#include "stdafx.h"
//�v���R���p�C���ς݃w�b�_�[�𗘗p���Ȃ��ꍇ�́A���1�s��
//���R�����g�A�E�g���ĉ���2�s���A���R�����g���Ă��������B
//#define WIN32_LEAN_AND_MEAN
//#include <windows.h>

#include "TaLib.h"

//�}�e���A�� �N���X�̊֐��|�C���^
LPCTSTR (WINAPI *PmGetMaterialName)(const CTaMaterial*) = NULL;
void (WINAPI *PmSetMaterialName)(CTaMaterial*, LPCTSTR) = NULL;
UINT (WINAPI *PmGetMaterialIndex)(const CTaMaterial*) = NULL;
void (WINAPI *PmSetMaterialIndex)(CTaMaterial*, UINT) = NULL;
void (WINAPI *PmGetMaterialColor)(const CTaMaterial*, float*, float*, float*) = NULL;
void (WINAPI *PmSetMaterialColor)(CTaMaterial*, float, float, float) = NULL;
float (WINAPI *PmGetMaterialDiffuse)(const CTaMaterial*) = NULL;
void (WINAPI *PmSetMaterialDiffuse)(CTaMaterial*, float) = NULL;
float (WINAPI *PmGetMaterialAmbient)(const CTaMaterial*) = NULL;
void (WINAPI *PmSetMaterialAmbient)(CTaMaterial*, float) = NULL;
float (WINAPI *PmGetMaterialEmissive)(const CTaMaterial*) = NULL;
void (WINAPI *PmSetMaterialEmissive)(CTaMaterial*, float) = NULL;
float (WINAPI *PmGetMaterialAlpha)(const CTaMaterial*) = NULL;
void (WINAPI *PmSetMaterialAlpha)(CTaMaterial*, float) = NULL;
float (WINAPI *PmGetMaterialSpecular)(const CTaMaterial*) = NULL;
void (WINAPI *PmSetMaterialSpecular)(CTaMaterial*, float) = NULL;
float (WINAPI *PmGetMaterialPower)(const CTaMaterial*) = NULL;
void (WINAPI *PmSetMaterialPower)(CTaMaterial*, float) = NULL;
UINT (WINAPI *PmGetMaterialTextureCount)(const CTaMaterial*) = NULL;
BOOL (WINAPI *PmGetMaterialTexture)(const CTaMaterial*, UINT, LPCTSTR*, UINT*, UINT*) = NULL;
BOOL (WINAPI *PmAddMaterialTexture)(CTaMaterial*, LPCTSTR, UINT, UINT, CTaScene*) = NULL;
BOOL (WINAPI *PmInsertMaterialTexture)(CTaMaterial*, UINT, LPCTSTR, UINT, UINT, CTaScene*) = NULL;
BOOL (WINAPI *PmReloadMaterialTexture)(CTaMaterial*, UINT, CTaScene*) = NULL;
BOOL (WINAPI *PmDeleteMaterialTexture)(CTaMaterial*, UINT) = NULL;
void (WINAPI *PmDeleteAllMaterialTextures)(CTaMaterial*) = NULL;

//�I�u�W�F�N�g �N���X�̊֐��|�C���^
UINT (WINAPI *PmGetObjectType)(const CTaObject*) = NULL;
LPCTSTR (WINAPI *PmGetObjectTypeName)(const CTaObject*) = NULL;
LPCTSTR (WINAPI *PmGetObjectName)(const CTaObject*) = NULL;
void (WINAPI *PmSetObjectName)(CTaObject*, LPCTSTR) = NULL;
UINT (WINAPI *PmGetObjectTreeNameLength)(const CTaObject*) = NULL;
void (WINAPI *PmGetObjectTreeName)(const CTaObject*, LPTSTR) = NULL;
BOOL (WINAPI *PmGetObjectVisible)(const CTaObject*) = NULL;
void (WINAPI *PmSetObjectVisible)(CTaObject*, BOOL, BOOL) = NULL;
BOOL (WINAPI *PmGetObjectLocked)(const CTaObject*) = NULL;
void (WINAPI *PmSetObjectLocked)(CTaObject*, BOOL) = NULL;
BOOL (WINAPI *PmGetObjectSlerped)(const CTaObject*) = NULL;
void (WINAPI *PmSetObjectSlerped)(CTaObject*, BOOL) = NULL;
BOOL (WINAPI *PmGetObjectAngularShaded)(const CTaObject* pObject) = NULL;
BOOL (WINAPI *PmSetObjectAngularShaded)(CTaObject* pObject, BOOL bAngularShaded, BOOL bUpdateGeometry) = NULL;
float (WINAPI *PmGetObjectSmoothAngle)(const CTaObject* pObject) = NULL;
BOOL (WINAPI *PmSetObjectSmoothAngle)(CTaObject* pObject, float SmoothAngle, BOOL bUpdateGeometry) = NULL;
void (WINAPI *PmGetObjectPivot)(const CTaObject*, TA_VECTOR*) = NULL;
void (WINAPI *PmSetObjectPivot)(CTaObject*, const TA_VECTOR*) = NULL;
void (WINAPI *PmGetObjectScale)(const CTaObject*, TA_VECTOR*) = NULL;
void (WINAPI *PmSetObjectScale)(CTaObject*, const TA_VECTOR*) = NULL;
void (WINAPI *PmGetObjectShear)(const CTaObject*, TA_VECTOR*) = NULL;
void (WINAPI *PmSetObjectShear)(CTaObject*, const TA_VECTOR*) = NULL;
void (WINAPI *PmGetObjectRotate)(const CTaObject*, TA_QUAT*) = NULL;
void (WINAPI *PmSetObjectRotate)(CTaObject*, const TA_QUAT*, BOOL) = NULL;
void (WINAPI *PmGetObjectAngle)(const CTaObject*, TA_VECTOR*) = NULL;
void (WINAPI *PmSetObjectAngle)(CTaObject*, const TA_VECTOR*) = NULL;
void (WINAPI *PmGetObjectTranslate)(const CTaObject*, TA_VECTOR*) = NULL;
void (WINAPI *PmSetObjectTranslate)(CTaObject*, const TA_VECTOR*) = NULL;
UINT (WINAPI *PmGetObjectEulerOrder)(const CTaObject*) = NULL;
void (WINAPI *PmSetObjectEulerOrder)(CTaObject*, UINT) = NULL;
void (WINAPI *PmGetObjectTransform)(const CTaObject*, TA_MATRIX*, BOOL) = NULL;
void (WINAPI *PmSetObjectTransform)(CTaObject*, const TA_MATRIX*, BOOL, BOOL) = NULL;
void (WINAPI *PmGetObjectWorldTransform)(const CTaObject*, TA_MATRIX*, BOOL) = NULL;
UINT (WINAPI *PmGetObjectBoneCount)(const CTaObject*) = NULL;
BOOL (WINAPI *PmGetObjectBones)(const CTaObject*, CTaObject**) = NULL;
void (WINAPI *PmSetObjectBones)(CTaObject*, CTaObject*const*, UINT) = NULL;
BOOL (WINAPI *PmGetObjectSkinBindTransform)(const CTaObject*, TA_MATRIX*) = NULL;
void (WINAPI *PmSetObjectSkinBindTransform)(CTaObject*, const TA_MATRIX*) = NULL;
BOOL (WINAPI *PmGetObjectBoneBindTransforms)(const CTaObject*, TA_MATRIX*) = NULL;
void (WINAPI *PmSetObjectBoneBindTransforms)(CTaObject*, const TA_MATRIX*, UINT) = NULL;
UINT (WINAPI *PmGetObjectBindPoseObjectCount)(const CTaObject*) = NULL;
BOOL (WINAPI *PmGetObjectBindPose)(const CTaObject*, CTaObject**, TA_VECTOR*, TA_VECTOR*, TA_VECTOR*, TA_VECTOR*) = NULL;
void (WINAPI *PmSetObjectBindPose)(CTaObject*, CTaObject*const*, const TA_VECTOR*, const TA_VECTOR*, const TA_VECTOR*, const TA_VECTOR*, UINT) = NULL;
void (WINAPI *PmClearObjectBones)(CTaObject*) = NULL;
CTaObject* (WINAPI *PmGetParentObject)(const CTaObject*) = NULL;
CTaObject* (WINAPI *PmGetRootObject)(const CTaObject*) = NULL;
UINT (WINAPI *PmGetObjectChildCount)(const CTaObject*) = NULL;
CTaObject* (WINAPI *PmGetObjectChild)(const CTaObject*, UINT) = NULL;
UINT (WINAPI *PmGetObjectChildIndex)(const CTaObject*, const CTaObject*) = NULL;
void (WINAPI *PmAddObjectChild)(CTaObject*, CTaObject*) = NULL;
BOOL (WINAPI *PmInsertObjectChild)(CTaObject*, UINT, CTaObject*) = NULL;
BOOL (WINAPI *PmRemoveObjectChild)(CTaObject*, CTaObject*) = NULL;
BOOL (WINAPI *PmDeleteObjectChild)(CTaObject*, CTaObject*) = NULL;
UINT (WINAPI *PmGetObjectIndexCount)(const CTaObject*) = NULL;
UINT (WINAPI *PmGetObjectIndices)(const CTaObject*, UINT*) = NULL;
CTaObject* (WINAPI *PmFindObject)(const CTaObject*, const UINT*, UINT) = NULL;
BOOL (WINAPI *PmInsertObject)(CTaObject*, const UINT*, UINT, CTaObject*) = NULL;
CTaObject* (WINAPI *PmFindObjectTreeName)(const CTaObject*, LPCTSTR) = NULL;
UINT (WINAPI *PmGetObjectVertexCount)(const CTaObject*) = NULL;
void (WINAPI *PmGetObjectVertexPositions)(const CTaObject*, TA_VECTOR*) = NULL;
void (WINAPI *PmSetObjectVertexPositions)(CTaObject*, const TA_VECTOR*) = NULL;
void (WINAPI *PmAddObjectVertex)(CTaObject*, const TA_VECTOR*) = NULL;
void (WINAPI *PmAddObjectVertices)(CTaObject*, const TA_VECTOR*, UINT) = NULL;
BOOL (WINAPI *PmHasObjectVertexBone)(const CTaObject*) = NULL;
BOOL (WINAPI *PmGetObjectVertexBones)(const CTaObject*, BYTE*const*, float*const*) = NULL;
BOOL (WINAPI *PmSetObjectVertexBones)(CTaObject*, const BYTE*const*, const float*const*) = NULL;
UINT (WINAPI *PmGetObjectFaceCount)(const CTaObject*) = NULL;
void (WINAPI *PmGetObjectFaceVertexCounts)(const CTaObject*, UINT*) = NULL;
void (WINAPI *PmGetObjectFaceVertexIndices)(const CTaObject*, int*const*) = NULL;
void (WINAPI *PmGetObjectFaceMaterials)(const CTaObject*, CTaMaterial**) = NULL;
void (WINAPI *PmSetObjectFaceMaterials)(CTaObject*, CTaMaterial*const*) = NULL;
void (WINAPI *PmGetObjectFaceNormals)(const CTaObject*, TA_VECTOR*) = NULL;
void (WINAPI *PmGetObjectFaceVertexFlatShades)(const CTaObject*, BOOL*const*) = NULL;
void (WINAPI *PmSetObjectFaceVertexFlatShades)(CTaObject*, const BOOL*const*) = NULL;
void (WINAPI *PmGetObjectFaceVertexColors)(const CTaObject*, TA_COLOR*const*) = NULL;
void (WINAPI *PmSetObjectFaceVertexColors)(CTaObject*, const TA_COLOR*const*) = NULL;
BOOL (WINAPI *PmHasObjectFaceVertexUV)(const CTaObject*) = NULL;
void (WINAPI *PmGetObjectFaceVertexUVs)(const CTaObject*, TA_VECTOR_2D*const*) = NULL;
void (WINAPI *PmSetObjectFaceVertexUVs)(CTaObject*, const TA_VECTOR_2D*const*) = NULL;
void (WINAPI *PmGetObjectFaceVertexNormals)(const CTaObject*, TA_VECTOR*const*) = NULL;
void (WINAPI *PmAddObjectFace)(CTaObject*, const int*, UINT) = NULL;
void (WINAPI *PmAddObjectFaces)(CTaObject*, const int*const*, const UINT*, UINT) = NULL;
void (WINAPI *PmCleanUpObjectMesh)(CTaObject*) = NULL;
void (WINAPI *PmUpdateObjectMeshTopology)(CTaObject*) = NULL;
void (WINAPI *PmUpdateObjectMeshNormals)(CTaObject*) = NULL;
void (WINAPI *PmUpdateObjectBoundBox)(CTaObject*) = NULL;
void (WINAPI *PmUpdateObjectGraphics)(CTaObject*) = NULL;
void (WINAPI *PmUpdateObjectGeometry)(CTaObject*) = NULL;
//�W���C���g�֘A�����o�[
BOOL (WINAPI *PmGetJointAreaEnabled)(const CTaObject*) = NULL;
void (WINAPI *PmSetJointAreaEnabled)(CTaObject*, BOOL) = NULL;
BOOL (WINAPI *PmGetJointParentScaleCompensated)(const CTaObject*) = NULL;
void (WINAPI *PmSetJointParentScaleCompensated)(CTaObject*, BOOL) = NULL;
//�J�����֘A�����o�[
UINT (WINAPI *PmGetCameraProjectionType)(const CTaObject*) = NULL;
void (WINAPI *PmSetCameraProjectionType)(CTaObject*, UINT) = NULL;
float (WINAPI *PmGetCameraViewAngle)(const CTaObject*) = NULL;
void (WINAPI *PmSetCameraViewAngle)(CTaObject*, float) = NULL;
float (WINAPI *PmGetCameraViewHeight)(const CTaObject*) = NULL;
void (WINAPI *PmSetCameraViewHeight)(CTaObject*, float) = NULL;
//���C�g�֘A�����o�[
BOOL (WINAPI *PmGetLightActive)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightActive)(CTaObject*, BOOL) = NULL;
void (WINAPI *PmGetLightColor)(const CTaObject*, float*, float*, float*) = NULL;
void (WINAPI *PmSetLightColor)(CTaObject*, float, float, float) = NULL;
float (WINAPI *PmGetLightDiffuse)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightDiffuse)(CTaObject*, float) = NULL;
float (WINAPI *PmGetLightAmbient)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightAmbient)(CTaObject*, float) = NULL;
float (WINAPI *PmGetLightSpecular)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightSpecular)(CTaObject*, float) = NULL;
UINT (WINAPI *PmGetLightType)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightType)(CTaObject*, UINT) = NULL;
UINT (WINAPI *PmGetLightDecayType)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightDecayType)(CTaObject*, UINT) = NULL;
float (WINAPI *PmGetLightIntensity)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightIntensity)(CTaObject*, float) = NULL;
float (WINAPI *PmGetLightRange)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightRange)(CTaObject*, float) = NULL;
float (WINAPI *PmGetLightConeAngle)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightConeAngle)(CTaObject*, float) = NULL;
float (WINAPI *PmGetLightPenumbraAngle)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightPenumbraAngle)(CTaObject*, float) = NULL;
float (WINAPI *PmGetLightFalloff)(const CTaObject*) = NULL;
void (WINAPI *PmSetLightFalloff)(CTaObject*, float) = NULL;
//�}�e���A���֘A�����o�[
UINT (WINAPI *PmGetModelMaterialCount)(const CTaObject*) = NULL;
void (WINAPI *PmUpdateModelMaterialIndices)(CTaObject*) = NULL;
BOOL (WINAPI *PmGetModelMaterials)(const CTaObject*, CTaMaterial**) = NULL;
CTaMaterial* (WINAPI *PmGetModelMaterial)(const CTaObject*, UINT) = NULL;
UINT (WINAPI *PmGetModelMaterialIndex)(const CTaObject*, const CTaMaterial*) = NULL;
CTaMaterial* (WINAPI *PmGetModelCurMaterial)(const CTaObject*) = NULL;
void (WINAPI *PmSetModelCurMaterial)(CTaObject*, CTaMaterial*) = NULL;
void (WINAPI *PmAddModelMaterial)(CTaObject*, CTaMaterial*) = NULL;
BOOL (WINAPI *PmInsertModelMaterial)(CTaObject*, UINT, CTaMaterial*) = NULL;
BOOL (WINAPI *PmDeleteModelMaterial)(CTaObject*, CTaMaterial*) = NULL;
BOOL (WINAPI *PmDeleteAllModelMaterials)(CTaObject*) = NULL;
//�A�j���[�V�����֘A�����o�[
UINT (WINAPI *PmGetModelAnimCount)(const CTaObject*) = NULL;
void (WINAPI *PmUpdateModelAnimIndices)(CTaObject*) = NULL;
BOOL (WINAPI *PmGetModelAnims)(const CTaObject*, CTaAnim** ppAnims) = NULL;
CTaAnim* (WINAPI *PmGetModelAnim)(const CTaObject*, UINT) = NULL;
UINT (WINAPI *PmGetModelAnimIndex)(const CTaObject*, const CTaAnim*) = NULL;
CTaAnim* (WINAPI *PmGetModelCurAnim)(const CTaObject*) = NULL;
void (WINAPI *PmSetModelCurAnim)(CTaObject*, CTaAnim*) = NULL;
void (WINAPI *PmAddModelAnim)(CTaObject*, CTaAnim*) = NULL;
BOOL (WINAPI *PmInsertModelAnim)(CTaObject*, UINT, CTaAnim*) = NULL;

//�V�[�� �N���X�̊֐��|�C���^
CTaObject* (WINAPI *PmGetSceneRootObject)(const CTaScene*) = NULL;

//�A�j���[�V���� �N���X�̊֐��|�C���^
LPCTSTR (WINAPI *PmGetAnimName)(const CTaAnim*) = NULL;
void (WINAPI *PmSetAnimName)(CTaAnim*, LPCTSTR) = NULL;
UINT (WINAPI *PmGetAnimIndex)(const CTaAnim*) = NULL;
void (WINAPI *PmSetAnimIndex)(CTaAnim*, UINT) = NULL;
float (WINAPI *PmGetAnimFps)(const CTaAnim*) = NULL;
BOOL (WINAPI *PmSetAnimFps)(CTaAnim*, float) = NULL;
float (WINAPI *PmGetAnimCurFrame)(const CTaAnim*) = NULL;
void (WINAPI *PmSetAnimCurFrame)(CTaAnim*, float) = NULL;
float (WINAPI *PmGetAnimFirstFrame)(const CTaAnim*) = NULL;
BOOL (WINAPI *PmSetAnimFirstFrame)(CTaAnim*, float) = NULL;
float (WINAPI *PmGetAnimLastFrame)(const CTaAnim*) = NULL;
BOOL (WINAPI *PmSetAnimLastFrame)(CTaAnim*, float) = NULL;
BOOL (WINAPI *PmIsObjectAnimItemEmpty)(const CTaAnim*, CTaObject*) = NULL;
CTaAnimItem* (WINAPI *PmGetObjectAnimItem)(const CTaAnim*, UINT, CTaObject*) = NULL;
BOOL (WINAPI *PmAnimateObjectAnimItems)(const CTaAnim*, CTaObject*, float, BOOL) = NULL;
CTaAnimItem* (WINAPI *PmCreateObjectAnimItem)(CTaAnim*, UINT, CTaObject*) = NULL;
BOOL (WINAPI *PmDeleteObjectAnimItem)(CTaAnim*, UINT, CTaObject*) = NULL;
BOOL (WINAPI *PmDeleteObjectAnimItems)(CTaAnim*, CTaObject*) = NULL;
BOOL (WINAPI *PmDeleteAllObjectAnimItems)(CTaAnim*) = NULL;
void (WINAPI *PmClearAnimItems)(CTaAnim*) = NULL;
void (WINAPI *PmCleanUpObjectAnimItems)(CTaAnim*) = NULL;
BOOL (WINAPI *PmGetConstrainedObjectAnimItems)(const CTaAnim*, CTaAnim*, float, BOOL) = NULL;

//�A�j���[�V���� �o�����[ �N���X�̊֐��|�C���^
BOOL (WINAPI *PmStoreAnimValuesObjectValues)(CTaAnimValues*, const CTaAnim*, const CTaObject*) = NULL;
BOOL (WINAPI *PmRestoreAnimValues)(const CTaAnimValues*, const CTaAnim*) = NULL;
void (WINAPI *PmClearAnimValues)(CTaAnimValues*) = NULL;

//�A�j���[�V���� �A�C�e�� �N���X�̊֐��|�C���^
BOOL (WINAPI *PmAnimateAnimItem)(const CTaAnimItem*, float, BOOL) = NULL;
UINT (WINAPI *PmGetAnimItemKeyFrameCount)(const CTaAnimItem*) = NULL;
BOOL (WINAPI *PmGetAnimItemKeyFrame)(const CTaAnimItem*, UINT, float*, float*, UINT*, UINT*, float*, float*, BOOL*) = NULL;
BOOL (WINAPI *PmSetAnimItemKeyFrame)(CTaAnimItem*, UINT, const float*, const UINT*, const UINT*, const float*, const float*, const BOOL*, BOOL) = NULL;
void (WINAPI *PmInsertAnimItemKeyFrame)(CTaAnimItem*, float, float, const UINT*, const UINT*, const float*, const float*, const BOOL*, BOOL) = NULL;
BOOL (WINAPI *PmDeleteAnimItemKeyFrame)(CTaAnimItem*, UINT, BOOL) = NULL;
void (WINAPI *PmDeleteAnimItemKeyFrames)(CTaAnimItem*) = NULL;
void (WINAPI *PmUpdateAnimItemSpline)(CTaAnimItem*) = NULL;

//�O���[�o���֐��̊֐��|�C���^
CTaMaterial* (WINAPI *PmCreateMaterial)() = NULL;
void (WINAPI *PmDeleteMaterial)(CTaMaterial*) = NULL;
CTaObject* (WINAPI *PmCreateObject)(UINT, CTaScene*) = NULL;
void (WINAPI *PmDeleteObject)(CTaObject*) = NULL;
CTaAnim* (WINAPI *PmCreateAnim)(void) = NULL;
void (WINAPI *PmDeleteAnim)(CTaAnim*) = NULL;
CTaAnimValues* (WINAPI *PmCreateAnimValues)(void) = NULL;
void (WINAPI *PmDeleteAnimValues)(CTaAnimValues*) = NULL;

//�֐��擾�}�N��
#define TA_GET_FUNC(func) \
*(FARPROC*)&func = GetProcAddress(hModule, #func); \
if(!func){ \
MessageBox(NULL, #func "�֐��̎擾�Ɏ��s���܂����B", "TOYSTUDIO API���C�u����������", MB_OK|MB_ICONWARNING); \
return FALSE; }

//���O���[�o���֐�

//���C�u�����[�̏�����
BOOL TaInitLib(HMODULE hModule)
{
	if(!hModule)
		return FALSE;

	//�}�e���A�� �N���X
	TA_GET_FUNC(PmGetMaterialName);
	TA_GET_FUNC(PmSetMaterialName);
	TA_GET_FUNC(PmGetMaterialIndex);
	TA_GET_FUNC(PmSetMaterialIndex);
	TA_GET_FUNC(PmGetMaterialColor);
	TA_GET_FUNC(PmSetMaterialColor);
	TA_GET_FUNC(PmGetMaterialDiffuse);
	TA_GET_FUNC(PmSetMaterialDiffuse);
	TA_GET_FUNC(PmGetMaterialAmbient);
	TA_GET_FUNC(PmSetMaterialAmbient);
	TA_GET_FUNC(PmGetMaterialEmissive);
	TA_GET_FUNC(PmSetMaterialEmissive);
	TA_GET_FUNC(PmGetMaterialAlpha);
	TA_GET_FUNC(PmSetMaterialAlpha);
	TA_GET_FUNC(PmGetMaterialSpecular);
	TA_GET_FUNC(PmSetMaterialSpecular);
	TA_GET_FUNC(PmGetMaterialPower);
	TA_GET_FUNC(PmSetMaterialPower);
	TA_GET_FUNC(PmGetMaterialTextureCount);
	TA_GET_FUNC(PmGetMaterialTexture);
	TA_GET_FUNC(PmAddMaterialTexture);
	TA_GET_FUNC(PmInsertMaterialTexture);
	TA_GET_FUNC(PmReloadMaterialTexture);
	TA_GET_FUNC(PmDeleteMaterialTexture);
	TA_GET_FUNC(PmDeleteAllMaterialTextures);

	//�I�u�W�F�N�g �N���X
	TA_GET_FUNC(PmGetObjectType);
	TA_GET_FUNC(PmGetObjectTypeName);
	TA_GET_FUNC(PmGetObjectName);
	TA_GET_FUNC(PmSetObjectName);
	TA_GET_FUNC(PmGetObjectTreeNameLength);
	TA_GET_FUNC(PmGetObjectTreeName);
	TA_GET_FUNC(PmGetObjectVisible);
	TA_GET_FUNC(PmSetObjectVisible);
	TA_GET_FUNC(PmGetObjectLocked);
	TA_GET_FUNC(PmSetObjectLocked);
	TA_GET_FUNC(PmGetObjectSlerped);
	TA_GET_FUNC(PmSetObjectSlerped);
	TA_GET_FUNC(PmGetObjectAngularShaded);
	TA_GET_FUNC(PmSetObjectAngularShaded);
	TA_GET_FUNC(PmGetObjectSmoothAngle);
	TA_GET_FUNC(PmSetObjectSmoothAngle);
	TA_GET_FUNC(PmGetObjectPivot);
	TA_GET_FUNC(PmSetObjectPivot);
	TA_GET_FUNC(PmGetObjectScale);
	TA_GET_FUNC(PmSetObjectScale);
	TA_GET_FUNC(PmGetObjectShear);
	TA_GET_FUNC(PmSetObjectShear);
	TA_GET_FUNC(PmGetObjectRotate);
	TA_GET_FUNC(PmSetObjectRotate);
	TA_GET_FUNC(PmGetObjectAngle);
	TA_GET_FUNC(PmSetObjectAngle);
	TA_GET_FUNC(PmGetObjectTranslate);
	TA_GET_FUNC(PmSetObjectTranslate);
	TA_GET_FUNC(PmGetObjectEulerOrder);
	TA_GET_FUNC(PmSetObjectEulerOrder);
	TA_GET_FUNC(PmGetObjectTransform);
	TA_GET_FUNC(PmSetObjectTransform);
	TA_GET_FUNC(PmGetObjectWorldTransform);
	TA_GET_FUNC(PmGetObjectBoneCount);
	TA_GET_FUNC(PmGetObjectBones);
	TA_GET_FUNC(PmSetObjectBones);
	TA_GET_FUNC(PmGetObjectSkinBindTransform);
	TA_GET_FUNC(PmSetObjectSkinBindTransform);
	TA_GET_FUNC(PmGetObjectBoneBindTransforms);
	TA_GET_FUNC(PmSetObjectBoneBindTransforms);
	TA_GET_FUNC(PmGetObjectBindPoseObjectCount);
	TA_GET_FUNC(PmGetObjectBindPose);
	TA_GET_FUNC(PmSetObjectBindPose);
	TA_GET_FUNC(PmClearObjectBones);
	TA_GET_FUNC(PmGetParentObject);
	TA_GET_FUNC(PmGetRootObject);
	TA_GET_FUNC(PmGetObjectChildCount);
	TA_GET_FUNC(PmGetObjectChild);
    TA_GET_FUNC(PmGetObjectChildIndex);
    TA_GET_FUNC(PmAddObjectChild);
    TA_GET_FUNC(PmInsertObjectChild);
    TA_GET_FUNC(PmRemoveObjectChild);
    TA_GET_FUNC(PmDeleteObjectChild);
    TA_GET_FUNC(PmGetObjectIndexCount);
    TA_GET_FUNC(PmGetObjectIndices);
    TA_GET_FUNC(PmFindObject);
    TA_GET_FUNC(PmInsertObject);
	TA_GET_FUNC(PmFindObjectTreeName);
	TA_GET_FUNC(PmGetObjectVertexCount);
	TA_GET_FUNC(PmGetObjectVertexPositions);
	TA_GET_FUNC(PmSetObjectVertexPositions);
	TA_GET_FUNC(PmAddObjectVertex);
	TA_GET_FUNC(PmAddObjectVertices);
	TA_GET_FUNC(PmHasObjectVertexBone);
	TA_GET_FUNC(PmGetObjectVertexBones);
	TA_GET_FUNC(PmSetObjectVertexBones);
	TA_GET_FUNC(PmGetObjectFaceCount);
	TA_GET_FUNC(PmGetObjectFaceVertexCounts);
	TA_GET_FUNC(PmGetObjectFaceVertexIndices);
	TA_GET_FUNC(PmGetObjectFaceMaterials);
	TA_GET_FUNC(PmSetObjectFaceMaterials);
	TA_GET_FUNC(PmGetObjectFaceNormals);
	TA_GET_FUNC(PmGetObjectFaceVertexFlatShades);
	TA_GET_FUNC(PmSetObjectFaceVertexFlatShades);
	TA_GET_FUNC(PmGetObjectFaceVertexColors);
	TA_GET_FUNC(PmSetObjectFaceVertexColors);
	TA_GET_FUNC(PmHasObjectFaceVertexUV);
	TA_GET_FUNC(PmGetObjectFaceVertexUVs);
	TA_GET_FUNC(PmSetObjectFaceVertexUVs);
	TA_GET_FUNC(PmGetObjectFaceVertexNormals);
	TA_GET_FUNC(PmAddObjectFace);
	TA_GET_FUNC(PmAddObjectFaces);
	TA_GET_FUNC(PmCleanUpObjectMesh);
	TA_GET_FUNC(PmUpdateObjectMeshTopology);
	TA_GET_FUNC(PmUpdateObjectMeshNormals);
	TA_GET_FUNC(PmUpdateObjectBoundBox);
	TA_GET_FUNC(PmUpdateObjectGraphics);
	TA_GET_FUNC(PmUpdateObjectGeometry);
	//�W���C���g�֘A
	TA_GET_FUNC(PmGetJointAreaEnabled);
	TA_GET_FUNC(PmSetJointAreaEnabled);
	TA_GET_FUNC(PmGetJointParentScaleCompensated);
	TA_GET_FUNC(PmSetJointParentScaleCompensated);
	//�J�����֘A
	TA_GET_FUNC(PmGetCameraProjectionType);
	TA_GET_FUNC(PmSetCameraProjectionType);
	TA_GET_FUNC(PmGetCameraViewAngle);
	TA_GET_FUNC(PmSetCameraViewAngle);
	TA_GET_FUNC(PmGetCameraViewHeight);
	TA_GET_FUNC(PmSetCameraViewHeight);
	//���C�g�֘A
	TA_GET_FUNC(PmGetLightActive);
	TA_GET_FUNC(PmSetLightActive);
	TA_GET_FUNC(PmGetLightColor);
	TA_GET_FUNC(PmSetLightColor);
	TA_GET_FUNC(PmGetLightDiffuse);
	TA_GET_FUNC(PmSetLightDiffuse);
	TA_GET_FUNC(PmGetLightAmbient);
	TA_GET_FUNC(PmSetLightAmbient);
	TA_GET_FUNC(PmGetLightSpecular);
	TA_GET_FUNC(PmSetLightSpecular);
	TA_GET_FUNC(PmGetLightType);
	TA_GET_FUNC(PmSetLightType);
	TA_GET_FUNC(PmGetLightDecayType);
	TA_GET_FUNC(PmSetLightDecayType);
	TA_GET_FUNC(PmGetLightIntensity);
	TA_GET_FUNC(PmSetLightIntensity);
	TA_GET_FUNC(PmGetLightRange);
	TA_GET_FUNC(PmSetLightRange);
	TA_GET_FUNC(PmGetLightConeAngle);
	TA_GET_FUNC(PmSetLightConeAngle);
	TA_GET_FUNC(PmGetLightPenumbraAngle);
	TA_GET_FUNC(PmSetLightPenumbraAngle);
	TA_GET_FUNC(PmGetLightFalloff);
	TA_GET_FUNC(PmSetLightFalloff);
	//�}�e���A���֘A
	TA_GET_FUNC(PmGetModelMaterialCount);
	TA_GET_FUNC(PmUpdateModelMaterialIndices);
	TA_GET_FUNC(PmGetModelMaterials);
	TA_GET_FUNC(PmGetModelMaterial);
	TA_GET_FUNC(PmGetModelMaterialIndex);
	TA_GET_FUNC(PmGetModelCurMaterial);
	TA_GET_FUNC(PmSetModelCurMaterial);
	TA_GET_FUNC(PmAddModelMaterial);
	TA_GET_FUNC(PmInsertModelMaterial);
	TA_GET_FUNC(PmDeleteModelMaterial);
	TA_GET_FUNC(PmDeleteAllModelMaterials);
	//�A�j���[�V�����֘A
	TA_GET_FUNC(PmGetModelAnimCount);
	TA_GET_FUNC(PmUpdateModelAnimIndices);
	TA_GET_FUNC(PmGetModelAnims);
	TA_GET_FUNC(PmGetModelAnim);
	TA_GET_FUNC(PmGetModelAnimIndex);
	TA_GET_FUNC(PmGetModelCurAnim);
	TA_GET_FUNC(PmSetModelCurAnim);
	TA_GET_FUNC(PmAddModelAnim);
	TA_GET_FUNC(PmInsertModelAnim);

	//�V�[�� �N���X
	TA_GET_FUNC(PmGetSceneRootObject);

	//�A�j���[�V���� �N���X
	TA_GET_FUNC(PmGetAnimName);
	TA_GET_FUNC(PmSetAnimName);
	TA_GET_FUNC(PmGetAnimIndex);
	TA_GET_FUNC(PmSetAnimIndex);
	TA_GET_FUNC(PmGetAnimFps);
	TA_GET_FUNC(PmSetAnimFps);
	TA_GET_FUNC(PmGetAnimCurFrame);
	TA_GET_FUNC(PmSetAnimCurFrame);
	TA_GET_FUNC(PmGetAnimFirstFrame);
	TA_GET_FUNC(PmSetAnimFirstFrame);
	TA_GET_FUNC(PmGetAnimLastFrame);
	TA_GET_FUNC(PmSetAnimLastFrame);
	TA_GET_FUNC(PmIsObjectAnimItemEmpty);
	TA_GET_FUNC(PmGetObjectAnimItem);
	TA_GET_FUNC(PmAnimateObjectAnimItems);
	TA_GET_FUNC(PmCreateObjectAnimItem);
	TA_GET_FUNC(PmDeleteObjectAnimItem);
	TA_GET_FUNC(PmDeleteObjectAnimItems);
	TA_GET_FUNC(PmDeleteAllObjectAnimItems);
	TA_GET_FUNC(PmCleanUpObjectAnimItems);
	TA_GET_FUNC(PmClearAnimItems);
	TA_GET_FUNC(PmGetConstrainedObjectAnimItems);

	//�A�j���[�V���� �o�����[ �N���X
	TA_GET_FUNC(PmStoreAnimValuesObjectValues);
	TA_GET_FUNC(PmRestoreAnimValues);
	TA_GET_FUNC(PmClearAnimValues);

	//�A�j���[�V���� �A�C�e�� �N���X
	TA_GET_FUNC(PmAnimateAnimItem);
	TA_GET_FUNC(PmGetAnimItemKeyFrameCount);
	TA_GET_FUNC(PmGetAnimItemKeyFrame);
	TA_GET_FUNC(PmSetAnimItemKeyFrame);
	TA_GET_FUNC(PmInsertAnimItemKeyFrame);
	TA_GET_FUNC(PmDeleteAnimItemKeyFrame);
	TA_GET_FUNC(PmDeleteAnimItemKeyFrames);
	TA_GET_FUNC(PmUpdateAnimItemSpline);

	//�O���[�o���֐�
	TA_GET_FUNC(PmCreateMaterial);
	TA_GET_FUNC(PmDeleteMaterial);
	TA_GET_FUNC(PmCreateObject);
	TA_GET_FUNC(PmDeleteObject);
	TA_GET_FUNC(PmCreateAnim);
	TA_GET_FUNC(PmDeleteAnim);
	TA_GET_FUNC(PmCreateAnimValues);
	TA_GET_FUNC(PmDeleteAnimValues);

	return TRUE;
}

CTaMaterial* TaCreateMaterial(void)
{
	return PmCreateMaterial();
}

void TaDeleteMaterial(CTaMaterial* pMaterial)
{
	PmDeleteMaterial(pMaterial);
}

CTaObject* TaCreateObject(TA_OBJECT_TYPE Type, CTaScene* pScene)
{
	return PmCreateObject(Type, pScene);
}

void TaDeleteObject(CTaObject* pObject)
{
	PmDeleteObject(pObject);
}

CTaAnim* TaCreateAnim(void)
{
	return PmCreateAnim();
}

void TaDeleteAnim(CTaAnim* pAnim)
{
	PmDeleteAnim(pAnim);
}


CTaAnimValues* TaCreateAnimValues(void)
{
	return PmCreateAnimValues();
}

void TaDeleteAnimValues(CTaAnimValues* pAnimValues)
{
	PmDeleteAnimValues(pAnimValues);
}

//���}�e���A�� �N���X

LPCSTR CTaMaterial::GetName()const
{
	return PmGetMaterialName(this);
}

void CTaMaterial::SetName(LPCTSTR pszName)
{
	PmSetMaterialName(this, pszName);
}

UINT CTaMaterial::GetIndex()const
{
	return PmGetMaterialIndex(this);
}

void CTaMaterial::SetIndex(UINT nIndex)
{
	PmSetMaterialIndex(this, nIndex);
}

TA_VECTOR CTaMaterial::GetColor()const
{
	TA_VECTOR vec;
	PmGetMaterialColor(this, &vec.r, &vec.g, &vec.b);
	return vec;
}

void CTaMaterial::SetColor(const TA_VECTOR& Color)
{
	PmSetMaterialColor(this, Color.r, Color.g, Color.b);
}

float CTaMaterial::GetDiffuse()const
{
	return PmGetMaterialDiffuse(this);
}

void CTaMaterial::SetDiffuse(float Diffuse)
{
	PmSetMaterialDiffuse(this, Diffuse);
}

float CTaMaterial::GetAmbient()const
{
	return PmGetMaterialAmbient(this);
}

void CTaMaterial::SetAmbient(float Ambient)
{
	PmSetMaterialAmbient(this, Ambient);
}

float CTaMaterial::GetEmissive()const
{
	return PmGetMaterialEmissive(this);
}

void CTaMaterial::SetEmissive(float Emissive)
{
	PmSetMaterialEmissive(this, Emissive);
}

float CTaMaterial::GetAlpha()const
{
	return PmGetMaterialAlpha(this);
}

void CTaMaterial::SetAlpha(float Alpha)
{
	PmSetMaterialAlpha(this, Alpha);
}

float CTaMaterial::GetSpecular()const
{
	return PmGetMaterialSpecular(this);
}

void CTaMaterial::SetSpecular(float Specular)
{
	PmSetMaterialSpecular(this, Specular);
}

float CTaMaterial::GetPower()const
{
	return PmGetMaterialPower(this);
}

void CTaMaterial::SetPower(float Power)
{
	PmSetMaterialPower(this, Power);
}

UINT CTaMaterial::GetTextureCount()const
{
	return PmGetMaterialTextureCount(this);
}

BOOL CTaMaterial::GetTexture(UINT nIndex, LPCTSTR* ppszFilePath, TA_COLOR_OP_TYPE* pColorOp, TA_ALPHA_OP_TYPE* pAlphaOp)const
{
	return PmGetMaterialTexture(this, nIndex, ppszFilePath, (UINT*)pColorOp, (UINT*)pAlphaOp);
}

BOOL CTaMaterial::AddTexture(LPCTSTR pszFilePath, TA_COLOR_OP_TYPE ColorOp, TA_ALPHA_OP_TYPE AlphaOp, CTaScene* pScene)
{
	return PmAddMaterialTexture(this, pszFilePath, ColorOp, AlphaOp, pScene);
}

BOOL CTaMaterial::InsertTexture(UINT nIndex, LPCTSTR pszFilePath, TA_COLOR_OP_TYPE ColorOp, TA_ALPHA_OP_TYPE AlphaOp, CTaScene* pScene)
{
	return PmInsertMaterialTexture(this, nIndex, pszFilePath, ColorOp, AlphaOp, pScene);
}

BOOL CTaMaterial::ReloadTexture(UINT nIndex, CTaScene* pScene)
{
	return PmReloadMaterialTexture(this, nIndex, pScene);
}

BOOL CTaMaterial::DeleteTexture(UINT nIndex)
{
	return PmDeleteMaterialTexture(this, nIndex);
}

void CTaMaterial::DeleteAllTextures()
{
	PmDeleteAllMaterialTextures(this);
}

//���I�u�W�F�N�g �N���X

TA_OBJECT_TYPE CTaObject::GetType()const
{
	return static_cast<TA_OBJECT_TYPE>(PmGetObjectType(this));
}

LPCTSTR CTaObject::GetTypeName()const
{
	return PmGetObjectTypeName(this);
}

LPCTSTR CTaObject::GetName()const
{
	return PmGetObjectName(this);
}

void CTaObject::SetName(LPCTSTR pszName)
{
	PmSetObjectName(this, pszName);
}

UINT CTaObject::GetTreeNameLength()const
{
	return PmGetObjectTreeNameLength(this);
}

void CTaObject::GetTreeName(LPTSTR pszTreeName)const
{
	PmGetObjectTreeName(this, pszTreeName);
}

BOOL CTaObject::GetVisible()const
{
	return PmGetObjectVisible(this);
}

void CTaObject::SetVisible(BOOL bVisible, BOOL bUpdateGraphics)
{
	PmSetObjectVisible(this, bVisible, bUpdateGraphics);
}

BOOL CTaObject::GetLocked()const
{
	return PmGetObjectLocked(this);
}

void CTaObject::SetLocked(BOOL bLocked)
{
	PmSetObjectLocked(this, bLocked);
}


BOOL CTaObject::GetSlerped()const
{
	return PmGetObjectSlerped(this);
}

void CTaObject::SetSlerped(BOOL bSlerped)
{
	PmSetObjectSlerped(this, bSlerped);
}

BOOL CTaObject::GetAngularShaded()
{
	return PmGetObjectAngularShaded(this);
}

void CTaObject::SetAngularShaded(BOOL bAngularShaded, BOOL bUpdateGeometry)
{
	PmSetObjectAngularShaded(this, bAngularShaded, bUpdateGeometry);
}

float CTaObject::GetSmoothAngle()
{
	return PmGetObjectSmoothAngle(this);
}

void CTaObject::SetSmoothAngle(float SmoothAngle, BOOL bUpdateGeometry)
{
	PmSetObjectSmoothAngle(this, SmoothAngle, bUpdateGeometry);
}

TA_VECTOR CTaObject::GetPivot()const
{
	TA_VECTOR Pivot;
	PmGetObjectPivot(this, &Pivot);
	return Pivot;
}

void CTaObject::SetPivot(const TA_VECTOR& Pivot)
{
	PmSetObjectPivot(this, &Pivot);
}

TA_VECTOR CTaObject::GetScale()const
{
	TA_VECTOR Scale;
	PmGetObjectScale(this, &Scale);
	return Scale;
}

void CTaObject::SetScale(const TA_VECTOR& Scale)
{
	PmSetObjectScale(this, &Scale);
}

TA_VECTOR CTaObject::GetShear()const
{
	TA_VECTOR Shear;
	PmGetObjectShear(this, &Shear);
	return Shear;
}

void CTaObject::SetShear(const TA_VECTOR& Shear)
{
	PmSetObjectShear(this, &Shear);
}

TA_QUAT CTaObject::GetRotate()const
{
	TA_QUAT Rotate;
	PmGetObjectRotate(this, &Rotate);
	return Rotate;
}

void CTaObject::SetRotate(const TA_QUAT& Rotate, BOOL bResetAngle)
{
	PmSetObjectRotate(this, &Rotate, bResetAngle);
}

TA_VECTOR CTaObject::GetAngle()const
{
	TA_VECTOR Angle;
	PmGetObjectAngle(this, &Angle);
	return Angle;
}

void CTaObject::SetAngle(const TA_VECTOR& Angle)
{
	PmSetObjectAngle(this, &Angle);
}

TA_VECTOR CTaObject::GetTranslate()const
{
	TA_VECTOR Translate;
	PmGetObjectTranslate(this, &Translate);
	return Translate;
}

void CTaObject::SetTranslate(const TA_VECTOR& Translate)
{
	PmSetObjectTranslate(this, &Translate);
}

TA_EULER_ORDER_TYPE CTaObject::GetEulerOrder()const
{
	return static_cast<TA_EULER_ORDER_TYPE>(PmGetObjectEulerOrder(this));
}

void CTaObject::SetEulerOrder(TA_EULER_ORDER_TYPE EulerOrder)
{
	PmSetObjectEulerOrder(this, EulerOrder);
}

void CTaObject::GetTransform(TA_MATRIX& Transform, BOOL bLeftHand)const
{
	PmGetObjectTransform(this, &Transform, bLeftHand);
}

void CTaObject::SetTransform(const TA_MATRIX& Transform, BOOL bShear, BOOL bLeftHand)
{
	PmSetObjectTransform(this, &Transform, bShear, bLeftHand);
}

void CTaObject::GetWorldTransform(TA_MATRIX& Transform, BOOL bLeftHand)const
{
	PmGetObjectWorldTransform(this, &Transform, bLeftHand);
}

UINT CTaObject::GetBoneCount()const
{
	return PmGetObjectBoneCount(this);
}

BOOL CTaObject::GetBones(CTaObject* pBones[])const
{
	return PmGetObjectBones(this, pBones);
}

void CTaObject::SetBones(CTaObject*const pBones[], UINT nCount)
{
	PmSetObjectBones(this, pBones, nCount);
}

BOOL CTaObject::GetSkinBindTransform(TA_MATRIX& Transform)const
{
	return PmGetObjectSkinBindTransform(this, &Transform);
}

void CTaObject::SetSkinBindTransform(const TA_MATRIX& Transform)
{
	PmSetObjectSkinBindTransform(this, &Transform);
}

BOOL CTaObject::GetBoneBindTransforms(TA_MATRIX Transforms[])const
{
	return PmGetObjectBoneBindTransforms(this, Transforms);
}

void CTaObject::SetBoneBindTransforms(const TA_MATRIX Transforms[], UINT nCount)
{
	PmSetObjectBoneBindTransforms(this, Transforms, nCount);
}

UINT CTaObject::GetBindPoseObjectCount()const
{
	return PmGetObjectBindPoseObjectCount(this);
}

BOOL CTaObject::GetBindPose(CTaObject* pObjects[], TA_VECTOR Translates[],
									TA_VECTOR Angles[], TA_VECTOR Scales[], TA_VECTOR Shears[])const
{
	return PmGetObjectBindPose(this, pObjects, Translates, Angles, Scales, Shears);
}

void CTaObject::SetBindPose(CTaObject*const pObjects[], const TA_VECTOR Translates[],
									const TA_VECTOR Angles[], const TA_VECTOR Scales[], const TA_VECTOR Shears[], UINT nCount)
{
	PmSetObjectBindPose(this, pObjects, Translates, Angles, Scales, Shears, nCount);
}

void CTaObject::ClearBones()
{
	PmClearObjectBones(this);
}

CTaObject* CTaObject::GetParent()const
{
	return PmGetParentObject(this);
}

CTaObject* CTaObject::GetRootModel()const
{
	return PmGetRootObject(this);
}

UINT CTaObject::GetChildCount()const
{
	return PmGetObjectChildCount(this);
}

CTaObject* CTaObject::GetChild(UINT nIndex)const
{
	return PmGetObjectChild(this, nIndex);
}

UINT CTaObject::GetChildIndex(const CTaObject* pChild)const
{
	return PmGetObjectChildIndex(this, pChild);
}

void CTaObject::AddChild(CTaObject* pChild)
{
	PmAddObjectChild(this, pChild);
}

BOOL CTaObject::InsertChild(UINT nIndex, CTaObject* pChild)
{
	return PmInsertObjectChild(this, nIndex, pChild);
}

BOOL CTaObject::RemoveChild(CTaObject* pChild)
{
	return PmRemoveObjectChild(this, pChild);
}

BOOL CTaObject::DeleteChild(CTaObject* pChild)
{
	return PmDeleteObjectChild(this, pChild);
}

UINT CTaObject::GetIndexCount()const
{
	return PmGetObjectIndexCount(this);
}

UINT CTaObject::GetIndices(UINT Indices[])const
{
	return PmGetObjectIndices(this, Indices);
}

CTaObject* CTaObject::Find(const UINT Indices[], UINT nCount)const
{
	return PmFindObject(this, Indices, nCount);
}

BOOL CTaObject::Insert(const UINT Indices[], UINT nCount, CTaObject* pObject)
{
	return PmInsertObject(this, Indices, nCount, pObject);
}

CTaObject* CTaObject::FindTreeName(LPCTSTR pszTreeName)const
{
	return PmFindObjectTreeName(this, pszTreeName);
}

UINT CTaObject::GetVertexCount()const
{
	return PmGetObjectVertexCount(this);
}

void CTaObject::GetVertexPositions(TA_VECTOR Positions[])const
{
	PmGetObjectVertexPositions(this, Positions);
}

void CTaObject::SetVertexPositions(const TA_VECTOR Positions[])
{
	PmSetObjectVertexPositions(this, Positions);
}

void CTaObject::AddVertex(const TA_VECTOR& Position)
{
	PmAddObjectVertex(this, &Position);
}

void CTaObject::AddVertices(const TA_VECTOR Positions[], UINT nCount)
{
	PmAddObjectVertices(this, Positions, nCount);
}

BOOL CTaObject::HasVertexBone()const
{
	return PmHasObjectVertexBone(this);
}

BOOL CTaObject::GetVertexBones(BYTE*const pIndices[], float*const pWeights[])const
{
	return PmGetObjectVertexBones(this, pIndices, pWeights);
}

BOOL CTaObject::SetVertexBones(const BYTE*const pIndices[], const float*const pWeights[])
{
	return PmSetObjectVertexBones(this, pIndices, pWeights);
}

UINT CTaObject::GetFaceCount()const
{
	return PmGetObjectFaceCount(this);
}

void CTaObject::GetFaceVertexCounts(UINT Counts[])const
{
	PmGetObjectFaceVertexCounts(this, Counts);
}

void CTaObject::GetFaceVertexIndices(int* const pIndices[])const
{
	PmGetObjectFaceVertexIndices(this, pIndices);
}

void CTaObject::GetFaceMaterials(CTaMaterial* pMaterials[])const
{
	PmGetObjectFaceMaterials(this, pMaterials);
}

void CTaObject::SetFaceMaterials(CTaMaterial*const pMaterials[])
{
	PmSetObjectFaceMaterials(this, pMaterials);
}

void CTaObject::GetFaceNormals(TA_VECTOR Normals[])const
{
	PmGetObjectFaceNormals(this, Normals);
}

void CTaObject::GetFaceVertexFlatShades(BOOL*const pFlatShades[])const
{
	PmGetObjectFaceVertexFlatShades(this, pFlatShades);
}

void CTaObject::SetFaceVertexFlatShades(const BOOL*const pFlatShades[])
{
	PmSetObjectFaceVertexFlatShades(this, pFlatShades);
}

void CTaObject::GetFaceVertexColors(TA_COLOR*const pColors[])const
{
	PmGetObjectFaceVertexColors(this, pColors);
}

void CTaObject::SetFaceVertexColors(const TA_COLOR*const pColors[])
{
	PmSetObjectFaceVertexColors(this, pColors);
}

BOOL CTaObject::HasFaceVertexUV()const
{
	return PmHasObjectFaceVertexUV(this);
}

void CTaObject::GetFaceVertexUVs(TA_VECTOR_2D*const pUVs[])const
{
	PmGetObjectFaceVertexUVs(this, pUVs);
}

void CTaObject::SetFaceVertexUVs(const TA_VECTOR_2D*const pUVs[])
{
	PmSetObjectFaceVertexUVs(this, pUVs);
}

void CTaObject::GetFaceVertexNormals(TA_VECTOR*const pNormals[])const
{
	PmGetObjectFaceVertexNormals(this, pNormals);
}

void CTaObject::AddFace(const int Indices[], UINT nCount)
{
	PmAddObjectFace(this, Indices, nCount);
}

void CTaObject::AddFaces(const int*const pIndices[], const UINT Counts[], UINT nCount)
{
	PmAddObjectFaces(this, pIndices, Counts, nCount);
}

void CTaObject::CleanUpMesh()
{
	PmCleanUpObjectMesh(this);
}

void CTaObject::UpdateMeshTopology()
{
	PmUpdateObjectMeshTopology(this);
}

void CTaObject::UpdateMeshNormals()
{
	PmUpdateObjectMeshNormals(this);
}

void CTaObject::UpdateBoundBox()
{
	PmUpdateObjectBoundBox(this);
}

void CTaObject::UpdateGraphics()
{
	PmUpdateObjectGraphics(this);
}

void CTaObject::UpdateGeometry()
{
	PmUpdateObjectGeometry(this);
}

//���W���C���g�p���\�b�h

BOOL CTaObject::GetJointAreaEnabled()const
{
	return PmGetJointAreaEnabled(this);
}

void CTaObject::SetJointAreaEnabled(BOOL bEnabled)
{
	PmSetJointAreaEnabled(this, bEnabled);
}

BOOL CTaObject::GetJointParentScaleCompensated()const
{
	return PmGetJointParentScaleCompensated(this);
}

void CTaObject::SetJointParentScaleCompensated(BOOL bCompensated)
{
	PmSetJointParentScaleCompensated(this, bCompensated);
}

//���J�����p���\�b�h

TA_PROJECTION_TYPE CTaObject::GetCameraProjectionType()const
{
	return static_cast<TA_PROJECTION_TYPE>(PmGetCameraProjectionType(this));
}

void CTaObject::SetCameraProjectionType(TA_PROJECTION_TYPE ProjectionType)
{
	PmSetCameraProjectionType(this, ProjectionType);
}

float CTaObject::GetCameraViewAngle()const
{
	return PmGetCameraViewAngle(this);
}

void CTaObject::SetCameraViewAngle(float ViewAngle)
{
	PmSetCameraViewAngle(this, ViewAngle);
}

float CTaObject::GetCameraViewHeight()const
{
	return PmGetCameraViewHeight(this);
}

void CTaObject::SetCameraViewHeight(float ViewHeight)
{
	PmSetCameraViewHeight(this, ViewHeight);
}

//�����C�g�p���\�b�h

BOOL CTaObject::GetLightActive()const
{
	return PmGetLightActive(this);
}

void CTaObject::SetLightActive(BOOL bActive)
{
	PmSetLightActive(this, bActive);
}

TA_VECTOR CTaObject::GetLightColor()const
{
	TA_VECTOR vec;
	PmGetLightColor(this, &vec.r, &vec.g, &vec.b);
	return vec;
}

void CTaObject::SetLightColor(const TA_VECTOR& Color)
{
	PmSetLightColor(this, Color.r, Color.g, Color.b);
}

float CTaObject::GetLightDiffuse()const
{
	return PmGetLightDiffuse(this);
}

void CTaObject::SetLightDiffuse(float Diffuse)
{
	PmSetLightDiffuse(this, Diffuse);
}

float CTaObject::GetLightAmbient()const
{
	return PmGetLightAmbient(this);
}

void CTaObject::SetLightAmbient(float Ambient)
{
	PmSetLightAmbient(this, Ambient);
}

float CTaObject::GetLightSpecular()const
{
	return PmGetLightSpecular(this);
}

void CTaObject::SetLightSpecular(float Specular)
{
	PmSetLightSpecular(this, Specular);
}

TA_LIGHT_TYPE CTaObject::GetLightType()const
{
	return static_cast<TA_LIGHT_TYPE>(PmGetLightType(this));
}

void CTaObject::SetLightType(TA_LIGHT_TYPE LightType)
{
	PmSetLightType(this, LightType);
}

TA_DECAY_TYPE CTaObject::GetLightDecayType()const
{
	return static_cast<TA_DECAY_TYPE>(PmGetLightDecayType(this));
}

void CTaObject::SetLightDecayType(TA_DECAY_TYPE DecayType)
{
	PmSetLightDecayType(this, DecayType);
}

float CTaObject::GetLightIntensity()const
{
	return PmGetLightIntensity(this);
}

void CTaObject::SetLightIntensity(float Intensity)
{
	PmSetLightIntensity(this, Intensity);
}

float CTaObject::GetLightRange()const
{
	return PmGetLightRange(this);
}

void CTaObject::SetLightRange(float Range)
{
	PmSetLightRange(this, Range);
}

float CTaObject::GetLightConeAngle()const
{
	return PmGetLightConeAngle(this);
}

void CTaObject::SetLightConeAngle(float ConeAngle)
{
	PmSetLightConeAngle(this, ConeAngle);
}

float CTaObject::GetLightPenumbraAngle()const
{
	return PmGetLightPenumbraAngle(this);
}

void CTaObject::SetLightPenumbraAngle(float PenumbraAngle)
{
	PmSetLightPenumbraAngle(this, PenumbraAngle);
}

float CTaObject::GetLightFalloff()const
{
	return PmGetLightFalloff(this);
}

void CTaObject::SetLightFalloff(float Falloff)
{
	PmSetLightFalloff(this, Falloff);
}

//�����f���p���\�b�h

UINT CTaObject::GetModelMaterialCount()const
{
	return PmGetModelMaterialCount(this);
}

void CTaObject::UpdateModelMaterialIndices()
{
	PmUpdateModelMaterialIndices(this);
}

BOOL CTaObject::GetModelMaterials(CTaMaterial* pMaterials[])const
{
	return PmGetModelMaterials(this, pMaterials);
}

CTaMaterial* CTaObject::GetModelMaterial(UINT nIndex)const
{
	return PmGetModelMaterial(this, nIndex);
}

UINT CTaObject::GetModelMaterialIndex(const CTaMaterial* pMaterial)const
{
	return PmGetModelMaterialIndex(this, pMaterial);
}

CTaMaterial* CTaObject::GetModelCurMaterial()const
{
	return PmGetModelCurMaterial(this);
}

void CTaObject::SetModelCurMaterial(CTaMaterial* pMaterial)
{
	PmSetModelCurMaterial(this, pMaterial);
}

void CTaObject::AddModelMaterial(CTaMaterial* pMaterial)
{
	PmAddModelMaterial(this, pMaterial);
}

BOOL CTaObject::InsertModelMaterial(UINT nIndex, CTaMaterial* pMaterial)
{
	return PmInsertModelMaterial(this, nIndex, pMaterial);
}

BOOL CTaObject::DeleteModelMaterial(CTaMaterial* pMaterial)
{
	return PmDeleteModelMaterial(this, pMaterial);
}

BOOL CTaObject::DeleteAllModelMaterials()
{
	return PmDeleteAllModelMaterials(this);
}

UINT CTaObject::GetModelAnimCount()const
{
	return PmGetModelAnimCount(this);
}

void CTaObject::UpdateModelAnimIndices()
{
	PmUpdateModelAnimIndices(this);
}

BOOL CTaObject::GetModelAnims(CTaAnim* pAnims[])const
{
	return PmGetModelAnims(this, pAnims);
}

CTaAnim* CTaObject::GetModelAnim(UINT nIndex)const
{
	return PmGetModelAnim(this, nIndex);
}

UINT CTaObject::GetModelAnimIndex(const CTaAnim* pAnim)const
{
	return PmGetModelAnimIndex(this, pAnim);
}

CTaAnim* CTaObject::GetModelCurAnim()const
{
	return PmGetModelCurAnim(this);
}

void CTaObject::SetModelCurAnim(CTaAnim* pAnim)
{
	PmSetModelCurAnim(this, pAnim);
}

void CTaObject::AddModelAnim(CTaAnim* pAnim)
{
	PmAddModelAnim(this, pAnim);
}

BOOL CTaObject::InsertModelAnim(UINT nIndex, CTaAnim* pAnim)
{
	return PmInsertModelAnim(this, nIndex, pAnim);
}

//���V�[�� �N���X

CTaObject* CTaScene::GetRootModel()const
{
	return PmGetSceneRootObject(this);
}

//���A�j���[�V���� �N���X

LPCTSTR CTaAnim::GetName()const
{
	return PmGetAnimName(this);
}

void CTaAnim::SetName(LPCTSTR pszName)
{
	PmSetAnimName(this, pszName);
}

UINT CTaAnim::GetIndex()const
{
	return PmGetAnimIndex(this);
}

void CTaAnim::SetIndex(UINT nIndex)
{
	PmSetAnimIndex(this, nIndex);
}

float CTaAnim::GetFps()const
{
	return PmGetAnimFps(this);
}

BOOL CTaAnim::SetFps(float Fps)
{
	return PmSetAnimFps(this, Fps);
}

float CTaAnim::GetCurFrame()const
{
	return PmGetAnimCurFrame(this);
}

void CTaAnim::SetCurFrame(float Frame)
{
	PmSetAnimCurFrame(this, Frame);
}

float CTaAnim::GetFirstFrame()const
{
	return PmGetAnimFirstFrame(this);
}

BOOL CTaAnim::SetFirstFrame(float Frame)
{
	return PmSetAnimFirstFrame(this, Frame);
}

float CTaAnim::GetLastFrame()const
{
	return PmGetAnimLastFrame(this);
}

BOOL CTaAnim::SetLastFrame(float Frame)
{
	return PmSetAnimLastFrame(this, Frame);
}

BOOL CTaAnim::IsObjectItemEmpty(CTaObject* pObject)const
{
	return PmIsObjectAnimItemEmpty(this, pObject);
}

CTaAnimItem* CTaAnim::GetObjectItem(TA_ANIM_ITEM_TYPE Type, CTaObject* pObject)const
{
	return PmGetObjectAnimItem(this, Type, pObject);
}

BOOL CTaAnim::AnimateObjectItem(TA_ANIM_ITEM_TYPE Type, CTaObject* pObject, float Frame)const
{
	//�A�C�e�����Ȃ��ꍇ
	CTaAnimItem* pItem = GetObjectItem(Type, pObject);
	if(!pItem)
		return FALSE;

	//�A�j���[�V�����̎��s
	return pItem->Animate(Frame);
}

BOOL CTaAnim::AnimateObjectItems(CTaObject* pObject, float Frame)const
{
	return PmAnimateObjectAnimItems(this, pObject, Frame, FALSE);
}

CTaAnimItem* CTaAnim::CreateObjectItem(TA_ANIM_ITEM_TYPE Type, CTaObject* pObject)
{
	return PmCreateObjectAnimItem(this, Type, pObject);
}

BOOL CTaAnim::DeleteObjectItem(TA_ANIM_ITEM_TYPE Type, CTaObject* pObject)
{
	return PmDeleteObjectAnimItem(this, Type, pObject);
}

BOOL CTaAnim::DeleteObjectItems(CTaObject* pObject)
{
	return PmDeleteObjectAnimItems(this, pObject);
}

BOOL CTaAnim::DeleteObjectItems()
{
	return PmDeleteAllObjectAnimItems(this);
}

void CTaAnim::CleanUpObjectItems()
{
	PmCleanUpObjectAnimItems(this);
}

void CTaAnim::ClearItems()
{
	PmClearAnimItems(this);
}

BOOL CTaAnim::GetConstrainedObjectItems(CTaAnim* pAnim, float FrameStep, BOOL bAttachIKHandle)const
{
	return PmGetConstrainedObjectAnimItems(this, pAnim, FrameStep, bAttachIKHandle); 
}

//���A�j���[�V���� �o�����[ �N���X

BOOL CTaAnimValues::StoreObjectValues(const CTaAnim* pAnim, const CTaObject* pObject)
{
	return PmStoreAnimValuesObjectValues(this, pAnim, pObject);
}

BOOL CTaAnimValues::Restore(const CTaAnim* pAnim)const
{
	return PmRestoreAnimValues(this, pAnim);
}

void CTaAnimValues::Clear()
{
	PmClearAnimValues(this);
}

//���A�j���[�V���� �A�C�e�� �N���X

BOOL CTaAnimItem::Animate(float Frame)const
{
	return PmAnimateAnimItem(this, Frame, FALSE);
}

UINT CTaAnimItem::GetKeyFrameCount()const
{
	return PmGetAnimItemKeyFrameCount(this);
}

BOOL CTaAnimItem::GetKeyFrame(UINT nIndex, float* pFrame, float* pValue,
								  TA_TAN_TYPE* pLeftTanType, TA_TAN_TYPE* pRightTanType, float* pLeftTan, float* pRightTan, BOOL* pTanSeparated)const
{
	return PmGetAnimItemKeyFrame(this, nIndex, pFrame, pValue, (UINT*)pLeftTanType, (UINT*)pRightTanType, pLeftTan, pRightTan, pTanSeparated);
}

BOOL CTaAnimItem::SetKeyFrame(UINT nIndex, const float* pValue, const TA_TAN_TYPE* pLeftTanType, const TA_TAN_TYPE* pRightTanType,
							const float* pLeftTan, const float* pRightTan, const BOOL* pTanSeparated, BOOL bUpdateSpline)
{
	return PmSetAnimItemKeyFrame(this, nIndex, pValue, (const UINT*)pLeftTanType, (const UINT*)pRightTanType, pLeftTan, pRightTan, pTanSeparated, bUpdateSpline);
}

void CTaAnimItem::InsertKeyFrame(float Frame, float Value, const TA_TAN_TYPE* pLeftTanType, const TA_TAN_TYPE* pRightTanType, 
								const float* pLeftTan, const float* pRightTan, const BOOL* pTanSeparated, BOOL bUpdateSpline)
{
	PmInsertAnimItemKeyFrame(this, Frame, Value, (const UINT*)pLeftTanType, (const UINT*)pRightTanType, pLeftTan, pRightTan, pTanSeparated, bUpdateSpline);
}

BOOL CTaAnimItem::DeleteKeyFrame(UINT nIndex, BOOL bUpdateSpline)
{
	return PmDeleteAnimItemKeyFrame(this, nIndex, bUpdateSpline);
}

void CTaAnimItem::DeleteKeyFrames()
{
	PmDeleteAnimItemKeyFrames(this);
}

void CTaAnimItem::UpdateSpline()
{
	PmUpdateAnimItemSpline(this);
}

