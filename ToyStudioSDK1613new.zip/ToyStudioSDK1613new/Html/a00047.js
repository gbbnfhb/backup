var a00047 =
[
    [ "TaGetImportFileExt", "a00047.htm#gaad9411127d29f61eebb854ab44afd55b", null ],
    [ "TaGetImportFileType", "a00047.htm#ga2225dacc4af0cce5819a974d525bb33b", null ],
    [ "TaGetImportFileTypeCount", "a00047.htm#ga0ef3d853d1462c8f8f2fb3af851ea90c", null ],
    [ "TaImportFile", "a00047.htm#gadc9f60e919603af0158018ffbfcf4989", null ]
];