var a00048 =
[
    [ "TaExportFile", "a00048.htm#gae0a007af9cdbb8c7fb873e71384a423b", null ],
    [ "TaGetExportFileExt", "a00048.htm#ga851be23f9bacabf48ea77e1b84faf04b", null ],
    [ "TaGetExportFileType", "a00048.htm#gaa02df85ec21cbac0f4577e3e4d2d83da", null ],
    [ "TaGetExportFileTypeCount", "a00048.htm#gada672a76e9bcfdc11dfbec108eb5e3bf", null ]
];