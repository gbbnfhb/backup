var a00011 =
[
    [ "階層構造", "a00012.htm", [
      [ "子オブジェクトの取得", "a00012.htm#GetChild", null ],
      [ "マテリアルの取得", "a00012.htm#GetMaterial", null ],
      [ "アニメーションの取得", "a00012.htm#GetAnim", null ]
    ] ],
    [ "座標変換", "a00013.htm", [
      [ "座標系", "a00013.htm#Coordinates", null ],
      [ "ベクトル、行列の形式", "a00013.htm#VectorMatrix", null ],
      [ "ローカル変換行列", "a00013.htm#LocalTransform", null ],
      [ "ワールド変換行列", "a00013.htm#WorldTransform", null ]
    ] ],
    [ "ポリゴン", "a00014.htm", [
      [ "頂点", "a00014.htm#Vertex", null ],
      [ "面", "a00014.htm#Face", null ],
      [ "ポリゴンの追加", "a00014.htm#AddPolygon", null ]
    ] ],
    [ "スキニング", "a00015.htm", [
      [ "スキニングとは", "a00015.htm#AboutSkinning", null ],
      [ "スキニング用のデータ", "a00015.htm#SkinningData", null ],
      [ "ボーン行列", "a00015.htm#SkinningTransform", null ],
      [ "スキニング処理", "a00015.htm#SkinningProcessing", null ]
    ] ],
    [ "アニメーション", "a00016.htm", [
      [ "キー フレームとは", "a00016.htm#KeyFrame", null ],
      [ "フレーム レートとは", "a00016.htm#FrameRate", null ],
      [ "アニメーション アイテム", "a00016.htm#AnimItem", null ],
      [ "キー フレームの追加", "a00016.htm#AddKeyFrame", null ],
      [ "指定フレームでアニメーション", "a00016.htm#Animate", null ],
      [ "IKハンドルのアニメーション", "a00016.htm#AnimateIKHandle", null ]
    ] ]
];