var a00046 =
[
    [ "TaGetManufacturerName", "a00046.htm#ga0fa0e887bb3b8dc74af79d0490564473", null ],
    [ "TaGetPluginElements", "a00046.htm#gade01a40cf431cacde09a545f733de6c9", null ],
    [ "TaGetProductName", "a00046.htm#ga72fa74099a962e90950ff91e5a49bbb2", null ],
    [ "TaGetProductVersion", "a00046.htm#ga0ffaba45ec3f2ef5c05d9a8ddaa1f248", null ],
    [ "TaGetSdkVersion", "a00046.htm#ga38ed34edd08213b3c6a768944d65c8fb", null ],
    [ "TaInitPlugin", "a00046.htm#gaac40fd6dc97a46771f8cef050bcd6c90", null ]
];