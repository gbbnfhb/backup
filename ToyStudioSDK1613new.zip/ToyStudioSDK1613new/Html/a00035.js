var a00035 =
[
    [ "TA_ARGB", "a00035.htm#ga5c5acc0b43a092cc081a4c93765b1925", null ],
    [ "TA_GET_A", "a00035.htm#gab4b2fd8861e0db8439e337207131ec3c", null ],
    [ "TA_GET_B", "a00035.htm#ga6d89c1bd963c99632cbcfc512e59678f", null ],
    [ "TA_GET_G", "a00035.htm#ga097989a18e973d3d66f5e16c828a5b28", null ],
    [ "TA_GET_R", "a00035.htm#gacd3a5860b8a71e647bef3cacb51904e4", null ],
    [ "TA_MAX_VERTEX_BONE_COUNT", "a00035.htm#ga9e480dce66ec71d0ef6e15071ea45eaa", null ],
    [ "TA_PI", "a00035.htm#ga27e02bc18146e933dba5d41f5a7095b8", null ],
    [ "TA_PLUGIN_EXPORT", "a00035.htm#gaa64c0113fb01b992120a1d8c6784c297", null ],
    [ "TA_SDK_VERSION_LS", "a00035.htm#ga3e334aa9ec1305e38fff3ea23f009461", null ],
    [ "TA_SDK_VERSION_MS", "a00035.htm#gadad1e41c29011613d7fbc009c1ff83ad", null ],
    [ "TA_TO_DEGREE", "a00035.htm#ga9f351a3148185a863e0345f0e7482885", null ],
    [ "TA_TO_RADIAN", "a00035.htm#gacefd7072c575c4d9c33732aac88412b3", null ],
    [ "TA_COLOR", "a00035.htm#ga0cd23958848c32a78d08d7cc91e3d3b7", null ],
    [ "TA_ALPHA_OP_TYPE", "a00035.htm#ga3557c00b76ac7f674c9030774d1de93b", [
      [ "TA_ALPHA_OP_DISABLE", "a00035.htm#gga3557c00b76ac7f674c9030774d1de93ba20f1493900b15863268de1b7020db232", null ],
      [ "TA_ALPHA_OP_CURRENT", "a00035.htm#gga3557c00b76ac7f674c9030774d1de93babd52e2f369078441104c3a573dfefd42", null ],
      [ "TA_ALPHA_OP_TEXTURE", "a00035.htm#gga3557c00b76ac7f674c9030774d1de93ba086c8c55d45590ec8d7ea9c3f4534757", null ],
      [ "TA_ALPHA_OP_MODULATE", "a00035.htm#gga3557c00b76ac7f674c9030774d1de93ba443fb9c39fbf4fc3ca6ae4e4240f82d0", null ],
      [ "TA_ALPHA_OP_MODULATE2X", "a00035.htm#gga3557c00b76ac7f674c9030774d1de93ba4609d3be3ac82eb7b4fa9c4ae37eed92", null ],
      [ "TA_ALPHA_OP_MODULATE4X", "a00035.htm#gga3557c00b76ac7f674c9030774d1de93ba972df97ff1afeb5551d44e0fd034470a", null ],
      [ "TA_ALPHA_OP_ADD", "a00035.htm#gga3557c00b76ac7f674c9030774d1de93bae4fd58ee80bf1c4f298d66b483fe01e2", null ],
      [ "TA_ALPHA_OP_SUBTRACT_CURRENT", "a00035.htm#gga3557c00b76ac7f674c9030774d1de93ba0e18479f64e3b3f74155ea7dff875698", null ],
      [ "TA_ALPHA_OP_SUBTRACT_TEXTURE", "a00035.htm#gga3557c00b76ac7f674c9030774d1de93ba82ad9c91ed13d2a15fbf08712ab6dfbe", null ]
    ] ],
    [ "TA_ANIM_ITEM_TYPE", "a00035.htm#ga1ee8f5f6f15812cce353eabf4fac8b2b", [
      [ "TA_ANIM_ITEM_NONE", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba3a0e936417ce8682af7320a6c21aab1a", null ],
      [ "TA_ANIM_ITEM_SCALE_X", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba75093c3406ac3032674059a3e093bde0", null ],
      [ "TA_ANIM_ITEM_SCALE_Y", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba498b8ecebdf892af717df6e828dba2d4", null ],
      [ "TA_ANIM_ITEM_SCALE_Z", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba0d2ee6e61dd9a40a036250e734f24f9c", null ],
      [ "TA_ANIM_ITEM_ROTATE_X", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2bacf2a873e005f6f8d7b4c91e16571fb24", null ],
      [ "TA_ANIM_ITEM_ROTATE_Y", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba9c622119e604b6f169011a537efee900", null ],
      [ "TA_ANIM_ITEM_ROTATE_Z", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba924283fc7232660298e95ea18217f533", null ],
      [ "TA_ANIM_ITEM_TRANSLATE_X", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba619a0b4b2934fae6eef1a233b2a1e08c", null ],
      [ "TA_ANIM_ITEM_TRANSLATE_Y", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba9bebc119213ad14a22958ce8985894b7", null ],
      [ "TA_ANIM_ITEM_TRANSLATE_Z", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba22f06f53d29627c518d8e94e470ff11e", null ],
      [ "TA_ANIM_ITEM_PIVOT_X", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba014d2c0c611341757f91dfbe2c6858db", null ],
      [ "TA_ANIM_ITEM_PIVOT_Y", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba4c40508f0142f42161a3779a4d2ab9a2", null ],
      [ "TA_ANIM_ITEM_PIVOT_Z", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba970e74bb58d1978c9db3ccea4496b85b", null ],
      [ "TA_ANIM_ITEM_SHEAR_X", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba4f3ab88f5357f0adebc7279e92be5799", null ],
      [ "TA_ANIM_ITEM_SHEAR_Y", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba60d5920554c5860b6d1160578dbaf9cd", null ],
      [ "TA_ANIM_ITEM_SHEAR_Z", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2ba188c4881bf76b04f061028bc522fe04a", null ],
      [ "TA_ANIM_ITEM_VISIBLE", "a00035.htm#gga1ee8f5f6f15812cce353eabf4fac8b2bad2ea970a245dd40ac068ab77b7737442", null ]
    ] ],
    [ "TA_COLOR_OP_TYPE", "a00035.htm#ga2abca45adda394674dfc02dc52cbabf9", [
      [ "TA_COLOR_OP_DISABLE", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9a2b9282bd884edfb71c6a2ded3d9b5d19", null ],
      [ "TA_COLOR_OP_CURRENT", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9a478b41ffadc128f7532a3b114b4fc708", null ],
      [ "TA_COLOR_OP_TEXTURE", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9aa594ecb07ea9a1bf01a1c6a0e04f8cb7", null ],
      [ "TA_COLOR_OP_MODULATE", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9a43bbd57fa7ef18b7e44b6f7923f5b656", null ],
      [ "TA_COLOR_OP_MODULATE2X", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9ae37c7fe3a913cdde00bd6686fb78e06d", null ],
      [ "TA_COLOR_OP_MODULATE4X", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9a8de8d66d38da1a92da75f81ec236e435", null ],
      [ "TA_COLOR_OP_ADD", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9a6df4267154e8195348728052e8b0b185", null ],
      [ "TA_COLOR_OP_SUBTRACT_CURRENT", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9acf3d91cf798de3581b559b60a30e1426", null ],
      [ "TA_COLOR_OP_SUBTRACT_TEXTURE", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9a7b829c42d5d60132e80dbf8e3526b64b", null ],
      [ "TA_COLOR_OP_CURRENT_ALPHA_CURRENT", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9a5830b0704e50cd2a5970eba8bc459768", null ],
      [ "TA_COLOR_OP_CURRENT_ALPHA_TEXTURE", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9a77107c1da27392f02118b034e57d9ac3", null ],
      [ "TA_COLOR_OP_TEXTURE_ALPHA_CURRENT", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9ae80e00ad7e5e433027a17b1bcc82ff63", null ],
      [ "TA_COLOR_OP_TEXTURE_ALPHA_TEXTURE", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9aeaf059227c6c5996766c8b834993689a", null ],
      [ "TA_COLOR_OP_BUMP", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9a88c2fecc9e69b0b5b2943c268653311a", null ],
      [ "TA_COLOR_OP_BUMP_LUMINANCE", "a00035.htm#gga2abca45adda394674dfc02dc52cbabf9a8ca2450341d64e798bef2cfcfa098cfa", null ]
    ] ],
    [ "TA_DECAY_TYPE", "a00035.htm#gade2d0114918e8244c33b1ea1a1c3e9b4", [
      [ "TA_DECAY_NONE", "a00035.htm#ggade2d0114918e8244c33b1ea1a1c3e9b4a2c8dee4df3211bb1cc96d451e845d7af", null ],
      [ "TA_DECAY_LINEAR", "a00035.htm#ggade2d0114918e8244c33b1ea1a1c3e9b4a6824fa89010541b86733b661be922be3", null ],
      [ "TA_DECAY_QUADRATIC", "a00035.htm#ggade2d0114918e8244c33b1ea1a1c3e9b4ab6b11cbb2d9a58cdb29570b034a3feb1", null ]
    ] ],
    [ "TA_EULER_ORDER_TYPE", "a00035.htm#gae0744043ca7728fb8b7696e30ec511a8", [
      [ "TA_EULER_ORDER_XYZ", "a00035.htm#ggae0744043ca7728fb8b7696e30ec511a8ac56bdc4f52847e4e77d82989d69b8f2d", null ],
      [ "TA_EULER_ORDER_XZY", "a00035.htm#ggae0744043ca7728fb8b7696e30ec511a8ac0feaa734f147b3e7c8da945579598b3", null ],
      [ "TA_EULER_ORDER_YXZ", "a00035.htm#ggae0744043ca7728fb8b7696e30ec511a8a2aa63c1be65228f990ccf71b1b3a79b6", null ],
      [ "TA_EULER_ORDER_YZX", "a00035.htm#ggae0744043ca7728fb8b7696e30ec511a8a2379421f18eec216b74f984d22537b33", null ],
      [ "TA_EULER_ORDER_ZXY", "a00035.htm#ggae0744043ca7728fb8b7696e30ec511a8a052956fdb21472af019be9f79de44510", null ],
      [ "TA_EULER_ORDER_ZYX", "a00035.htm#ggae0744043ca7728fb8b7696e30ec511a8a43c87ece8652528be0619a164134ba99", null ]
    ] ],
    [ "TA_LIGHT_TYPE", "a00035.htm#gaefdd9596a06dc8a76ba312d7b95f1ee5", [
      [ "TA_LIGHT_DIRECTIONAL", "a00035.htm#ggaefdd9596a06dc8a76ba312d7b95f1ee5ad1ebddd5a325de7c498e1181fb37c4f9", null ],
      [ "TA_LIGHT_POINT", "a00035.htm#ggaefdd9596a06dc8a76ba312d7b95f1ee5a93c7c08d6c5d035712d7035e70e467ac", null ],
      [ "TA_LIGHT_SPOT", "a00035.htm#ggaefdd9596a06dc8a76ba312d7b95f1ee5ac822d75935e2df5c802678057fd1f048", null ]
    ] ],
    [ "TA_OBJECT_TYPE", "a00035.htm#ga1ce1b26362319155d287895bdf0679ff", [
      [ "TA_OBJECT_NONE", "a00035.htm#gga1ce1b26362319155d287895bdf0679ffa928e09fbbdf750215aa8ed27cdba0381", null ],
      [ "TA_OBJECT_MESH", "a00035.htm#gga1ce1b26362319155d287895bdf0679ffa8e7ddc9034ccca8c4c107a6f90b6e407", null ],
      [ "TA_OBJECT_GROUP", "a00035.htm#gga1ce1b26362319155d287895bdf0679ffa0c039027c6094e0973644d1b6caa037e", null ],
      [ "TA_OBJECT_MODEL", "a00035.htm#gga1ce1b26362319155d287895bdf0679ffaffb4a5c57832a6205b59c8b599374b94", null ],
      [ "TA_OBJECT_NULL", "a00035.htm#gga1ce1b26362319155d287895bdf0679ffa707e5a3af0ca80fe29dca5992007e122", null ],
      [ "TA_OBJECT_JOINT", "a00035.htm#gga1ce1b26362319155d287895bdf0679ffa8a28507064e84491630c31e2fe62d27a", null ],
      [ "TA_OBJECT_CAMERA", "a00035.htm#gga1ce1b26362319155d287895bdf0679ffa9208b2c6bbf2986c643d218129cfb73c", null ],
      [ "TA_OBJECT_IK_HANDLE", "a00035.htm#gga1ce1b26362319155d287895bdf0679ffa12827a977dcbb804ce88293a382a03a9", null ],
      [ "TA_OBJECT_LIGHT", "a00035.htm#gga1ce1b26362319155d287895bdf0679ffa26e169e92bb290c955162c5bdfc6fce0", null ]
    ] ],
    [ "TA_PLUGIN_ELEMENT_TYPE", "a00035.htm#gafb24dacaa6afe1915d16eac00012deff", [
      [ "TA_PLUGIN_ELEMENT_IMPORT", "a00035.htm#ggafb24dacaa6afe1915d16eac00012deffac87e0aca426d0fe4111716619b535d18", null ],
      [ "TA_PLUGIN_ELEMENT_EXPORT", "a00035.htm#ggafb24dacaa6afe1915d16eac00012deffaa2f483e75855a41e6a028ea46547ce44", null ]
    ] ],
    [ "TA_PROJECTION_TYPE", "a00035.htm#gabeedb98596e227a442d8a6ad6ff4e78d", [
      [ "TA_PROJECTION_PERSPECTIVE", "a00035.htm#ggabeedb98596e227a442d8a6ad6ff4e78dacca3a381ed4848d83ef47a4ae9bb2f19", null ],
      [ "TA_PROJECTION_ORTHO", "a00035.htm#ggabeedb98596e227a442d8a6ad6ff4e78da22cf2fbbc063097be850b87d6f151f16", null ]
    ] ],
    [ "TA_TAN_TYPE", "a00035.htm#gae8e1403597eec29655a4ecca2623e727", [
      [ "TA_TAN_SPLINE", "a00035.htm#ggae8e1403597eec29655a4ecca2623e727ab242faeb469b137562cc1ea8353968e9", null ],
      [ "TA_TAN_LINEAR", "a00035.htm#ggae8e1403597eec29655a4ecca2623e727a8de5070cc1b304db0add9500fc831391", null ],
      [ "TA_TAN_SPECIFIED", "a00035.htm#ggae8e1403597eec29655a4ecca2623e727acdbfc478897ce7b26faebc9af4de02d4", null ],
      [ "TA_TAN_STEP", "a00035.htm#ggae8e1403597eec29655a4ecca2623e727a94b362bf9f43f0effd00e8892aca4cd1", null ],
      [ "TA_TAN_STEP_NEXT", "a00035.htm#ggae8e1403597eec29655a4ecca2623e727afbf10c6d2876da9bc379c68fb756bc8a", null ]
    ] ]
];