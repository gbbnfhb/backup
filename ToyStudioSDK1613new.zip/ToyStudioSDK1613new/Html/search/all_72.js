var searchData=
[
  ['r',['r',['../a00028.htm#a164ce50560bb46add017057879bc1ff5',1,'TA_VECTOR::r()'],['../a00027.htm#ae0cb1bc9830ebe02671a4f174c889e52',1,'TA_QUAT::r()']]],
  ['reloadtexture',['ReloadTexture',['../a00023.htm#a1e8f6d22b29656573b57cbeafceabd56',1,'CTaMaterial']]],
  ['removechild',['RemoveChild',['../a00024.htm#a899239a2856cdb3ea7024db35996cb6d',1,'CTaObject']]],
  ['restore',['Restore',['../a00022.htm#ad4fcbe66d52cd211bab4ee07f79a290d',1,'CTaAnimValues']]]
];
