var searchData=
[
  ['operator_20const_20float_20_2a',['operator const float *',['../a00028.htm#aaf6e1ed62e4cbd65d05896ba100aaafc',1,'TA_VECTOR::operator const float *()'],['../a00029.htm#a39fcb1ca9f01bd107248bc165f4f6059',1,'TA_VECTOR_2D::operator const float *()'],['../a00027.htm#afa7298ed222d3dc2a36ca994a3bd8b37',1,'TA_QUAT::operator const float *()'],['../a00026.htm#a5b4fd1bb20df3a17b95480d4fd4eb7a7',1,'TA_MATRIX::operator const float *()']]],
  ['operator_20float_20_2a',['operator float *',['../a00028.htm#a2061d263ca3ea116aa5ffd5675d7972c',1,'TA_VECTOR::operator float *()'],['../a00029.htm#a8245a46a06485aaee3e1b70a8f507fe5',1,'TA_VECTOR_2D::operator float *()'],['../a00027.htm#a235a121ab2058b34e93b901c66ee01a4',1,'TA_QUAT::operator float *()'],['../a00026.htm#a1fe90e3b3448b9db61b098a5899f8126',1,'TA_MATRIX::operator float *()']]]
];
