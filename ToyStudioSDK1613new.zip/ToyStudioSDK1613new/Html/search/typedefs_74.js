var searchData=
[
  ['ta_5fcolor',['TA_COLOR',['../a00041.htm#ga0cd23958848c32a78d08d7cc91e3d3b7',1,'TaLibSymbol.h']]]
];
