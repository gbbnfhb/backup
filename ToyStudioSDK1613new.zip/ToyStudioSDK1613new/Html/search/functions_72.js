var searchData=
[
  ['reloadtexture',['ReloadTexture',['../a00023.htm#a1e8f6d22b29656573b57cbeafceabd56',1,'CTaMaterial']]],
  ['removechild',['RemoveChild',['../a00024.htm#a899239a2856cdb3ea7024db35996cb6d',1,'CTaObject']]],
  ['restore',['Restore',['../a00022.htm#ad4fcbe66d52cd211bab4ee07f79a290d',1,'CTaAnimValues']]]
];
