var searchData=
[
  ['hasfacevertexuv',['HasFaceVertexUV',['../a00024.htm#a021382f2f5dd75c96e08651f4da809cd',1,'CTaObject']]],
  ['hasvertexbone',['HasVertexBone',['../a00024.htm#ab79889b41524743a1ebcc062f7a23e80',1,'CTaObject']]]
];
