var searchData=
[
  ['r',['r',['../a00028.htm#a164ce50560bb46add017057879bc1ff5',1,'TA_VECTOR::r()'],['../a00027.htm#ae0cb1bc9830ebe02671a4f174c889e52',1,'TA_QUAT::r()']]]
];
