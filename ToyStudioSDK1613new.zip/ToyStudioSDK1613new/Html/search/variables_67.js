var searchData=
[
  ['g',['g',['../a00028.htm#ad9be512de7c6d9452fc92a244eff09a8',1,'TA_VECTOR::g()'],['../a00027.htm#ae78415b90b45db3d7e9a1a1a39e447ac',1,'TA_QUAT::g()']]]
];
