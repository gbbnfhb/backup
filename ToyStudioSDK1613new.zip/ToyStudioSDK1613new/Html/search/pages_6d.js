var searchData=
[
  ['myplugin',['MyPlugin',['../a00019.htm',1,'Samples']]]
];
