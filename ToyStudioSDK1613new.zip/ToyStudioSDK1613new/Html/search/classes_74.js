var searchData=
[
  ['ta_5fmatrix',['TA_MATRIX',['../a00026.htm',1,'']]],
  ['ta_5fquat',['TA_QUAT',['../a00027.htm',1,'']]],
  ['ta_5fvector',['TA_VECTOR',['../a00028.htm',1,'']]],
  ['ta_5fvector_5f2d',['TA_VECTOR_2D',['../a00029.htm',1,'']]]
];
