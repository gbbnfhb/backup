var searchData=
[
  ['use_5fexport_5ffunc',['USE_EXPORT_FUNC',['../a00038.htm#aa896f5e9afafa1a9f2c39a3e87c25af7',1,'TaPlugin.h']]],
  ['use_5fimport_5ffunc',['USE_IMPORT_FUNC',['../a00038.htm#a0af5df7b43e38ba0f2d7be671d7ce8df',1,'TaPlugin.h']]]
];
