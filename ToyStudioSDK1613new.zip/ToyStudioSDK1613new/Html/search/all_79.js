var searchData=
[
  ['y',['y',['../a00028.htm#a7289517c1c4d73df345aa33e5d659afe',1,'TA_VECTOR::y()'],['../a00029.htm#a952ce4998e24ea7984f3ec2376f19197',1,'TA_VECTOR_2D::y()'],['../a00027.htm#a921c4275c0735a429cb500876c808ec0',1,'TA_QUAT::y()']]]
];
