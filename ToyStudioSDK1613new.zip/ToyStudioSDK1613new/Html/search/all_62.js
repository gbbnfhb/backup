var searchData=
[
  ['b',['b',['../a00028.htm#ad815075291d6d582b4e294377715c929',1,'TA_VECTOR::b()'],['../a00027.htm#a47d12bc2384ecf117b0553e09282ef95',1,'TA_QUAT::b()']]]
];
