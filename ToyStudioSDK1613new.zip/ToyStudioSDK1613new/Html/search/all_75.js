var searchData=
[
  ['u',['u',['../a00029.htm#aa7efd775dca8069a4aa31161e4ae611b',1,'TA_VECTOR_2D']]],
  ['updateboundbox',['UpdateBoundBox',['../a00024.htm#a4d0bc45aeb7647d3477cf953d933032b',1,'CTaObject']]],
  ['updategeometry',['UpdateGeometry',['../a00024.htm#a0c7ca1b7374e5105f6fb045a5e8aaea2',1,'CTaObject']]],
  ['updategraphics',['UpdateGraphics',['../a00024.htm#a8a6f20f3f87df376c95604cfa2a72a30',1,'CTaObject']]],
  ['updatemeshnormals',['UpdateMeshNormals',['../a00024.htm#a9b3cb566f747efa1a29713d60ec618e6',1,'CTaObject']]],
  ['updatemeshtopology',['UpdateMeshTopology',['../a00024.htm#a371127171aff8e567700b6bea733256f',1,'CTaObject']]],
  ['updatemodelanimindices',['UpdateModelAnimIndices',['../a00024.htm#a7ef037fcfa404fd667b1fcdae3718d08',1,'CTaObject']]],
  ['updatemodelmaterialindices',['UpdateModelMaterialIndices',['../a00024.htm#a9dd93f6d988e0393628a68037f392a9b',1,'CTaObject']]],
  ['updatespline',['UpdateSpline',['../a00021.htm#aed78db543ce8fe99c8f707520aea80f4',1,'CTaAnimItem']]],
  ['use_5fexport_5ffunc',['USE_EXPORT_FUNC',['../a00038.htm#aa896f5e9afafa1a9f2c39a3e87c25af7',1,'TaPlugin.h']]],
  ['use_5fimport_5ffunc',['USE_IMPORT_FUNC',['../a00038.htm#a0af5df7b43e38ba0f2d7be671d7ce8df',1,'TaPlugin.h']]]
];
