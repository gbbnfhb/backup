var a00038 =
[
    [ "USE_EXPORT_FUNC", "a00038.htm#aa896f5e9afafa1a9f2c39a3e87c25af7", null ],
    [ "USE_IMPORT_FUNC", "a00038.htm#a0af5df7b43e38ba0f2d7be671d7ce8df", null ],
    [ "TaExportFile", "a00038.htm#gae0a007af9cdbb8c7fb873e71384a423b", null ],
    [ "TaGetExportFileExt", "a00038.htm#ga851be23f9bacabf48ea77e1b84faf04b", null ],
    [ "TaGetExportFileType", "a00038.htm#gaa02df85ec21cbac0f4577e3e4d2d83da", null ],
    [ "TaGetExportFileTypeCount", "a00038.htm#gada672a76e9bcfdc11dfbec108eb5e3bf", null ],
    [ "TaGetImportFileExt", "a00038.htm#gaad9411127d29f61eebb854ab44afd55b", null ],
    [ "TaGetImportFileType", "a00038.htm#ga2225dacc4af0cce5819a974d525bb33b", null ],
    [ "TaGetImportFileTypeCount", "a00038.htm#ga0ef3d853d1462c8f8f2fb3af851ea90c", null ],
    [ "TaGetManufacturerName", "a00038.htm#ga0fa0e887bb3b8dc74af79d0490564473", null ],
    [ "TaGetPluginElements", "a00038.htm#gade01a40cf431cacde09a545f733de6c9", null ],
    [ "TaGetProductName", "a00038.htm#ga72fa74099a962e90950ff91e5a49bbb2", null ],
    [ "TaGetProductVersion", "a00038.htm#ga0ffaba45ec3f2ef5c05d9a8ddaa1f248", null ],
    [ "TaGetSdkVersion", "a00038.htm#ga38ed34edd08213b3c6a768944d65c8fb", null ],
    [ "TaImportFile", "a00038.htm#gadc9f60e919603af0158018ffbfcf4989", null ],
    [ "TaInitPlugin", "a00038.htm#gaac40fd6dc97a46771f8cef050bcd6c90", null ]
];