var a00034 =
[
    [ "TaCreateAnim", "a00034.htm#ga1d8431754fe103b7ba9cd10919f1bcfc", null ],
    [ "TaCreateAnimValues", "a00034.htm#gaff75438edb4d8ba279571aed8251628d", null ],
    [ "TaCreateMaterial", "a00034.htm#ga6c6814721e6746a9d3b35ba2afe39714", null ],
    [ "TaCreateObject", "a00034.htm#gac7058e5a383be5c38ee9ccd0363fe1c8", null ],
    [ "TaDeleteAnim", "a00034.htm#ga99b12abff7e4e134b67a32dadedac47f", null ],
    [ "TaDeleteAnimValues", "a00034.htm#ga4571670ef46538b94176a50904802e4d", null ],
    [ "TaDeleteMaterial", "a00034.htm#ga3476c3355580604c06900174872a795b", null ],
    [ "TaDeleteObject", "a00034.htm#gaa7fba6441261e56f1e75173b48aeacc4", null ],
    [ "TaInitLib", "a00034.htm#gadd6a0c6e292bde6e13b151210bd2349b", null ]
];