Texture2D txDiffuse : register( t0 );
SamplerState samLinear : register( s0 );

#include "cb_main.h"


struct VS_INPUT
{
	float4 Pos : POSITION;
	float2 Tex : TEXCOORD;
	float4 Col : COLOR;
};

struct PS_INPUT
{
	float4 Pos : SV_POSITION;
	float2 Tex : TEXCOORD;
	float4 Col : COLOR;
};


//-------------------------
//�{�[���ό`�����_�u�����h
PS_INPUT vsMain( VS_INPUT input)
{
	PS_INPUT output = (PS_INPUT)0;
	output.Pos = input.Pos;
	output.Tex = input.Tex;
	output.Col = input.Col;
	return output;
}

//-------------------------
//�s�N�Z���V�F�[�_
float4 psMain( PS_INPUT input ) : SV_Target
{
	return float4(0,0,0,0.2);//input.Col;//*txDiffuse.Sample( samLinear, input.Tex);
}

//-------------------------
//�V�F�[�_�G�t�F�N�g��`
#ifdef ZGFX

	technique Basic
	{
		pass P0
		{
			CullMode = NONE;
			DepthEnable = FALSE;
			DepthWriteMask = ZERO;
			DepthFunc = GREATER;
			StencilEnable = TRUE;
			StencilReadMask = 0xff;
			StencilWriteMask = 0x00;
			FrontFaceStencilFail = KEEP;
			FrontFaceStencilDepthFail = KEEP;
			FrontFaceStencilPass = KEEP;
			FrontFaceStencilFunc = NOT_EQUAL;
			BackFaceStencilFail = KEEP;
			BackFaceStencilDepthFail = KEEP;
			BackFaceStencilPass = KEEP;
			BackFaceStencilFunc = NOT_EQUAL;
			
			BlendEnable[0] = TRUE;
			SrcBlend[0] = SRC_ALPHA;
			DestBlend[0] = INV_SRC_ALPHA;
			BlendOp[0] = ADD;
			SrcBlendAlpha[0] = ONE;
			DestBlendAlpha[0] = ZERO;
			BlendOpAlpha[0] = ADD;
			
			VertexShader = compile vs_4_0 vsMain();
			PixelShader = compile ps_4_0 psMain();
		}
	}

#endif//ZGFX

