Texture2D txDiffuse : register( t0 );
SamplerState samLinear : register( s0 );

#include "cb_main.h"


//�{�[���C���f�b�N�X�ƃE�G�C�g�L
struct VS_INPUT_BONE
{
	float4 Pos : POSITION;
	uint4 Bidx : BONEINDEX;
	uint4 Bwgt : BONEWEIGHT;
};
struct GS_INPUT
{
	float4 Pos : SV_POSITION;
	float Edge : COLOR;
};

struct PS_INPUT
{
	float4 Pos : SV_POSITION;
	float Edge : COLOR;
};


//-------------------------
//�{�[���ό`�����_�u�����h
PS_INPUT vsBasicBlend( VS_INPUT_BONE input)
{
	PS_INPUT output = (PS_INPUT)0;
	float4 pos = input.Pos;
	float3 bpos0 = input.Bwgt[0]*mul(pos, getBoneMatrix(input.Bidx.x));
	float3 bpos1 = input.Bwgt[1]*mul(pos, getBoneMatrix(input.Bidx.y));
	pos.xyz = (bpos0.xyz + bpos1.xyz)/100;
	
	pos = mul( pos, Object.mtxWorld );
	pos = mul( pos, Scene.mtxView );
	output.Pos = mul( pos, Scene.mtxProj );
	output.Edge = input.Bwgt.w;//�����p
	return output;
}


void output_line5(GS_INPUT v0, GS_INPUT v1, inout LineStream<PS_INPUT> Stream )
{
	const float width = 1.0;
	const float px0 = width*v0.Pos.w/640.0;
	const float py0 = width*v0.Pos.w/480.0;
	const float px1 = width*v1.Pos.w/640.0;
	const float py1 = width*v1.Pos.w/480.0;
	
	PS_INPUT vo0,vo1;
	vo0.Pos = v0.Pos;
	vo0.Edge = v0.Edge;
	vo1.Pos = v1.Pos;
	vo1.Edge = v1.Edge;

	Stream.Append(vo0);
	Stream.Append(vo1);
	Stream.RestartStrip();

	vo0.Pos = v0.Pos + float4(px0,0,0,0);
	vo1.Pos = v1.Pos + float4(px1,0,0,0);
	Stream.Append(vo0);
	Stream.Append(vo1);

	vo0.Pos = v0.Pos  + float4(-px0,0,0,0);
	vo1.Pos = v1.Pos + float4(-px1,0,0,0);
	Stream.Append(vo0);
	Stream.Append(vo1);
	Stream.RestartStrip();
		
	vo0.Pos = v0.Pos + float4(0,py0,0,0);
	vo1.Pos = v1.Pos + float4(0,py1,0,0);
	Stream.Append(vo0);
	Stream.Append(vo1);
	Stream.RestartStrip();

	vo0.Pos = v0.Pos + float4(0,-py0,0,0);
	vo1.Pos = v1.Pos + float4(0,-py1,0,0);
	Stream.Append(vo0);
	Stream.Append(vo1);
	Stream.RestartStrip();
}


// �W�I���g���V�F�[�_
[maxvertexcount(10)]
void gsBasic( lineadj GS_INPUT input[4],
			uint primID : SV_PrimitiveID,
			inout LineStream<PS_INPUT> Stream )
{
	float3 v0 = input[0].Pos.xyz/input[0].Pos.w;
	float3 v1 = input[1].Pos.xyz/input[1].Pos.w;
	float3 v2 = input[2].Pos.xyz/input[2].Pos.w;
	float3 v3 = input[3].Pos.xyz/input[3].Pos.w;

	float cs0 = cross(v1-v0,v2-v0).z;
	float cs1 = cross(v2-v3,v1-v3).z;
		
	if( -0.0 > cs0*cs1 ){
		output_line5( input[1], input[2], Stream);
	}
}

//-------------------------
//�s�N�Z���V�F�[�_
float4 psBasic( PS_INPUT input ) : SV_Target
{
	return float4(0,0,0,0.12*input.Edge);
}

//-------------------------
//�V�F�[�_�G�t�F�N�g��`
#ifdef ZGFX

	technique Basic
	{
		pass P0
		{
			//�A���t�@�u�����h
			BlendEnable[0] = TRUE;
			SrcBlend[0] = ZERO;//SRC_ALPHA;
			DestBlend[0] = INV_SRC_ALPHA;
			BlendOp[0] = ADD;
			SrcBlendAlpha[0] = ONE;
			DestBlendAlpha[0] = ZERO;
			BlendOpAlpha[0] = ADD;

			CullMode = NONE;
			DepthFunc = LESS_EQUAL;
			DepthWriteMask = ZERO;
			VertexShader = compile vs_4_0 vsBasicBlend();
			GeometryShader = compile gs_4_0 gsBasic();
			PixelShader = compile ps_4_0 psBasic();
		}
	}
	
#endif//ZGFX

