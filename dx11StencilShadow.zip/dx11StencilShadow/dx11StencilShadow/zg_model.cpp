#include "stdafx.h"

#include "zg_model.h"
#include "zg_mqo.h"

#include <map>

namespace zgmdl
{

//-------------------------------------
Vertex::Vertex()
{
	init();
}

Vertex::~Vertex()
{
	del();
}

Vertex::Vertex(Vertex&& v)
{
	*this = v;
}

const Vertex& Vertex::operator=(Vertex&& v)
{
	del();//�R�s�[���|��
	eFormat = v.eFormat;
	eAttr = v.eAttr;
	sizeStride = v.sizeStride;
	sizeData = v.sizeData;
	numData = v.numData;
	numElem = v.numElem;
	pData = v.pData;
	v.init();//�ړ���폜
	return *this;
}

Vertex::Vertex(const Vertex& v)
{
	init();
	if(!v.pData)return;
	if( !Create(v.eAttr, v.numData, v.eFormat, v.numElem))return;
	memcpy(pData, v.pData, sizeData);
}

const Vertex& Vertex::operator=(const Vertex& v)
{
	Vertex tmp(v);
	*this = std::move(tmp);
	return *this;
}

void Vertex::del()
{
	if(pData){
		::operator delete( pData );
	}
	init();
}

void Vertex::init()
{
	pData = nullptr;
	eFormat = FMT_NULL;
	eAttr = VATTR_NULL;
	sizeStride = 0;
	sizeData = 0;
	numData = 0;
	numElem = 0;
}

//-------------------------------------
bool Vertex::Create(VATTR attr, zgU32 num, FORMAT format, zgU32 elem_num)
{
	zgU32 elem_size = 0;
	switch(format){
	case FMT_F32:
	case FMT_U32:
		elem_size = 4;
		break;
	case FMT_U16:
		elem_size = 2;
		break;
	case FMT_U8:
		elem_size = 1;
		break;
	}
	if(elem_size == 0)return false;

	size_t s = num*elem_size*elem_num;
	
	pData = ::operator new(s);
	if(!pData)return false;
	numData = num;
	sizeData = s;
	sizeStride = elem_size*elem_num;
	eFormat = format;
	eAttr = attr;
	numElem = elem_num;
	return true;
}
void* Vertex::rawget(zgU32 idx, zgU32 size)
{
	if(idx*size >= sizeData)return nullptr;
	return reinterpret_cast<zgU8*>(pData) + idx*size;
}
const void* Vertex::rawget(zgU32 idx, zgU32 size) const
{
	if(idx*size >= sizeData)return nullptr;
	return reinterpret_cast<zgU8*>(pData) + idx*size;
}

//-------------------------------------
bool Mesh::getSlot(Vertex::VATTR attr, zgU32& slot) const
{
	zgU32 s = 0;
	for(auto& vtx : aVertex){
		if(vtx.getAttr() == attr){
			slot = s;
			return true;
		}
		++s;
	}
	return false;//�Ȃ�
}
//-------------------------------------
zgU32 Mesh::VertexNum() const
{
	return aVertex.size();
}
//-------------------------------------
Vertex* Mesh::getVertex(zgU32 idx)
{
	if(idx >= VertexNum())return nullptr;
	return &aVertex[idx];
}
//-------------------------------------
const Vertex* Mesh::getVertex(zgU32 idx) const
{
	if(idx >= VertexNum())return nullptr;
	return &aVertex[idx];
}
Vertex* Mesh::getVertexAttr(Vertex::VATTR attr)
{
	zgU32 slot;
	if(!getSlot(attr,slot))return nullptr;
	return &aVertex[slot];
}
const Vertex* Mesh::getVertexAttr(Vertex::VATTR attr) const
{
	zgU32 slot;
	if(!getSlot(attr,slot))return nullptr;
	return &aVertex[slot];
}

//-------------------------------------
void Mesh::ResizeVertex(zgU32 num)
{
	aVertex.resize(num);
}

//-------------------------------------
zgU32 Object::MeshNum() const
{
	return aMesh.size();
}
//-------------------------------------
void Object::ResizeMesh(zgU32 num)
{
	aMesh.resize(num);
}
//-------------------------------------
Mesh* Object::getMesh(zgU32 idx)
{
	if(idx >= MeshNum())return nullptr;
	return &aMesh[idx];
}
//-------------------------------------
const Mesh* Object::getMesh(zgU32 idx) const
{
	if(idx >= MeshNum())return nullptr;
	return &aMesh[idx];
}


//-------------------------------------
zgU32 Model::MatNum() const
{
	return aMat.size();
}
zgU32 Model::ObjNum() const
{
	return aObj.size();
}
zgU32 Model::BoneNum() const
{
	return aBone.size();
}

//-------------------------------------
void Model:: ResizeMat(zgU32 num)
{
	aMat.resize(num);
}

//-------------------------------------
Material* Model::getMat(zgU32 idx)
{
	if(idx >= MatNum())return nullptr;
	return &aMat[idx];
}
//-------------------------------------
const Material* Model::getMat(zgU32 idx) const
{
	if(idx >= MatNum())return nullptr;
	return &aMat[idx];
}

//-------------------------------------
void Model:: ResizeObj(zgU32 num)
{
	aObj.resize(num);
}
//-------------------------------------
Object* Model::getObj(zgU32 idx)
{
	if(idx >= ObjNum())return nullptr;
	return &aObj[idx];
}
//-------------------------------------
const Object* Model::getObj(zgU32 idx) const
{
	if(idx >= ObjNum())return nullptr;
	return &aObj[idx];
}

//-------------------------------------
void Model:: ResizeBone(zgU32 num)
{
	aBone.resize(num);
	aHier.resize(num);
}
Bone* Model::getBone(zgU32 idx)
{
	if(idx >= aBone.size())return nullptr;
	return &aBone[idx];
}
const Bone* Model::getBone(zgU32 idx) const
{
	if(idx >= aBone.size())return nullptr;
	return &aBone[idx];
}
Hierarchy* Model::getHier(zgU32 idx)
{
	if(idx >= aHier.size())return nullptr;
	return &aHier[idx];
}
const Hierarchy* Model::getHier(zgU32 idx) const
{
	if(idx >= aHier.size())return nullptr;
	return &aHier[idx];
}
void Model::ResizeInstList(zgU32 num)
{
	aInst.resize(num);
}
zgU32 Model::DListNum() const
{
	return aInst.size();
}
InstList* Model::getInstList(zgU32 idx)
{
	if(idx >= aInst.size())return nullptr;
	return &aInst[idx];
}
const InstList* Model::getInstList(zgU32 idx) const
{
	if(idx >= aInst.size())return nullptr;
	return &aInst[idx];
}

namespace{

#if 0//Merge�@SORTVERTEX�ɕK�v�Ȋ֐�
struct SORTVERTEX
{
	//�\�[�g�l
	zgF32 value() const;

	//����ȏ��ɋ߂����_�͂Ȃ�
	bool limit(const SORTVERTEX& o, OPTION& opt) const 

	//�\�[�g�s�v�Ȃ炱�ꂾ��
	//�߂��l���ǂ��� OPTION�ɋ��e�덷�Ȃǂ�ݒ肷��
	bool Near(const SORTVERTEX& o, OPTION& opt) const;	
};
#endif

template <typename SORTVERTEX>
struct SORTFUNC
{
	bool operator()( const SORTVERTEX* a, const SORTVERTEX* b) const
	{
		return a->value() < b->value();
	}
};

template <typename SORTVERTEX, typename OPTION> 
zgU32 Merge(
	const std::vector<SORTVERTEX>& vertex,
	std::vector<zgU32>& merge_map,//�}�[�W���index�l
	OPTION& opt)
{
	zgU32 new_idx = 0;	
	zgU32 vnum = vertex.size();

	// �|�C���^���\�[�g�@
	std::vector<const SORTVERTEX*> sort_vertex;
	sort_vertex.reserve(vnum);
	for(auto& v : vertex){
		sort_vertex.push_back(&v);
	}
	std::sort(sort_vertex.begin(), sort_vertex.end(), SORTFUNC<SORTVERTEX>());

	merge_map.resize(vertex.size(), vnum);//���L���ς݃t���O�����˂�

	// �z��̐擪���珇�Ɉʒu�̋߂����_���P�ɂ܂Ƃ߂�
	for(zgU32 iv=0;iv<vnum;++iv){
		zgU32 a_idx = sort_vertex[iv] - vertex.data();
		const SORTVERTEX* a = sort_vertex[iv];

		if( merge_map[a_idx] < vnum )continue;//���łɃ}�[�W�ς�
		merge_map[a_idx] = new_idx;

		zgU32 next = vnum;
		for(zgU32 jv=iv+1;jv<vnum;++jv){
			zgU32 b_idx = sort_vertex[jv] - vertex.data();
			const SORTVERTEX* b = sort_vertex[jv];
			if( merge_map[b_idx] < vnum )continue;//���łɃ}�[�W�ς�

			if(a->limit(*b, opt)){
				break;//����ȏ��ɋ߂����_�͂Ȃ�
			}

			if( a->Near(*b, opt) ){
				//�߂��̒��_�ɓ���index�l�����蓖��
				merge_map[b_idx] = new_idx;
			}else{
				if( next == vnum){
					//���̌����J�n�ʒu
					next = jv-1;
				}
			}
		}
		++new_idx;
		if( next < vnum ){
			iv = next;
		}
	}
	return new_idx;//�}�[�W��̒��_��

}

//--------------------------------------------
// �\�[�g�pZGVECTOR3
struct SORTZGVECTOR3
{
	SORTZGVECTOR3(){}
	SORTZGVECTOR3( const ZGVECTOR3& a) : v(a){} 
	ZGVECTOR3 v;
	//---------------
	zgF32 value() const{ return v.x + v.y + v.z;}
	//---------------
	bool limit(const SORTZGVECTOR3& o, zgF32 eps) const
	{
		return fabs(value() - o.value()) > 3.0f*eps;
	}
	//---------------
	bool Near(const SORTZGVECTOR3& o, zgF32 eps) const
	{
		zgF32 sub = v.x - o.v.x;
		if(sub > eps || sub < -eps)return false;
		sub = v.y - o.v.y;
		if(sub > eps || sub < -eps)return false;
		sub = v.z - o.v.z;
		if(sub > eps || sub < -eps)return false;
		return true;
	}
};

struct SORTZGVECTOR2
{
	SORTZGVECTOR2(){}
	SORTZGVECTOR2( const ZGVECTOR2& a) : v(a){} 
	ZGVECTOR2 v;
	//---------------
	zgF32 value() const{ return v.x + v.y;}
	//---------------
	bool limit(const SORTZGVECTOR3& o, zgF32 eps) const
	{
		return fabs(value() - o.value()) > 2.0f*eps;
	}
	//---------------
	bool Near(const SORTZGVECTOR2& o, zgF32 eps) const
	{
		zgF32 sub = v.x - o.v.x;
		if(sub > eps || sub < -eps)return false;
		sub = v.y - o.v.y;
		if(sub > eps || sub < -eps)return false;
		return true;
	}
};
struct SORTZGUVECTOR4
{
	SORTZGUVECTOR4(){}
	SORTZGUVECTOR4( const ZGUVECTOR4& a) : v(a){} 
	ZGUVECTOR4 v;
	//---------------
	bool Near(const SORTZGUVECTOR4& o, zgU32 eps) const
	{
		//�����Ȃ̂Ō덷�O
		if( v.x != o.v.x )return false;
		if( v.y != o.v.y )return false;
		if( v.z != o.v.z )return false;
	
		//���@�{�[���E�G�C�g��w���G�b�W�t���O�Ƃ��Ďg�p�@���L���_�̔�������Ȃ�
		//��p�̃G�b�W�f�[�^�p�̒��_�f�[�^���쐬�\��
	//	if( v.w != o.v.w )return false;

		return true;
	}
};

struct SORTVERTEX_EPS{
	SORTVERTEX_EPS(zgF32 p=0.001f, zgF32 n=0.0001f, zgF32 t=0.0001f)
	: pos(p), nor(n), tex(t)
	{}
	
	zgF32 pos;
	zgF32 nor;
	zgF32 tex;
};
struct SORTVERTEX_P
{
	SORTVERTEX_P(){}
	SORTVERTEX_P(const SORTZGVECTOR3& p) : pos(p){}

	SORTZGVECTOR3 pos;

	zgF32 value() const
	{
		return pos.value();
	}
	bool limit(const SORTVERTEX_P& o, SORTVERTEX_EPS& eps) const
	{
		return pos.limit(o.pos, eps.pos);
	}
	bool Near(const SORTVERTEX_P& o, SORTVERTEX_EPS& eps) const
	{
		return pos.Near(o.pos, eps.pos);
	}
};
struct SORTVERTEX_PNT2 : public SORTVERTEX_P
{
	SORTVERTEX_PNT2(){}
	SORTVERTEX_PNT2(const SORTZGVECTOR3& p, const SORTZGVECTOR3& n,
					const SORTZGVECTOR2& t0, const SORTZGVECTOR2& t1)
	: SORTVERTEX_P(p), nor(n), tex0(t0), tex1(t1)
	{}

	SORTZGVECTOR3 nor;
	SORTZGVECTOR2 tex0,tex1;

	bool Near(const SORTVERTEX_PNT2& o, SORTVERTEX_EPS& eps) const
	{
		return SORTVERTEX_P::Near(o, eps)
				&& nor.Near(o.nor, eps.nor)
				&& tex0.Near(o.tex0, eps.tex)
				&& tex1.Near(o.tex1, eps.tex);
	}
};
struct SORTVERTEX_PNT2B : public SORTVERTEX_PNT2
{
	SORTVERTEX_PNT2B() : SORTVERTEX_PNT2(){}
	SORTVERTEX_PNT2B(const SORTZGVECTOR3& p, const SORTZGVECTOR3& n,
					const SORTZGVECTOR2& t0, const SORTZGVECTOR2& t1,
					const SORTZGUVECTOR4& bi, const SORTZGUVECTOR4& bw)
	: SORTVERTEX_PNT2(p, n, t0, t1), bidx(bi), bwgt(bw)
	{}

	SORTZGUVECTOR4 bidx;
	SORTZGUVECTOR4 bwgt;
	bool Near(const SORTVERTEX_PNT2B& o, SORTVERTEX_EPS& eps) const
	{
		return SORTVERTEX_PNT2::Near(o, eps)
				&& bidx.Near(o.bidx, 0)
				&& bwgt.Near(o.bwgt, 0);
	}
};
struct SORTVERTEX_PB : public SORTVERTEX_P
{
	SORTVERTEX_PB(){}
	SORTVERTEX_PB(const SORTZGVECTOR3& p,
					const SORTZGUVECTOR4& bi, const SORTZGUVECTOR4& bw)
	: SORTVERTEX_P(p), bidx(bi), bwgt(bw)
	{}

	SORTZGUVECTOR4 bidx;
	SORTZGUVECTOR4 bwgt;

	bool Near(const SORTVERTEX_PB& o, SORTVERTEX_EPS& eps) const
	{
		return SORTVERTEX_P::Near(o, eps)
				&& bidx.Near(o.bidx, 0)
				&& bwgt.Near(o.bwgt, 0);
	}
};



}//ns


//--------------------------------------
bool MergeVertex(Model& model)
{
	zgU32 cnt = 0;
	for(zgU32 io=0;io<model.ObjNum();++io){
		Object* obj = model.getObj(io);
		if(!obj)continue;
		if( MergeVertex(*obj) ){
			++cnt;
		}
	}
	return cnt==model.ObjNum();
}

//--------------------------------------
bool MergeVertex(Object& obj)
{
	zgU32 cnt = 0;
	for(zgU32 im=0;im<obj.MeshNum();++im){
		Mesh* mesh = obj.getMesh(im);
		if(!mesh)continue;
		if( MergeVertex(*mesh) ){
			++cnt;
		}
	}
	return cnt==obj.MeshNum();
}

//--------------------------------------
bool MergeVertex(Mesh& mesh)
{
	const zgF32 EPS = 0.001f;//���e�덷
	SORTVERTEX_EPS vertex_eps(EPS);

	Vertex* pos = mesh.getVertexAttr(Vertex::POSITION);
	if(!pos || pos->getNum()<2)return false;
	Vertex* nor = mesh.getVertexAttr(Vertex::NORMAL);
	Vertex* tc0 = mesh.getVertexAttr(Vertex::TEXCRD0);
	Vertex* bidx = mesh.getVertexAttr(Vertex::BONEINDEX);
	Vertex* bwgt = mesh.getVertexAttr(Vertex::BONEWEIGHT);
	Vertex& index = mesh.getIndex();

	// �Ƃ肠�������_�f�[�^�\���ƃt�H�[�}�b�g�Œ�
	if(!nor || !tc0 || !bidx || !bwgt)return false;
	if( pos->getFormat() != Vertex::FMT_F32 || pos->getElemNum() != 3)return false;
	if( nor->getFormat() != Vertex::FMT_F32 || nor->getElemNum() != 3)return false;
	if( tc0->getFormat() != Vertex::FMT_F32 || tc0->getElemNum() != 2)return false;
	if( bidx->getFormat() != Vertex::FMT_U16 || bidx->getElemNum() != 4)return false;
	if( bwgt->getFormat() != Vertex::FMT_U8 || bwgt->getElemNum() != 4)return false;
	if( index.getFormat() != Vertex::FMT_U32 || index.getElemNum() != 1)return false;
	std::vector<SORTVERTEX_PNT2B> vertex;
	std::vector<zgU32> merge_map;

	vertex.reserve(pos->getNum());
	ZGVECTOR2 t00(0,0);
	for(zgU32 iv=0;iv<pos->getNum();++iv){
		ZGVECTOR3 p,n;
		ZGVECTOR2 t;
		zgU16 bi[4];
		zgU8 bw[4];
		if( !pos->getData(iv, p) )return false;
		if( !nor->getData(iv, n) )return false;
		if( !tc0->getData(iv, t) )return false;
		if( !bidx->getData(iv, bi) )return false;
		if( !bwgt->getData(iv, bw) )return false;
		vertex.push_back(
				SORTVERTEX_PNT2B(p,n,t,t00,
					ZGUVECTOR4(bi[0],bi[1],bi[2],bi[3]),
					ZGUVECTOR4(bw[0],bw[1],bw[2],bw[3]) ) );
	}
	
	zgU32 new_vnum = Merge<SORTVERTEX_PNT2B>(vertex, merge_map, vertex_eps);

	Vertex new_pos, new_nor, new_tc0, new_bidx, new_bwgt, new_index;
	if( !new_pos.Create(Vertex::POSITION, new_vnum, Vertex::FMT_F32, 3) )return false;
	if( !new_nor.Create(Vertex::NORMAL, new_vnum, Vertex::FMT_F32, 3) )return false;
	if( !new_tc0.Create(Vertex::TEXCRD0, new_vnum, Vertex::FMT_F32, 2) )return false;
	if( !new_bidx.Create(Vertex::BONEINDEX, new_vnum, Vertex::FMT_U16, 4) )return false;
	if( !new_bwgt.Create(Vertex::BONEWEIGHT, new_vnum, Vertex::FMT_U8, 4) )return false;
	if( !new_index.Create(Vertex::INDEX, index.getNum(), Vertex::FMT_U32, 1) )return false;
	for(zgU32 iv=0;iv<vertex.size();++iv){
		const SORTVERTEX_PNT2B& v = vertex[iv];
		zgU32 idx = merge_map[iv];

		ZGVECTOR3 p,n;
		ZGVECTOR2 t;
		zgU16 bi[4];
		zgU8 bw[4];
		if( !pos->getData(iv, p) )return false;
		if( !nor->getData(iv, n) )return false;
		if( !tc0->getData(iv, t) )return false;
		if( !bidx->getData(iv, bi) )return false;
		if( !bwgt->getData(iv, bw) )return false;

		if( !new_pos.setData(idx, p) )return false;
		if( !new_nor.setData(idx, n) )return false;
		if( !new_tc0.setData(idx, t) )return false;
		if( !new_bidx.setData(idx, bi) )return false;
		if( !new_bwgt.setData(idx, bw) )return false;
	}
	for(zgU32 ii=0;ii<index.getNum();++ii){
		zgU32 vidx;
		if( !index.getData(ii, vidx) )return false;
		zgU32 idx = merge_map[vidx];
		if( !new_index.setData(ii, idx) )return false;
	}
	
	*pos = std::move(new_pos);
	*nor = std::move(new_nor);
	*tc0 = std::move(new_tc0);
	*bidx = std::move(new_bidx);
	*bwgt = std::move(new_bwgt);
	index = std::move(new_index);
	return true;
}


//----------------------------------------------
//������
namespace{

struct OLineTri
{
	OLineTri(zgU32 a0=0,zgU32 a1=0,zgU32 a2=0)
	{
		vidx[0] = a0;
		vidx[1] = a1;
		vidx[2] = a2;
		edge[0]=edge[1]=edge[2]=false;
		adj_vidx[0] = adj_vidx[1] = adj_vidx[2] = 0;
	}
	zgU32 vidx[3];
	bool edge[3];//�Ӂ@0-1 1-2 2-0�̗֊s���o�^�ς�
	zgU32 adj_vidx[3];//�אڃ|���S���̒��_�@�V���h�E�{�����[���p
};

}//ns

//----------------------------------------------
bool CreateGeoOutline(const Object& obj, Mesh& out_mesh)
{
	//�S���b�V���̒��_��1�ɂ܂Ƃ߁A�}�[�W����
	const zgF32 EPS = 0.001f;//���e�덷
	SORTVERTEX_EPS vertex_eps(EPS);
	std::vector<SORTVERTEX_PB> vertex;
	std::vector<zgU32> index;

	//���_�f�[�^�A�C���f�b�N�X��1�ɂ܂Ƃ߂�
	zgU32 idx_ofs = 0;
	for(zgU32 im=0;im<obj.MeshNum();++im){
		const Mesh* mesh = obj.getMesh(im);
		if(!mesh)continue;
		
		zgU32 slot;
		if(!mesh->getSlot(Vertex::POSITION, slot))continue;
		const Vertex* pos = mesh->getVertex(slot);
		const Vertex* bidx = mesh->getVertexAttr(Vertex::BONEINDEX);
		const Vertex* bwgt = mesh->getVertexAttr(Vertex::BONEWEIGHT);
		const Vertex& ids = mesh->getIndex();
		if(!pos || !bidx || !bwgt)continue;

		// �Ƃ肠�����t�H�[�}�b�g�Œ�
		if(pos->getFormat() != Vertex::FMT_F32 || pos->getElemNum() != 3 )continue;//float[3]�̂�
		if(bidx->getFormat() != Vertex::FMT_U16 || bidx->getElemNum() != 4 )continue;
		if(bwgt->getFormat() != Vertex::FMT_U8 || bwgt->getElemNum() != 4 )continue;
		if(ids.getFormat() != Vertex::FMT_U32 || ids.getElemNum() != 1)continue;//uint32�̂�

		for(zgU32 iv=0;iv<pos->getNum();++iv){
			ZGVECTOR3 p;
			zgU16 bi[4];
			zgU8 bw[4];
			if( !pos->getData(iv, p) )break;
			if( !bidx->getData(iv, bi) )break;
			if( !bwgt->getData(iv, bw) )break;

			vertex.push_back( SORTVERTEX_PB(p,
									ZGUVECTOR4(bi[0],bi[1],bi[2],bi[3]),
									ZGUVECTOR4(bw[0],bw[1],bw[2],bw[3]) ) );
			
		}

		for(zgU32 ii=0;ii<ids.getNum();++ii){
			zgU32 idx;
			if( !ids.getData(ii,idx) )break;
			index.push_back(idx+idx_ofs);
		}

		idx_ofs += pos->getNum();
	}

	std::vector<zgU32> merge_map;//�}�[�W���index�l
	
	zgU32 new_vnum = Merge<SORTVERTEX_PB>(vertex, merge_map, vertex_eps);
	
	Mesh new_mesh;
	new_mesh.ResizeVertex(5);
	Vertex* pos = new_mesh.getVertex(0);
	Vertex* bidx = new_mesh.getVertex(1);
	Vertex* bwgt = new_mesh.getVertex(2);
	Vertex* nor = new_mesh.getVertex(3);
	Vertex* tc0 = new_mesh.getVertex(4);
	Vertex& ids = new_mesh.getIndex();
	if(!pos || !bidx || !bwgt)return false;
	
	pos->Create(Vertex::POSITION, new_vnum, Vertex::FMT_F32, 3);
	bidx->Create(Vertex::BONEINDEX, new_vnum, Vertex::FMT_U16, 4);
	bwgt->Create(Vertex::BONEWEIGHT, new_vnum, Vertex::FMT_U8, 4);
	nor->Create(Vertex::NORMAL, new_vnum, Vertex::FMT_F32, 3);
	tc0->Create(Vertex::TEXCRD0, new_vnum, Vertex::FMT_F32, 2);
	
	for(zgU32 iv=0;iv<vertex.size();++iv){
		zgU32 idx = merge_map[iv];
		pos->setData(idx, vertex[iv].pos.v);
		const ZGUVECTOR4& bi = vertex[iv].bidx.v;
		const ZGUVECTOR4& bw = vertex[iv].bwgt.v;
		zgU16 bi16[4]={bi.x,bi.y,bi.z,bi.w};
		zgU8 bw8[4] = {bw.x,bw.y,bw.z,bw.w};
		bidx->setData(idx, bi16);
		bwgt->setData(idx, bw8);
		nor->setData(idx, ZGVECTOR3(0,1,0));
		tc0->setData(idx, ZGVECTOR2(0,0));
	}
	for(auto& i : index){
		i = merge_map[i];
	}

	std::vector<zgU32> line_index;
	

	std::vector<OLineTri> triangle;

	//���_���܂ރ|���S���̃��X�g�@���L�ӂ̌���������
	std::map<zgU32, std::vector<zgU32>> vidxtri;

	triangle.reserve(index.size()/3);
	for(zgU32 ii=0;ii<index.size();ii+=3){
		// �|���S�����X�g�쐬
		triangle.push_back( OLineTri(index[ii],index[ii+1],index[ii+2]) );
	}

	for(zgU32 ii=0;ii<index.size();++ii){
		zgU32 tri_idx = ii/3;

		//���_���\������|���S��index���X�g�쐬
		std::map<zgU32, std::vector<zgU32>>::iterator it;
		it = vidxtri.find( index[ii] );
		if(it == vidxtri.end() ){
			std::vector<zgU32> tri;
			tri.reserve(2);
			tri.push_back( tri_idx );
			vidxtri.insert( std::pair<zgU32, std::vector<zgU32>>(index[ii], tri) );
		}else{
			zgU32 i=0;
			for(i=0;i<it->second.size();++i){
				if( it->second[i] == tri_idx )break;//���łɒǉ��ς�
			}
			if(i==it->second.size()){
				// �V�K�ǉ�
				it->second.push_back( tri_idx );
			}
		}
	}

	zgU32 ti = 0;
	for(auto& tri0 : triangle){
		for(zgU32 i=0;i<3;++i){
			if( tri0.edge[i] )continue;//��
			zgU32 vidx0 = tri0.vidx[i];
			zgU32 vidx1 = tri0.vidx[(i+1)%3];
			zgU32 vidx2 = tri0.vidx[(i+2)%3];

			// ��vidx0-vidx1�����L���Ă���|���S���̌���
			bool find_edge = false;
			std::map<zgU32, std::vector<zgU32>>::iterator it;
			it = vidxtri.find( vidx0 );
			if( it != vidxtri.end() ){
				for(auto& tidx : it->second){
					if( tidx == ti )continue;//����
					OLineTri& tri1 = triangle[tidx];
					//���L�ӂ͋t���Ȃ̂�i0��i1���t
					zgU32 i1;
					for(i1=0;i1<3;++i1){ if(tri1.vidx[i1]==vidx0)break;}
					if(i1==3)continue;//���肦�񂯂�
					zgU32 i0 = (i1+2)%3; //(i-1)%3�����Ǖ����Ȃ��Ȃ̂�(i-1+3)%3
					if( tri1.vidx[i0] != vidx1)continue;//�Ⴄ

					if( tri1.edge[i0] )continue;//��
					zgU32 i2 = (i1+1)%3;

					line_index.push_back(vidx2);
					line_index.push_back(vidx0);
					line_index.push_back(vidx1);
					line_index.push_back(tri1.vidx[i2]);
					tri1.edge[i0] = true;
					find_edge = true;
					break;
				}
			}
			if( !find_edge ){
				//�Ɨ�������
				line_index.push_back(vidx2);
				line_index.push_back(vidx0);
				line_index.push_back(vidx1);
				line_index.push_back(vidx2);
			}
			tri0.edge[i] = true;
		}
		++ti;
	}
	
	new_mesh.setPrim(Mesh::PRIM_LINELIST_ADJ);
	ids.Create(Vertex::INDEX, line_index.size(), Vertex::FMT_U32, 1);
	for(zgU32 ii=0;ii<line_index.size();++ii){
		ids.setData( ii, line_index[ii] );
	}

	out_mesh = std::move(new_mesh);

	return true;
}


//-----------------------------------------------
bool CreateShadowVol(const Object& obj, Mesh& out_mesh)
{
	//�S���b�V���̒��_��1�ɂ܂Ƃ߁A�}�[�W����
	const zgF32 EPS = 0.001f;//���e�덷
	SORTVERTEX_EPS vertex_eps(EPS);
	std::vector<SORTVERTEX_PB> vertex;
	std::vector<zgU32> index;

	//���_�f�[�^�A�C���f�b�N�X��1�ɂ܂Ƃ߂�
	zgU32 idx_ofs = 0;
	for(zgU32 im=0;im<obj.MeshNum();++im){
		const Mesh* mesh = obj.getMesh(im);
		if(!mesh)continue;
		
		zgU32 slot;
		if(!mesh->getSlot(Vertex::POSITION, slot))continue;
		const Vertex* pos = mesh->getVertex(slot);
		const Vertex* bidx = mesh->getVertexAttr(Vertex::BONEINDEX);
		const Vertex* bwgt = mesh->getVertexAttr(Vertex::BONEWEIGHT);
		const Vertex& ids = mesh->getIndex();
		if(!pos || !bidx || !bwgt)continue;

		// �Ƃ肠�����t�H�[�}�b�g�Œ�
		if(pos->getFormat() != Vertex::FMT_F32 || pos->getElemNum() != 3 )continue;//float[3]�̂�
		if(bidx->getFormat() != Vertex::FMT_U16 || bidx->getElemNum() != 4 )continue;
		if(bwgt->getFormat() != Vertex::FMT_U8 || bwgt->getElemNum() != 4 )continue;
		if(ids.getFormat() != Vertex::FMT_U32 || ids.getElemNum() != 1)continue;//uint32�̂�

		for(zgU32 iv=0;iv<pos->getNum();++iv){
			ZGVECTOR3 p;
			zgU16 bi[4];
			zgU8 bw[4];
			if( !pos->getData(iv, p) )break;
			if( !bidx->getData(iv, bi) )break;
			if( !bwgt->getData(iv, bw) )break;

			vertex.push_back( SORTVERTEX_PB(p,
									ZGUVECTOR4(bi[0],bi[1],bi[2],bi[3]),
									ZGUVECTOR4(bw[0],bw[1],bw[2],bw[3]) ) );
			
		}

		for(zgU32 ii=0;ii<ids.getNum();++ii){
			zgU32 idx;
			if( !ids.getData(ii,idx) )break;
			index.push_back(idx+idx_ofs);
		}

		idx_ofs += pos->getNum();
	}

	std::vector<zgU32> merge_map;//�}�[�W���index�l
	
	zgU32 new_vnum = Merge<SORTVERTEX_PB>(vertex, merge_map, vertex_eps);
	
	Mesh new_mesh;
	new_mesh.ResizeVertex(5);
	Vertex* pos = new_mesh.getVertex(0);
	Vertex* bidx = new_mesh.getVertex(1);
	Vertex* bwgt = new_mesh.getVertex(2);
	Vertex* nor = new_mesh.getVertex(3);
	Vertex* tc0 = new_mesh.getVertex(4);
	Vertex& ids = new_mesh.getIndex();
	if(!pos || !bidx || !bwgt)return false;
	
	pos->Create(Vertex::POSITION, new_vnum, Vertex::FMT_F32, 3);
	bidx->Create(Vertex::BONEINDEX, new_vnum, Vertex::FMT_U16, 4);
	bwgt->Create(Vertex::BONEWEIGHT, new_vnum, Vertex::FMT_U8, 4);
	nor->Create(Vertex::NORMAL, new_vnum, Vertex::FMT_F32, 3);
	tc0->Create(Vertex::TEXCRD0, new_vnum, Vertex::FMT_F32, 2);
	
	for(zgU32 iv=0;iv<vertex.size();++iv){
		zgU32 idx = merge_map[iv];
		pos->setData(idx, vertex[iv].pos.v);
		const ZGUVECTOR4& bi = vertex[iv].bidx.v;
		const ZGUVECTOR4& bw = vertex[iv].bwgt.v;
		zgU16 bi16[4]={bi.x,bi.y,bi.z,bi.w};
		zgU8 bw8[4] = {bw.x,bw.y,bw.z,bw.w};
		bidx->setData(idx, bi16);
		bwgt->setData(idx, bw8);
		nor->setData(idx, ZGVECTOR3(0,1,0));
		tc0->setData(idx, ZGVECTOR2(0,0));
	}
	for(auto& i : index){
		i = merge_map[i];
	}

	std::vector<zgU32> line_index;
	std::vector<OLineTri> triangle;

	//���_���܂ރ|���S���̃��X�g�@���L�ӂ̌���������
	std::map<zgU32, std::vector<zgU32>> vidxtri;
	triangle.reserve(index.size()/3);
	for(zgU32 ii=0;ii<index.size();ii+=3){
		// �|���S�����X�g�쐬
		triangle.push_back( OLineTri(index[ii],index[ii+1],index[ii+2]) );
	}
	for(zgU32 ii=0;ii<index.size();++ii){
		zgU32 tri_idx = ii/3;

		//���_���\������|���S��index���X�g�쐬
		std::map<zgU32, std::vector<zgU32>>::iterator it;
		it = vidxtri.find( index[ii] );
		if(it == vidxtri.end() ){
			std::vector<zgU32> tri;
			tri.reserve(4);
			tri.push_back( tri_idx );
			vidxtri.insert( std::pair<zgU32, std::vector<zgU32>>(index[ii], tri) );
		}else{
			zgU32 i=0;
			for(i=0;i<it->second.size();++i){
				if( it->second[i] == tri_idx )break;//���łɒǉ��ς�
			}
			if(i==it->second.size()){
				// �V�K�ǉ�
				it->second.push_back( tri_idx );
			}
		}
	}
	zgU32 ti = 0;
	for(auto& tri0 : triangle){
		for(zgU32 i=0;i<3;++i){
			if( tri0.edge[i] )continue;//��
			zgU32 vidx0 = tri0.vidx[i];
			zgU32 vidx1 = tri0.vidx[(i+1)%3];
			zgU32 vidx2 = tri0.vidx[(i+2)%3];

			// ��vidx0-vidx1�����L���Ă���|���S���̌���
			std::map<zgU32, std::vector<zgU32>>::iterator it;
			it = vidxtri.find( vidx0 );
			if( it != vidxtri.end() ){
				for(auto& tidx : it->second){
					if( tidx == ti )continue;//����
					OLineTri& tri1 = triangle[tidx];
					//���L�ӂ͋t���Ȃ̂�i0��i1���t
					zgU32 i1;
					for(i1=0;i1<3;++i1){ if(tri1.vidx[i1]==vidx0)break;}
					if(i1==3)continue;//���肦�񂯂�
					zgU32 i0 = (i1+2)%3; //(i-1)%3�����Ǖ����Ȃ��Ȃ̂�(i-1+3)%3
					if( tri1.vidx[i0] != vidx1)continue;//�Ⴄ

					if( tri1.edge[i0] )continue;//��
					zgU32 i2 = (i1+1)%3;
					
					// �����̗אڃ|���S��
					tri0.edge[i] = true;
					tri0.adj_vidx[i] = tri1.vidx[i2];

					// ����Ɏ�����
					tri1.edge[i0] = true;
					tri1.adj_vidx[i0] = vidx2;
					break;
				}
			}
		}
		line_index.push_back(tri0.vidx[0]);
		if( tri0.edge[0] ){
			// �אڃ|���S������
			line_index.push_back(tri0.adj_vidx[0]);
		}else{
			// �Ȃ��@�����΂̃|���S����o�^�i�אڂȂ��t���O�j
			line_index.push_back(tri0.vidx[2]);
		}
		line_index.push_back(tri0.vidx[1]);
		if( tri0.edge[1] ){
			line_index.push_back(tri0.adj_vidx[1]);
		}else{
			line_index.push_back(tri0.vidx[0]);
		}
		line_index.push_back(tri0.vidx[2]);
		if( tri0.edge[2] ){
			line_index.push_back(tri0.adj_vidx[2]);
		}else{
			line_index.push_back(tri0.vidx[1]);
		}
		++ti;
	}
	new_mesh.setPrim(Mesh::PRIM_TRILIST_ADJ);
	ids.Create(Vertex::INDEX, line_index.size(), Vertex::FMT_U32, 1);
	for(zgU32 ii=0;ii<line_index.size();++ii){
		ids.setData( ii, line_index[ii] );
	}


	out_mesh = std::move(new_mesh);
	
	return true;
}

}//zgmdl
