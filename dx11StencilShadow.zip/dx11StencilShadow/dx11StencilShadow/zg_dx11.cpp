#include "stdafx.h"

#include "zg_dx11.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <directxmath.h>
#include "DirectXTex/DirectXTex.h"

#include "zg_mqo.h"
#include "zg_mmd.h"
#include "zg_model.h"

#include "zg_renctx11.h"
#include "zg_ptrx11.h"
#include "zg_mdlx11.h"
#include "zg_shdfx.h"

#include "zg_mmd_dx11.h"

#include <fstream>
#include <string>
#include <stdlib.h>
#include <locale>

#include "sample_data.h"

using namespace zix11;
using namespace DirectX;
using namespace mmdx11;
namespace{


XMVECTOR ToXMVec(const ZGVECTOR3& v)
{
	return XMVectorSet(v.x,v.y,v.z, 0);
}
XMVECTOR ToXMVecW1(const ZGVECTOR3& v)
{
	return XMVectorSet(v.x,v.y,v.z, 1);
}
XMVECTOR ToXMVec(const ZGVECTOR4& v)
{
	return XMVectorSet(v.x,v.y,v.z,v.w);
}
XMVECTOR ToXMVec(const ZGQUAT& v)
{
	return XMVectorSet(v.x,v.y,v.z,v.w);
}
ZGVECTOR3 ToVec3(XMVECTOR v)
{
	return ZGVECTOR3(XMVectorGetX(v),XMVectorGetY(v),XMVectorGetZ(v));
}
ZGQUAT ToQuat(XMVECTOR v)
{
	return ZGQUAT(XMVectorGetX(v),XMVectorGetY(v),XMVectorGetZ(v),XMVectorGetW(v));
}

}



bool					g_InitDX11 = false;//2�d�������h�~
D3D_DRIVER_TYPE			g_DriverType = D3D_DRIVER_TYPE_NULL;
D3D_FEATURE_LEVEL		g_FeatureLevel = D3D_FEATURE_LEVEL_11_0;

RenContextX11 g_RenCtx;
std::vector<SPtr<MeshModel>::Type> g_aModel;
std::vector<RenListX11> g_RenList;
std::vector<RenListX11> g_OLineRenList;
std::vector<RenListX11> g_ShadowRenList;


RenContextX11& GetRenContext()
{
	return g_RenCtx;
}


//---------------------------------------------------------
HRESULT InitDX11(HWND hWnd)
{
	if(g_InitDX11)return S_FALSE;//���łɏ�����
	
	HRESULT hr = S_OK;
	
	RECT rc;
	GetClientRect( hWnd, &rc );
	UINT width = rc.right - rc.left;
	UINT height = rc.bottom - rc.top;

	UINT cdev_flags = 0;
#ifdef _DEBUG
	cdev_flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
	RenContextX11& renctx =  GetRenContext();

	// DirectX11&�n�[�h�E�F�A�Ή��̂�
	D3D_FEATURE_LEVEL feature_level = D3D_FEATURE_LEVEL_11_0;
	g_DriverType = D3D_DRIVER_TYPE_HARDWARE;


	//�f�o�C�X�쐬
	hr = D3D11CreateDevice(	NULL, D3D_DRIVER_TYPE_HARDWARE,	NULL, cdev_flags,
							&feature_level, 1, D3D11_SDK_VERSION, GSET_DXPTR(renctx.pDev),
							&g_FeatureLevel, GSET_DXPTR(renctx.pImCtx) );
	if( FAILED( hr ) ){
		return hr;
	}
	
	//�g�p�\��MSAA���擾
	DXGI_SAMPLE_DESC smpl_desc;
	//for(int i=0; i <= D3D11_MAX_MULTISAMPLE_SAMPLE_COUNT; i++){
	for(int i=0; i <= 8; i++){
		UINT Quality;
		if(SUCCEEDED(renctx.pDev->CheckMultisampleQualityLevels(DXGI_FORMAT_R8G8B8A8_UNORM, i, &Quality))){
			if(0 < Quality){
				smpl_desc.Count = i;
				smpl_desc.Quality = Quality - 1;
			}
		}
	}
	DXPtr<IDXGIDevice>::Type dxgi_dev;
	hr = renctx.pDev->QueryInterface(__uuidof(IDXGIDevice), (void**)GSET_DXPTR(dxgi_dev));
	if( FAILED( hr ) ){
		return hr;
	}
	DXPtr<IDXGIAdapter>::Type dxgi_adapter;
	hr = dxgi_dev->GetAdapter(GSET_DXPTR(dxgi_adapter));
	if( FAILED( hr ) ){
		return hr;
	}
	DXPtr<IDXGIFactory>::Type dxgi_factory;
	hr = dxgi_adapter->GetParent(__uuidof(IDXGIFactory), (void**)GSET_DXPTR(dxgi_factory));
	if( FAILED( hr ) ){
		return hr;
	}

	// �X���b�v�`�F�C���쐬
	DXGI_SWAP_CHAIN_DESC sd;
	ZeroMemory( &sd, sizeof( sd ) );
	sd.BufferCount = 1;
	sd.BufferDesc.Width = width;
	sd.BufferDesc.Height = height;
	sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	sd.BufferDesc.RefreshRate.Numerator = 60;
	sd.BufferDesc.RefreshRate.Denominator = 1;	//1/60 = 60fps
	sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	sd.OutputWindow = hWnd;
	sd.SampleDesc = smpl_desc;
	sd.Windowed = TRUE;
	hr = dxgi_factory->CreateSwapChain(renctx.pDev.get(), &sd, GSET_DXPTR(renctx.pSwapChain));
	if( FAILED( hr ) ){
		return hr;
	}


	// �X���b�v�`�F�C���ɗp�ӂ��ꂽ�o�b�t�@�i2D�e�N�X�`���j���擾
	ITex2DPtr back_buff;
	hr = renctx.pSwapChain->GetBuffer( 0, __uuidof( ID3D11Texture2D ), (LPVOID*)GSET_DXPTR(back_buff) );
	if( FAILED( hr ) ){
		return hr;
	}

	hr = renctx.pDev->CreateRenderTargetView( back_buff.get(), NULL, GSET_DXPTR(renctx.pRTView) );
	if( FAILED( hr ) ){
		return hr;
	}

	// �f�v�X�o�b�t�@�쐬
	D3D11_TEXTURE2D_DESC decs_depth;
	ZeroMemory( &decs_depth, sizeof(decs_depth) );
	decs_depth.Width = width;
	decs_depth.Height = height;
	decs_depth.MipLevels = 1;
	decs_depth.ArraySize = 1;
	decs_depth.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
	decs_depth.SampleDesc = smpl_desc;
	decs_depth.Usage = D3D11_USAGE_DEFAULT;
	decs_depth.BindFlags = D3D11_BIND_DEPTH_STENCIL;
	decs_depth.CPUAccessFlags = 0;
	decs_depth.MiscFlags = 0;
	hr = renctx.pDev->CreateTexture2D( &decs_depth, NULL, GSET_DXPTR(renctx.pDepthS) );
	if( FAILED( hr ) ){
		return hr;
	}

	// DepthStencilView�쐬
	D3D11_DEPTH_STENCIL_VIEW_DESC descDSV;
	ZeroMemory( &descDSV, sizeof(descDSV) );
	descDSV.Format = decs_depth.Format;
	descDSV.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2DMS;
	
	
	hr = renctx.pDev->CreateDepthStencilView( renctx.pDepthS.get(), &descDSV, GSET_DXPTR(renctx.pDSView) );
	if( FAILED( hr ) ){
		return hr;
	}
	
	// �^�[�Q�b�g�r���[
	ID3D11RenderTargetView* const rtvs[] = {renctx.pRTView.get(),};
	renctx.pImCtx->OMSetRenderTargets( 1, rtvs, renctx.pDSView.get() );

	// viewport
	D3D11_VIEWPORT vp;
	vp.Width = (FLOAT)width;
	vp.Height = (FLOAT)height;
	vp.MinDepth = 0.0f;
	vp.MaxDepth = 1.0f;
	vp.TopLeftX = 0;
	vp.TopLeftY = 0;
	renctx.pImCtx->RSSetViewports( 1, &vp );

	D3D11_BUFFER_DESC bd;
	ZeroMemory( &bd, sizeof(bd) );
	// �萔�o�b�t�@�쐬
	bd.Usage = D3D11_USAGE_DEFAULT;
	bd.CPUAccessFlags = 0;
	bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	
	// �萔�o�b�t�@�@�V�[���p�����[�^
	bd.ByteWidth = sizeof(SCBScene);
	hr = renctx.pDev->CreateBuffer( &bd, NULL, GSET_DXPTR(renctx.pCBScene) );
	if( FAILED( hr ) ){
		return hr;
	}

	// �萔�o�b�t�@�@�����p�����[�^
	bd.ByteWidth = sizeof(SCBLight);
	hr = renctx.pDev->CreateBuffer( &bd, NULL, GSET_DXPTR(renctx.pCBLight) );
	if( FAILED( hr ) ){
		return hr;
	}

	// �萔�o�b�t�@ �ϊ��s��i�v���W�F�N�V�����A�r���[�j�̍X�V
	SCBScene& scbscn =  renctx.scbScene;
	XMVECTOR Eye = XMVectorSet( 0.0f, 11.0f, -32.0f, 0.0f );
	XMVECTOR At = XMVectorSet( 0.0f, 10.0f, 0.0f, 0.0f );
	XMVECTOR Up = XMVectorSet( 0.0f, 1.0f, 0.0f, 0.0f );
	scbscn.mtxView = XMMatrixTranspose(XMMatrixLookAtLH( Eye, At, Up ));
	scbscn.mtxProj = XMMatrixTranspose(XMMatrixPerspectiveFovLH( XM_PIDIV4*0.9f, width / (FLOAT)height, 0.1f, 1000.0f ));
	renctx.pImCtx->UpdateSubresource( renctx.pCBScene.get(), 0, NULL, &scbscn, 0, 0 );

	// �����p�����[�^�̍X�V
	SCBLight& scblight = renctx.scbLight;
	ZeroMemory( &scblight, sizeof(scblight) );
	scblight.vDirLight[0] = XMVector3Normalize( XMVectorSet(1,1.2f,-2.2f, 0) );
	scblight.colDirLight[0] = XMVectorSet(0.7f,0.7f,0.7f,0);
	scblight.vHemiDir = XMVectorSet(0,1,0,0);
	scblight.colHemiSky = XMVectorSet(0.2f,0.2f,0.3f,0.0f);
	scblight.colHemiGrd = XMVectorSet(0.3f,0.3f,0.2f,0.0f);
	renctx.pImCtx->UpdateSubresource( renctx.pCBLight.get(), 0, NULL, &scblight, 0, 0 );

	{// �V�F�[�_
		ResLibrary<SEffectPtr>& efflib = renctx.libEffect;//�V�F�[�_�G�t�F�N�g
	
		const WCHAR* shader_file[] = {
			BASIC_SHADER_FX_FILE,
			BLEND_SHADER_FX_FILE,
			OUTLINE_BLEND_SHADER_FX_FILE,
			SHADOW_BLEND_SHADER_FX_FILE,
			SCREEN_FILL_SHADER_FX_FILE,
		};
		const char* shader_name[] = {
			"basic",
			"basic_b",
			"outline_b",
			"shadow_b",
			"screen_fill",
		};
		zgU32 cnt = 0;
		for(auto& file : shader_file){
			SEffectPtr seffect;
			//�V�K�쐬
			seffect = CreateShaderEffectFromFile(file);
			if(!seffect){
				MessageBox( NULL, L"�V�F�[�_�G�t�F�N�g�쐬���s", file, MB_OK );
			}else{
				// �ǉ�
				efflib.AddRes(shader_name[cnt], seffect);
			}
			cnt++;
		}
	}

	for(int i=0;i<2;++i){
		g_aModel.push_back(SPtr<MeshModel>::Type(new MeshModel));
	}

	{//�n��
		MQOModel mqo;
		CreateMQOFromFile(L"data\\plane.mqo", mqo);
		zgmdl::ModelPtr zgmodel_mqo = CreateModel(mqo);
		g_aModel[0]->pModel = CreateModelX11(*zgmodel_mqo);
		g_aModel[0]->v3Pos = ZGVECTOR3(0,0,0);
		g_aModel[0]->colModel = ZGVECTOR4(1,1,1,1);
	}

	{//PMD���f��
		PMDModel pmd;
		VMDMotion vmd;
		bool load_pmd = CreatePMD(PMD_MODEL_FILE, pmd);
		bool load_vmd = CreateVMD(VMD_MOTION_FILE, vmd);
		if(!load_pmd || !load_vmd){
			MessageBox(NULL,  L"PMD�AVMD�t�@�C����������܂���B\nsample_data.h�Ƀt�@�C���p�X��ݒ肵�Ă��������B",L"",MB_OK);
		}

		zgmdl::ModelPtr zgmodel_pmd = CreateModel(pmd);
		g_aModel[1]->pModel = CreateModelX11(*zgmodel_pmd);
		g_aModel[1]->v3Pos = ZGVECTOR3(0,0,0);
		g_aModel[1]->colModel = ZGVECTOR4(1,1,1,1);
		g_aModel[1]->aIK = pmd.aIK;
	
		//���̃A�j���[�V���������@VMD�Đ���IK����
		CreateMeshModel(vmd, *zgmodel_pmd, *g_aModel[1]);
	}

	// �����_�����O���X�g�쐬
	for(auto& mdl : g_aModel){
		if(!mdl)continue;
		MeshModel& model = *mdl;
		if(!model.pModel)continue;

		{//�ʏ탌���_�����O
			RenListX11 ren_list;
			if( model.pModel->CreateRenList(0,0, ren_list) ){
				g_RenList.push_back(std::move(ren_list));
			}
		}
		{//�֊s��
			RenListX11 ren_list;
			if( model.pModel->CreateRenList(1,0, ren_list) ){
				g_OLineRenList.push_back(std::move(ren_list));
			}
		}
		{//�V���h�E�{�����[��
			RenListX11 ren_list;
			if( model.pModel->CreateRenList(2,0, ren_list) ){
				g_ShadowRenList.push_back(std::move(ren_list));
			}
		}
	}

	g_InitDX11 = true;
	return S_OK;
}


//---------------------------------------------------------
void ExitDX11()
{
	//if(!g_InitDX11)return;//���������ĂȂ�
	//�������Ə������r���Ŏ��s�����ꍇ���\�[�X���[�N����
	RenContextX11& renctx = GetRenContext();
	if( renctx.pImCtx ) renctx.pImCtx->ClearState();
	
	g_aModel.clear();
	g_RenList.clear();
	g_OLineRenList.clear();
	g_ShadowRenList.clear();

	g_RenCtx.Clear();

	if(!g_InitDX11)return;//���������ĂȂ�
	g_InitDX11 = false;
}

namespace{
struct REN_PASS
{
	REN_PASS() : iPass(0){}
	REN_PASS(zgU32 ip, const SPassPtr& pass) : iPass(ip), pPass(pass){}

	bool operator<(const REN_PASS& rp) const {return iPass<rp.iPass;}

	zgU32 iPass;
	SPassPtr pPass;
};


}

//---------------------------------------------------------
void RenderDX11()
{
 	RenContextX11& renctx = GetRenContext();

	//��]
	static float g_fRotY = 0.0f;
	static DWORD dwTimeStart = 0;
	DWORD dwTimeCur = GetTickCount();
	if( dwTimeStart == 0 ) dwTimeStart = dwTimeCur;
	g_fRotY = 0;//( dwTimeCur - dwTimeStart ) / 1000.0f;

	float key_time = float( dwTimeCur - dwTimeStart ) / 33.333f;

	std::vector<REN_PASS> pass_list;
	XMMATRIX mmmm = XMMatrixIdentity();
	zgU32 mdl_cnt = 0;
	for(auto& mdl : g_aModel){
		if(!mdl)continue;
		MeshModel& model = *mdl;

		XMMATRIX mtx = XMMatrixTranslation(model.v3Pos.x, model.v3Pos.y, model.v3Pos.z);
		if(mdl_cnt == 0){
			mtx = XMMatrixTranspose(mtx);
		}else{
			mtx = XMMatrixMultiplyTranspose(XMMatrixRotationY(g_fRotY), mtx);
		}

		if(!model.pModel)continue;
		ModelX11& mdx11 = *model.pModel;

		//�{�[���s��X�V
		if( mdx11.numBoneMtx > 0 && model.numBone==mdx11.numBoneMtx ){

			// �A�j���[�V����
			VMDAnimation(key_time, model);

			// �A�j���[�V�����Ń��[�J���s�񂪕ύX���ꂽ�̂�
			// ���[���h�s����Čv�Z
			model.UpdatePose();

			// IK
			PMDIkAnimation(model);
		}

		// �{�[�������s��̍쐬�A�萔�o�b�t�@�ɓ]��
		if( mdx11.numBoneMtx > 0 && mdx11.pCBBoneMtx ){
			XMMATRIX* mtx_pose = reinterpret_cast<XMMATRIX*>(model.binMtxPose.get());
			XMMATRIX* mtx_init = reinterpret_cast<XMMATRIX*>(model.binMtxInitBone.get());
			MATRIX43* mtx_sub = reinterpret_cast<MATRIX43*>(model.binMtxSubBone.get());
			for(zgU32 ib=0;ib<mdx11.numBoneMtx;++ib){
				XMMATRIX mtx = XMMatrixMultiplyTranspose(
									XMMatrixInverse(nullptr,mtx_init[ib]),mtx_pose[ib]);
				mtx_sub[ib].r[0] = mtx.r[0];
				mtx_sub[ib].r[1] = mtx.r[1];
				mtx_sub[ib].r[2] = mtx.r[2];
			}
			if( model.binMtxSubBone.size() <= mdx11.sizeBoneMtx){
				renctx.pImCtx->UpdateSubresource( mdx11.pCBBoneMtx.get(), 0, NULL, model.binMtxSubBone.get(), 0, 0 );
			}
		}

		// ���f���p�����[�^�X�V
		SCBModel sbc_model;
		sbc_model.colModel = XMVectorSet(model.colModel.x,model.colModel.y,model.colModel.z,model.colModel.w);
		renctx.pImCtx->UpdateSubresource( mdx11.pCBModel.get(), 0, NULL, &sbc_model, 0, 0 );

		for(auto& obj : mdx11.apObj){
			if(!obj)continue;
			
			// �p���s����X�V
			SCBObject cbobj;
			cbobj.mtxWorld = mtx;
			renctx.pImCtx->UpdateSubresource( obj->pCBObject.get(), 0, NULL, &cbobj, 0, 0 );
		}
	}

	mdl_cnt = 0;
	for(auto& rl : g_RenList){
		for(auto& elem : rl.aDList){
			pass_list.push_back( REN_PASS((elem.idxPass|(mdl_cnt)<<4), elem.pPass));
		}
		++mdl_cnt;
	}
	for(auto& rl : g_OLineRenList){
		for(auto& elem : rl.aDList){
			pass_list.push_back( REN_PASS((elem.idxPass|(mdl_cnt)<<4), elem.pPass));
		}
		++mdl_cnt;
	}
	for(auto& rl : g_ShadowRenList){
		for(auto& elem : rl.aDList){
			pass_list.push_back( REN_PASS((elem.idxPass|(mdl_cnt)<<4), elem.pPass));
		}
		++mdl_cnt;
	}

	// �p�X�Ń\�[�g
	// ShaderPass���Ɨ����������ŏ��ԂɈˑ����Ȃ��̂Ń\�[�g���ł���
	std::sort(pass_list.begin(),pass_list.end());


	// �w��F�ŉ�ʃN���A
	//float ClearColor[4] = { 0.0f, 0.125f, 0.3f, 1.0f }; //red,green,blue,alpha
	float ClearColor[4] = { 0.2f, 0.4f, 0.8f, 1.0f }; //red,green,blue,alpha
	renctx.pImCtx->ClearRenderTargetView( renctx.pRTView.get(), ClearColor );

	//�f�v�X�o�b�t�@�N���A
	renctx.pImCtx->ClearDepthStencilView( renctx.pDSView.get(), D3D11_CLEAR_DEPTH|D3D11_CLEAR_STENCIL, 1.0f, 0 );

	//�p�X���X�g�ɒǉ����ꂽShaderPass��`��
	for(auto& p : pass_list){
		ShaderPass& pass = *p.pPass;
		
		// ���̓��C�A�E�g
		renctx.pImCtx->IASetInputLayout( pass.pLayout.get() );

		// �C���f�b�N�X�o�b�t�@
		renctx.pImCtx->IASetIndexBuffer( pass.pIBuff.get(), DXGI_FORMAT_R16_UINT, 0 );

		// ���_�o�b�t�@
		ID3D11Buffer* vbs[ShaderPass::VBUFF_MAXNUM];
		for(zgU32 vi=0;vi<pass.numVBuff;++vi){
			vbs[vi] = pass.apVBuff[vi].get();
		};
		renctx.pImCtx->IASetVertexBuffers( 0, pass.numVBuff, vbs,
										pass.aStride.data(), pass.aOffset.data() );

		// �X�e�[�g
		FLOAT bdfactor[4]={0,0,0,0};
		renctx.pImCtx->RSSetState( pass.pRsState.get() );
		renctx.pImCtx->OMSetBlendState( pass.pBdState.get(), bdfactor, 0xffffffff );
		renctx.pImCtx->OMSetDepthStencilState( pass.pDsState.get(), 0 );
	
		// �V�F�[�_
		{
			ID3D11Buffer* cb[ShaderPass::CBUFF_MAXNUM];
			for(zgU32 ci=0;ci<pass.numCBuff;++ci){
				cb[ci] = pass.apCBuff[ci].get();
			}
			renctx.pImCtx->VSSetConstantBuffers( 0, pass.numCBuff, cb );
			renctx.pImCtx->VSSetShader( pass.pVShader.get(), NULL, 0 );

			renctx.pImCtx->GSSetShader( pass.pGShader.get(), NULL, 0 );
			if(pass.pGShader.get()){
				renctx.pImCtx->GSSetConstantBuffers( 0, pass.numCBuff, cb );
			}


			ID3D11ShaderResourceView* srv[ShaderPass::TEX_MAXNUM];
			ID3D11SamplerState* ss[ShaderPass::TEX_MAXNUM];
			for(zgU32 ti=0;ti<pass.numTex;++ti){
				srv[ti] = pass.apSRView[ti].get();
				ss[ti] = pass.apSpState[ti].get();
			}
			renctx.pImCtx->PSSetShaderResources( 0, pass.numTex, srv );
			renctx.pImCtx->PSSetSamplers( 0, pass.numTex, ss );

			renctx.pImCtx->PSSetShader( pass.pPShader.get(), NULL, 0 );
			renctx.pImCtx->PSSetConstantBuffers( 0, pass.numCBuff, cb );
		}

		// �v���~�e�B�u�`��
		renctx.pImCtx->IASetPrimitiveTopology( pass.eTopo ); 
		//�|���S���`��
		renctx.pImCtx->DrawIndexed( pass.nCount, 0, 0 );
	}

	// �e�̕`��
	do{
		ResLibrary<SEffectPtr>& efflib = renctx.libEffect;//�V�F�[�_�G�t�F�N�g
		SEffectPtr seffect;
		if( !efflib.getRes("screen_fill", seffect) )break;

		ShaderEffect::PASS& pass = seffect->aTech[0].aPass[0];


		D3D11_INPUT_ELEMENT_DESC layout[] = {
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 20, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		};
		UINT elem_num = ARRAYSIZE( layout );
		IILayoutPtr ilayout;
		renctx.pDev->CreateInputLayout( layout, elem_num, pass.pVSCode->GetBufferPointer(),
											pass.pVSCode->GetBufferSize(), GSET_DXPTR(ilayout) );
		IBuffPtr vtxbuff;
		float vertex[4*9] = {
			-1.0f, -1.0f, 0.0f,  0.0f,0.0f,  1.0f,1.0f,1.0f,1.0f,
			1.0f, -1.0f, 0.0f,  1.0f,0.0f,  1.0f,1.0f,1.0f,1.0f,
			-1.0f, 1.0f, 0.0f,  0.0f,1.0f,  1.0f,1.0f,1.0f,1.0f,
			1.0f, 1.0f, 0.0f,  1.0f,1.0f,  1.0f,1.0f,1.0f,1.0f,
		};
		D3D11_BUFFER_DESC bd;
		ZeroMemory( &bd, sizeof(bd) );
		bd.Usage = D3D11_USAGE_DEFAULT;
		bd.ByteWidth = sizeof( vertex );
		bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		bd.CPUAccessFlags = 0;
		D3D11_SUBRESOURCE_DATA InitData;
		ZeroMemory( &InitData, sizeof(InitData) );
		InitData.pSysMem = vertex;
		renctx.pDev->CreateBuffer( &bd, &InitData, GSET_DXPTR(vtxbuff) );
		
		
		renctx.pImCtx->IASetInputLayout( ilayout.get() );
		UINT stride = 36;
		UINT offset = 0;
		ID3D11Buffer* buff = vtxbuff.get();
		renctx.pImCtx->IASetVertexBuffers( 0, 1, &buff, &stride, &offset );

		// �X�e�[�g
		FLOAT bdfactor[4]={0,0,0,0};
		renctx.pImCtx->RSSetState( pass.pRsState.get() );
		renctx.pImCtx->OMSetBlendState( pass.pBdState.get(), bdfactor, 0xffffffff );
		renctx.pImCtx->OMSetDepthStencilState( pass.pDsState.get(), 0 );

		renctx.pImCtx->IASetPrimitiveTopology( D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP );
		renctx.pImCtx->VSSetShader( pass.pVShader.get(), nullptr, 0 );
		renctx.pImCtx->GSSetShader( nullptr, nullptr, 0 );
		renctx.pImCtx->PSSetShader( pass.pPShader.get(), nullptr, 0 );
		renctx.pImCtx->Draw( 4, 0 );


	}while(0);

	//���ʂ��E�C���h�E�ɔ��f
    renctx.pSwapChain->Present( 0, 0 );
}
