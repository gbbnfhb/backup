#include "stdafx.h"

#include "zg_preprocess.h"

#include <fstream>
#include <vector>
#include <memory>


namespace {

class Include : public ID3DInclude
{
public:
	Include(){aPath.push_back("");}
 
	HRESULT __stdcall Open(D3D_INCLUDE_TYPE IncludeType, LPCSTR pFileName, LPCVOID pParentData, LPCVOID *ppData, UINT *pBytes);
	HRESULT __stdcall Close(LPCVOID pData);

	std::vector<std::string> aPath;//�����p�X
};

HRESULT __stdcall Include::Open(D3D_INCLUDE_TYPE IncludeType, LPCSTR pFileName, LPCVOID pParentData, LPCVOID *ppData, UINT *pBytes)
{
	switch(IncludeType) {
		// �Ƃ肠����""��<>�̋�ʂȂ�
	case D3D_INCLUDE_LOCAL:
	case D3D_INCLUDE_SYSTEM:
		break;
	default:
		return E_FAIL;
	}
	
	for(auto& p : aPath){
		std::string path = p;
		path += pFileName;

		std::ifstream input;
		input.open(path.c_str(), std::ios::binary);
		if(!input.is_open())continue;

		size_t fsize = (size_t)input.seekg(0, std::ios::end).tellg();
		input.seekg(0, std::ios::beg);

		void* data = ::operator new(fsize);
		input.read(reinterpret_cast<char*>(data), fsize);
		*ppData = data;
		*pBytes = fsize;
		return S_OK;
	}
	return E_FAIL;
}
HRESULT __stdcall Include::Close(LPCVOID pData)
{
	::operator delete(const_cast<void*>(pData));
	return S_OK;
}

}//ns

namespace zg
{

Preprocessor::~Preprocessor()
{
	if(pResult)pResult->Release();
	if(pError)pError->Release();
}

const void* Preprocessor::getResult() const
{
	return pResult? pResult->GetBufferPointer() : nullptr;
}

size_t Preprocessor::getResultSize() const
{
	return pResult? pResult->GetBufferSize() : 0;
}

const void* Preprocessor::getError() const
{
	return pError? pError->GetBufferPointer() : nullptr;
}

size_t Preprocessor::getpErrorSize() const
{
	return pError? pError->GetBufferSize() : 0;
}

void Preprocessor::ReleaseBlob()
{
	if(pResult)pResult->Release();
	if(pError)pError->Release();
	pResult = nullptr;
	pError = nullptr;
}

HRESULT Preprocessor::RunFile(const char* file)
{

	// �t�@�C���ǂݍ���
	std::ifstream input;
	input.open(file, std::ios::binary);
	if(!input.is_open())return E_FAIL;
	size_t fsize = (size_t)input.seekg(0, std::ios::end).tellg();
	input.seekg(0, std::ios::beg);
	ID3DBlob* blob = nullptr;
	D3DCreateBlob(fsize, &blob);
	void* b = blob->GetBufferPointer();
	input.read(reinterpret_cast<char*>(b), fsize);

	// include�̃J�����g�p�X
	size_t len = strlen(file)+1;
	std::vector<char> drv(len),path(len),name(len),ext(len);
	_splitpath_s(file, drv.data(),len, path.data(),len, name.data(),len, ext.data(),len);
	std::string cur_path = "";
	if( drv[0] || path[0] ){
		cur_path = drv.data();
		cur_path += path.data();
	}

	return Run(b, fsize, file, cur_path.c_str());
}

HRESULT Preprocessor::Run(const void* src, size_t size, const char* name, const char* inc_path)
{
	ReleaseBlob();
	std::unique_ptr<Include> ic( new Include );
	if(inc_path)ic->aPath.push_back( inc_path );
	//return D3DPreprocess(src, size, name, nullptr, D3D_COMPILE_STANDARD_FILE_INCLUDE, &pResult, &pError);
	return D3DPreprocess(src, size, name, nullptr, ic.get(), &pResult, &pError);
}

}//zg
