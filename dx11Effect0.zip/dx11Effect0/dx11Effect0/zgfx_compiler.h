#pragma once

namespace zgfx
{


class ZGFXCompiler
{
public:
	ZGFXCompiler();
	~ZGFXCompiler();

	bool Compile(const char* data, size_t size);
private:
};



}//zgfx