#pragma once

#include <string>
#include <map>

namespace zg {
namespace lex {

typedef int LexToken;
typedef char LexChar;
typedef int LexInt;
typedef float LexFloat;
typedef std::string LexString;

#define ZGLEXCHAR( _str ) _str

enum
{
	TK_TERMINATE = -1,//�I��
	TK_ERROR = -2,
	TK_ERR_NUMBER = -3,	// ���l��̓G���[

	TK_IDENTIFIER = 0x20000,
	TK_STRING,
	TK_INTEGER,
	TK_FLOAT,

	TK_EQ,		// ==
	TK_LE,		// <=
	TK_GE,		// >=
	TK_NE,		// !=
	TK_AND,		// &&
	TK_OR,		// ||

	TK_SHIFTL,	// <<
	TK_SHIFTR,	// >>

	TK_DIVEQ,	// /=
	TK_MULEQ,	// *=
	TK_MODEQ,	// %=
	TK_MINUSEQ,	// -=
	TK_PLUSEQ,	// +=

	TK_MINUSMINUS,	// --
	TK_PLUSPLUS,	// ++

	TK_KEYWORD_TOP = 0x30000,
	TK_KEYWORD_END = 0x3FFFF,
};


//--------------------
struct LexRead
{
	LexRead(const LexChar* start, const LexChar* end)
		: pStart(start), pEnd(end), pCurrent(start)
	{}

	// �����ǂݍ��݁@0�ŏI��
	LexInt Read()
	{
		if( pCurrent >= pEnd )return 0;
		LexInt c = *pCurrent++;
		return c;
	};

	const LexChar* pStart;
	const LexChar* pEnd;
	const LexChar* pCurrent;
};

//---------------------
// ������
struct Lexer
{
	Lexer(LexRead* lread);

	// �L�[���[�h�ǉ�
	// tk : TK_KEYWORD_TOP�`TK_KEYWORD_END
	void AddKeyword(const LexString& key, LexToken tk);

	// ������
	LexToken Lex();

	// ��͏I���H
	bool isEof() const;
	
	// ���݂̎���ID
	LexToken getToken() const;

	// ���݂̐����l�@TK_INTEGER=getToken()�̂ݗL��
	LexInt getIntVal() const;
	
	// ���݂̕��������l�@TK_FLOATR=getToken()�̂ݗL��
	LexFloat getFloatVal() const;
	
	// ���݂̕�����@TK_STRING,TK_IDENTIFIER,KEYWORD
	const LexString& getStrVal() const;

	int getLine() const { return nCurLine;}
	int getColumn() const { return nCurColumn;}
	const LexChar* getFile() const { return strCurFile.c_str();}
private:
	Lexer();

	void Error(const LexChar* error);

	void Next();
	void NextCol();
	void Token(LexToken t);
	LexToken RetToken(LexToken t);
	LexInt getCur() const;
	const LexString& getCurString() const;
	
	void SkipSpace();
	void LineComment();
	bool ReadString();
	LexToken ReadNumber();
	LexToken ReadID();

	LexRead* pRead;
	LexChar valCur;
	LexString strCur;
	LexInt valInt;
	LexFloat valFloat;
	LexString valString;
	LexToken iToken;
	bool bEof;
	int nCurLine;
	int nCurColumn;
	LexString strCurFile;
	LexString strLine;

	// keyword
	std::map<LexString,LexToken> mapKeywords;
	LexToken getKeyToken(const LexString& key) const;
};

} }//lex zg
