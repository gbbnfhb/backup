#pragma once

#include <d3dcompiler.h>

namespace zg
{

class Preprocessor
{
public:
	Preprocessor() : pResult(nullptr), pError(nullptr) {}
	~Preprocessor();

	HRESULT RunFile(const char* file);
	HRESULT Run(const void* src, size_t size, const char* name, const char* inc_path=nullptr);

	const void* getResult() const;
	size_t getResultSize() const;

	const void* getError() const;
	size_t getpErrorSize() const;

private:
	ID3DBlob* pResult;
	ID3DBlob* pError;

	void ReleaseBlob();

	Preprocessor& operator=(const Preprocessor&);
	Preprocessor& operator=(const Preprocessor&&);
	Preprocessor( const Preprocessor&);
	Preprocessor( const Preprocessor&&);
};

}//zg

