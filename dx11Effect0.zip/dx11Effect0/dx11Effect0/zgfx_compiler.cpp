#include "stdafx.h"

#include "zgfx_compiler.h"

#include "zg_lexer.h"

using namespace zg::lex;

enum {
	TKFX_TECHNIQUE11 = TK_KEYWORD_TOP,
	TKFX_PASS,
	TKFX_STRUCT,		// struct
	TKFX_CBUFFER,		// cbuffer
	TKFX_SAMPLER_STATE,	// SamplerState
	TKFX_BLEND_STATE,	// BlendState
	TKFX_DEPTH_STATE,	// DepthStencilState
	TKFX_RASTER_STATE,	// RasterizerState

	TKFX_SET_BLEND_STATE,	// SetBlendState
	TKFX_SET_DEPTH_STATE,	// SetDepthStencilState
	TKFX_SET_RASTER_STATE,	// SetRasterizerState
	TKFX_SET_VERTEX_SHADER,	// SetVertexShader
	TKFX_SET_PIXEL_SHADER,	// SetPixelShader
	TKFX_COMPILE_SHADER		// CompileShader
};

//------------------------
struct Compiler
{
	Compiler(LexRead* read)
		: Lex(read)
	{
		Lex.AddKeyword("technique11", TKFX_TECHNIQUE11);
		Lex.AddKeyword("pass", TKFX_PASS);
		Lex.AddKeyword("struct", TKFX_STRUCT);
		Lex.AddKeyword("cbuffer", TKFX_CBUFFER);
		Lex.AddKeyword("SamplerState", TKFX_SAMPLER_STATE);
		Lex.AddKeyword("BlendState", TKFX_BLEND_STATE);
		Lex.AddKeyword("DepthStencilState", TKFX_DEPTH_STATE);
		Lex.AddKeyword("RasterizerState", TKFX_RASTER_STATE);

		Lex.AddKeyword("SetBlendState", TKFX_SET_BLEND_STATE);
		Lex.AddKeyword("SetDepthStencilState", TKFX_SET_DEPTH_STATE);
		Lex.AddKeyword("SetRasterizerState", TKFX_SET_RASTER_STATE);
		Lex.AddKeyword("SetVertexShader", TKFX_SET_VERTEX_SHADER);
		Lex.AddKeyword("SetPixelShader", TKFX_SET_PIXEL_SHADER);
		Lex.AddKeyword("CompileShader", TKFX_COMPILE_SHADER);
	}

	bool Compile();
private:
	// �\���̒�`���
	bool ParseStruct();

	// �萔�o�b�t�@��`���
	bool ParseCBuffer();

	// �ϐ��܂��͊֐�
	bool ParseVarFunc();

	// �ϐ��^�̉��
	bool ParseVarType();

	// SamplerState�̉��
	bool ParseSamplerState();
	// BlendState�̉��
	bool ParseBlendState();
	// DepthStencilState�̉��
	bool ParseDepthState();
	// RasterizerState�̉��
	bool ParseRasterState();

	// �e�N�j�b�N��`���
	bool ParseTechnique();

	// �p�X��`���
	bool ParsePass();

	// Pass{ Set�`
	bool ParseSetBlendState();
	bool ParseSetDepthStencilState();
	bool ParseSetRasterizerState();
	bool ParseSetVertexShader();
	bool ParseSetPixelShader();



	bool tryparse_sema(LexString& str, LexString& reg, bool lex=true);
	bool get_float(LexFloat& fval, bool lex=true);
	bool get_int(LexInt& ival, bool lex=true);
	bool get_id(LexString& str, bool lex=true);
	bool get_CompileShader(LexString& profile, LexString& func);

	bool check_char(LexChar ch, bool lex=true);
	bool check_chars(const LexChar* str, bool lex=true);

	// �X�R�[�v�̃X�L�b�v�@'{'����'}'�܂�
	bool skip_scope(bool semicolon);

	bool skip_token(LexToken tk);

	enum STATE_VAL
	{
		SV_ERROR = -1,
		SV_END = 0,
		SV_INTEGER = 1,
		SV_FLOAT,
		SV_IDENTIFIER,
	};
	STATE_VAL parse_StateValue(LexString& name, LexInt& aryidx, LexInt& ival, LexFloat& fval, LexString& str);

	void Error(const LexChar* error)
	{
		int err = 0;
		int line = Lex.getLine();
		int col = Lex.getColumn();
		const LexChar* file = Lex.getFile();
		char text[256];
		sprintf_s(text,"%s(%d,%d):%s\n", file,line,col,error);
		OutputDebugStringA(text);
	}
	Lexer Lex;
};

//--------------------
bool Compiler::Compile()
{
	Lex.Lex();
	while(!Lex.isEof()){
		LexToken tk = Lex.getToken();
		switch(tk){
		//-- �\���̒�` --
		case TKFX_STRUCT:
			if(!ParseStruct()){ return false;}
			break;
		//-- �萔�o�b�t�@ --
		case TKFX_CBUFFER:
			if(!ParseCBuffer()){ return false;}
			break;
		//-- ���ʎq --
		case TK_IDENTIFIER:
			if(!ParseVarFunc()){ return false;}
			break;
		//-- SamplerState --
		case TKFX_SAMPLER_STATE:
			if(!ParseSamplerState()){ return false;}
			break;
		//-- BlendState --
		case TKFX_BLEND_STATE:
			if(!ParseBlendState()){ return false;}
			break;
		//-- DepthStencilState --
		case TKFX_DEPTH_STATE: 
			if(!ParseDepthState()){ return false;}
			break;
		//-- RasterizerState --
		case TKFX_RASTER_STATE:
			if(!ParseRasterState()){ return false;}
			break;
		//-- technique11 --
		case TKFX_TECHNIQUE11:
			if(!ParseTechnique()){ return false;}
			break;

		default:
			Error(ZGLEXCHAR("Syntax error"));
			return false;
		}
	}

	return true;
}

// �\���̒�`���
bool Compiler::ParseStruct()
{
	//�I���܂ŃX�L�b�v
	
	// �\���̖�
	LexString name;
	if( !get_id(name) ){
		Error(ZGLEXCHAR("Invalided struct name"));
		return false;
	}

	//{};��`�Ō�܂ŃX�L�b�v
	if( !skip_scope(true) ){
		Error(ZGLEXCHAR("Invalided struct definition"));
		return false;	
	}

	return true;
}	

// �萔�o�b�t�@��`���
bool Compiler::ParseCBuffer()
{
	//�I���܂ŃX�L�b�v
	//{};��`�Ō�܂ŃX�L�b�v
	if( !skip_scope(true) ){
		Error(ZGLEXCHAR("Invalided cbuffer definition"));
		return false;	
	}

	return true;
}
// �ϐ��܂��͊֐�
bool Compiler::ParseVarFunc()
{
	// �^��
	if( !ParseVarType() )return false;

	// �ϐ�or�֐���
	LexString name;
	if( !get_id(name, false) ){
		Error(ZGLEXCHAR("Invalided variable name"));
		return false;
	}

	LexToken tk = Lex.Lex();
	if( tk == ZGLEXCHAR('(') ){

		//�֐���`
		if( !skip_token(ZGLEXCHAR(')')) ){
			Error(ZGLEXCHAR("Invalided function	arg"));
			return false;
		}
		if( !skip_scope(false) ){
			Error(ZGLEXCHAR("Invalided function	def"));
			return false;
		}
	}else{
		//�ϐ���`
		if( !skip_token(ZGLEXCHAR(';')) ){
			Error(ZGLEXCHAR("Invalided variable	"));
			return false;
		}
	}
	return true;
}

// �ϐ��^�̉��
bool Compiler::ParseVarType()
{
	// �^��
	LexString name;
	if( !get_id(name, false) ){
		Error(ZGLEXCHAR("Invalided typename"));
		return false;
	}

	LexToken tk = Lex.Lex();
	if( tk != ZGLEXCHAR('<') ){
		return true;//�^���I��
	}
	//<>�@�I�u�W�F�N�g�^ skip
	while(!Lex.isEof()){
		tk = Lex.Lex();
		if( tk == ZGLEXCHAR('>') )break;
	}
	if( Lex.isEof() ){
		Error(ZGLEXCHAR("Invalided typename"));
		return false;
	}
	Lex.Lex();

	return true;
}

//------------------
Compiler::STATE_VAL Compiler::parse_StateValue(LexString& name, LexInt& aryidx,LexInt& ival, LexFloat& fval, LexString& str)
{
	LexToken tk = Lex.getToken();

	if( tk == ZGLEXCHAR('}') )return SV_END;
	if(tk != TK_IDENTIFIER)return SV_ERROR;
	name = Lex.getStrVal();

	aryidx = 0;
	tk = Lex.Lex();
	if( tk == ZGLEXCHAR('[') ){//�z��
		tk = Lex.Lex();
		if( tk != TK_INTEGER )return SV_ERROR;
		aryidx = Lex.getIntVal();
		tk = Lex.Lex();
		if( tk != ZGLEXCHAR(']') )return SV_ERROR;;
		tk = Lex.Lex();
	}
	
	if( tk != ZGLEXCHAR('=') )return SV_ERROR;

	STATE_VAL ret = SV_ERROR;
	// �l
	tk = Lex.Lex();
	switch( tk ){
	case TK_INTEGER:
		ival = Lex.getIntVal();
		ret = SV_INTEGER;
		break;
	case TK_FLOAT:
		fval = Lex.getFloatVal();
		ret = SV_FLOAT;
		break;
	case TK_IDENTIFIER:
		str = Lex.getStrVal();
		ret = SV_IDENTIFIER;
		break;
	default:
		Error(ZGLEXCHAR("Invalided SamplerState value"));
		return SV_ERROR;
	}
		
	tk = Lex.Lex();
	if( tk != ZGLEXCHAR(';') )return SV_ERROR;

	tk = Lex.Lex();
	return ret;
}

// SamplerState�̉��
bool Compiler::ParseSamplerState()
{
	// �ϐ���
	//if( tk != TK_IDENTIFIER ){
	LexString name;
	if( !get_id(name) ){
		Error(ZGLEXCHAR("Invalided SamplerState name"));
		return false;
	}

	// �Z�}���e�B�N�X
	LexString sema,reg;
	tryparse_sema(sema,reg);

	LexToken tk = Lex.getToken();
	if( tk == ZGLEXCHAR(';') ){//�I��
		Lex.Lex();
		return true;
	}
	if( tk != ZGLEXCHAR('{') ){
		Error(ZGLEXCHAR("Invalided SamplerState def"));
		return false;
	}

	// state[n] = val;�̉��
	tk = Lex.Lex();
	while(!Lex.isEof()){
		LexString name, sval;
		LexInt ival,aryidx;
		LexFloat fval;
		STATE_VAL sv = parse_StateValue(name,aryidx, ival,fval, sval);
		if(sv == SV_ERROR){
			Error(ZGLEXCHAR("Invalided SamplerState def"));
			return false;
		}
		if( sv == SV_END )break;
	}

	if(!check_chars(ZGLEXCHAR("};"),false)){
		Error(ZGLEXCHAR("Invalided SamplerState def"));
		return false;
	}

	Lex.Lex();
	return true;
}
// BlendState�̉��
bool Compiler::ParseBlendState()
{
	// �ϐ���
	LexString name;
	if( !get_id(name) ){
		Error(ZGLEXCHAR("Invalided SamplerState name"));
		return false;
	}

	LexToken tk = Lex.Lex();
	if( tk == ZGLEXCHAR(';') ){
		Lex.Lex();
		return true;
	}
	if( tk != ZGLEXCHAR('{') ){
		Error(ZGLEXCHAR("Invalided SamplerState def"));
		return false;
	}
	// state[n] = val;�̉��
	tk = Lex.Lex();
	while(!Lex.isEof()){
		LexString name, sval;
		LexInt ival,aryidx;
		LexFloat fval;
		STATE_VAL sv = parse_StateValue(name,aryidx, ival,fval, sval);
		if(sv == SV_ERROR){
			Error(ZGLEXCHAR("Invalided SamplerState def"));
			return false;
		}
		if( sv == SV_END )break;
	}

	if(!check_chars(ZGLEXCHAR("};"),false)){
		Error(ZGLEXCHAR("Invalided SamplerState def"));
		return false;
	}

	Lex.Lex();
	return true;
}
// DepthStencilState�̉��
bool Compiler::ParseDepthState()
{
	// �ϐ���
	LexString name;
	if( !get_id(name) ){
		Error(ZGLEXCHAR("Invalided SamplerState name"));
		return false;
	}

	LexToken tk = Lex.Lex();
	if( tk == ZGLEXCHAR(';') ){
		Lex.Lex();
		return true;
	}
	if( tk != ZGLEXCHAR('{') ){
		Error(ZGLEXCHAR("Invalided SamplerState def"));
		return false;
	}
	// state[n] = val;�̉��
	tk = Lex.Lex();
	while(!Lex.isEof()){
		LexString name, sval;
		LexInt ival,aryidx;
		LexFloat fval;
		STATE_VAL sv = parse_StateValue(name,aryidx, ival,fval, sval);
		if(sv == SV_ERROR){
			Error(ZGLEXCHAR("Invalided SamplerState def"));
			return false;
		}
		if( sv == SV_END )break;
	}

	if(!check_chars(ZGLEXCHAR("};"),false)){
		Error(ZGLEXCHAR("Invalided SamplerState def"));
		return false;
	}

	Lex.Lex();
	return true;
}
// RasterizerState�̉��
bool Compiler::ParseRasterState()
{
	// �ϐ���
	LexString name;
	if( !get_id(name) ){
		Error(ZGLEXCHAR("Invalided SamplerState name"));
		return false;
	}

	LexToken tk = Lex.Lex();
	if( tk == ZGLEXCHAR(';') ){
		Lex.Lex();
		return true;
	}
	if( tk != ZGLEXCHAR('{') ){
		Error(ZGLEXCHAR("Invalided SamplerState def"));
		return false;
	}
	// state[n] = val;�̉��
	tk = Lex.Lex();
	while(!Lex.isEof()){
		LexString name, sval;
		LexInt ival,aryidx;
		LexFloat fval;
		STATE_VAL sv = parse_StateValue(name,aryidx, ival,fval, sval);
		if(sv == SV_ERROR){
			Error(ZGLEXCHAR("Invalided SamplerState def"));
			return false;
		}
		if( sv == SV_END )break;
	}

	if(!check_chars(ZGLEXCHAR("};"),false)){
		Error(ZGLEXCHAR("Invalided SamplerState def"));
		return false;
	}

	Lex.Lex();
	return true;
}


// �e�N�j�b�N��`���
bool Compiler::ParseTechnique()
{
	// �e�N�j�b�N��
	LexString name;
	if( !get_id(name) ){
		Error(ZGLEXCHAR("Invalided technique def"));
		return false;
	}

	LexToken tk = Lex.Lex();
	if(tk != ZGLEXCHAR('{') ){
		Error(ZGLEXCHAR("Invalided technique def"));
		return false;
	}
	Lex.Lex();

	// �p�X
	while(!Lex.isEof()){
		tk = Lex.getToken();
		if( tk == TKFX_PASS ){
			if( !ParsePass() ){
				return false;
			}
		}else if( tk == ZGLEXCHAR('}') ){
			break;
		}else{
			Error(ZGLEXCHAR("Invalided technique def"));
			return false;
		}
	}

	Lex.Lex();

	return true;
}

// �p�X��`���
bool Compiler::ParsePass()
{
	// �p�X��
	LexString name;
	if( !get_id(name) ){
		Error(ZGLEXCHAR("Invalided pass def"));
		return false;
	}

	LexToken tk = Lex.Lex();
	if(tk != ZGLEXCHAR('{') ){
		Error(ZGLEXCHAR("Invalided pass def"));
		return false;
	}

	tk = Lex.Lex();
	while(!Lex.isEof()){
		tk = Lex.getToken();
		if( tk == ZGLEXCHAR('}') )break;

		switch(tk){
		case TKFX_SET_BLEND_STATE:	// SetBlendState
			if(!ParseSetBlendState()){
				Error(ZGLEXCHAR("Invalided SetBlendState def"));
				return false;
			}
			break;
		case TKFX_SET_DEPTH_STATE:	// SetDepthStencilState
			if(!ParseSetDepthStencilState()){
				Error(ZGLEXCHAR("Invalided SetDepthStencilState def"));
				return false;
			}
			break;
		case TKFX_SET_RASTER_STATE:	// SetRasterizerState
			if(!ParseSetRasterizerState()){
				Error(ZGLEXCHAR("Invalided SetRasterizerState def"));
				return false;
			}
			break;
		case TKFX_SET_VERTEX_SHADER:	// SetVertexShader
			if(!ParseSetVertexShader()){
				Error(ZGLEXCHAR("Invalided SetVertexShader def"));
				return false;
			}
			break;
		case TKFX_SET_PIXEL_SHADER:	// SetPixelShader
			if(!ParseSetPixelShader()){
				Error(ZGLEXCHAR("Invalided SetPixelShader def"));
				return false;
			}
			break;
		default:
			Error(ZGLEXCHAR("Invalided pass def"));
			return false;
		}
	}

	Lex.Lex();
	return true;
}

// Pass{ Set�`
bool Compiler::ParseSetBlendState()
{
	if( !check_char(ZGLEXCHAR('(')) ){return false;}

	// �X�e�[�g�ϐ���
	LexString name;
	if( !get_id(name) ){return false;}
	if( !check_char(ZGLEXCHAR(',')) ){return false;}

	// Blend Factor
	// �Ƃ肠����float4�̂�
	LexToken tk = Lex.Lex();
	if( tk != TK_IDENTIFIER || Lex.getStrVal()!=ZGLEXCHAR("float4") ){
		return false;
	}
	if( !check_char(ZGLEXCHAR('(')) ){return false;}
	LexFloat fv4[4];
	for(int i=0;i<3;++i){
		if(!get_float(fv4[i])){return false;}
		if( !check_char(ZGLEXCHAR(',')) ){return false;}
	}
	if(!get_float(fv4[3])){return false;}
	if( !check_chars(ZGLEXCHAR("),")) ){return false;}

	//Sample Mask
	LexInt mask;
	if( !get_int(mask) ){return false;}

	if( !check_chars(ZGLEXCHAR(");")) ){return false;}

	Lex.Lex();
	return true;
}
//-------------
bool Compiler::ParseSetDepthStencilState()
{
	if( !check_char(ZGLEXCHAR('(')) ){return false;}

	// �X�e�[�g�ϐ���
	LexString name;
	if( !get_id(name) ){return false;}
	if( !check_char(ZGLEXCHAR(',')) ){return false;}

	// stencil ref
	LexInt ref;
	if( !get_int(ref) ){return false;}

	if( !check_chars(ZGLEXCHAR(");")) ){return false;}

	Lex.Lex();
	return true;
}
//-------------
bool Compiler::ParseSetRasterizerState()
{
	if( !check_char(ZGLEXCHAR('(')) ){return false;}

	// �X�e�[�g�ϐ���
	LexString name;
	if( !get_id(name) ){return false;}

	if( !check_chars(ZGLEXCHAR(");")) ){return false;}

	Lex.Lex();
	return true;
}
//-------------
bool Compiler::ParseSetVertexShader()
{
	if( !check_char(ZGLEXCHAR('(')) ){return false;}
	LexString profile, func;
	if( !get_CompileShader(profile, func) ){return false;}
	if( !check_chars(ZGLEXCHAR(");")) ){return false;}
	Lex.Lex();
	return true;
}
//-------------
bool Compiler::ParseSetPixelShader()
{
	if( !check_char(ZGLEXCHAR('(')) ){return false;}
	LexString profile, func;
	if( !get_CompileShader(profile, func) ){return false;}
	if( !check_chars(ZGLEXCHAR(");")) ){return false;}
	Lex.Lex();
	return true;
}
//------------
bool Compiler::get_CompileShader(LexString& profile, LexString& func)
{
	LexToken tk = Lex.Lex();
	if( tk != TKFX_COMPILE_SHADER ){return false;}
	if( !check_char(ZGLEXCHAR('(')) ){return false;}
	if( !get_id(profile) ){return false;}
	if( !check_char(ZGLEXCHAR(',')) ){return false;}
	if( !get_id(func) ){return false;}
	if( !check_char(ZGLEXCHAR('(')) ){return false;}
	//��������
	while( !Lex.isEof() ){
		if( check_char(ZGLEXCHAR(')')) )break;
	}
	if( !check_char(ZGLEXCHAR(')')) ){return false;}
	return true;
}
//------------
bool Compiler::tryparse_sema(LexString& str, LexString& reg, bool lex)
{
	LexToken tk = lex? Lex.Lex() : Lex.getToken();
	if( tk != ZGLEXCHAR(':') )return false;
	if( !get_id(str) )return false;
	if( str == ZGLEXCHAR("register") ){
		if(!check_char(ZGLEXCHAR('(')))return false;
		if( !get_id(reg) )return false;
		if(!check_char(ZGLEXCHAR(')')))return false;
	}
	Lex.Lex();
	return true;
}

//------------
bool Compiler::get_float(LexFloat& fval, bool lex)
{
	LexToken tk = lex? Lex.Lex() : Lex.getToken();
	if(tk==TK_INTEGER){
		fval = static_cast<LexFloat>(Lex.getIntVal());
		return true;
	}else if(tk==TK_FLOAT){
		fval = Lex.getFloatVal();
		return true;
	}
	return false;
}

//------------
bool Compiler::get_int(LexInt& ival, bool lex)
{
	LexToken tk = lex? Lex.Lex() : Lex.getToken();
	if(tk==TK_INTEGER){
		ival = Lex.getIntVal();
		return true;
	}else if(tk==TK_FLOAT){
		ival = static_cast<LexInt>(Lex.getFloatVal());
		return true;
	}
	return false;
}

//------------
bool Compiler::get_id(LexString& str, bool lex)
{
	LexToken tk = lex? Lex.Lex() : Lex.getToken();
	if( tk != TK_IDENTIFIER )return false;
	str = Lex.getStrVal();
	return true;
}

//------------
bool Compiler::check_char(LexChar ch, bool lex)
{
	LexToken tk = lex? Lex.Lex() : Lex.getToken();
	return tk == ch;
}
//------------
bool Compiler::check_chars(const LexChar* str, bool lex)
{
	while(*str){
		if(lex)Lex.Lex();
		lex = true;
		if( !check_char(*str,false) )return false;
		++str;
	}
	return true;
}

//------------
bool Compiler::skip_token(LexToken tk)
{
	while(!Lex.isEof()){
		if( Lex.getToken() == tk)break;
		Lex.Lex();
	}
	if( Lex.isEof() )return false;//�Ȃ�
	Lex.Lex();
	return true;
}


//------------
bool Compiler::skip_scope(bool semicolon)
{
	// '{'�܂�
	while(!Lex.isEof()){
		if( Lex.getToken() == ZGLEXCHAR('{'))break;
		Lex.Lex();
	}
	if( Lex.isEof() )return false;//{���Ȃ�
	
	// '}'�܂�
	int cnt = 0;//{�̐� �l�X�g�Ή�
	Lex.Lex();
	while(!Lex.isEof()){
		LexToken tk = Lex.getToken();
		if(tk == ZGLEXCHAR('}')){
			if(cnt == 0){
				break;//�I��
			}else{
				--cnt;
			}
		}
		if( tk == ZGLEXCHAR('{') ){
			++cnt;
		}
		Lex.Lex();
	}

	Lex.Lex();
	if(semicolon){
		if( Lex.getToken() != ZGLEXCHAR(';') ){ return false;}
		Lex.Lex();
	}
	return true;
}

namespace zgfx
{

ZGFXCompiler::ZGFXCompiler()
{
}

ZGFXCompiler::~ZGFXCompiler()
{
}

bool ZGFXCompiler::Compile(const char* data, size_t size)
{
	LexRead read(data, data+size);
	Compiler compile(&read);
	return compile.Compile();
}


}//zgfx


