#include "stdafx.h"

#include "zg_dx11.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <directxmath.h>

#include "zg_preprocess.h"
#include "zgfx_compiler.h"


using namespace DirectX;

#define SAFE_RELEASE(_p) if((_p)){(_p)->Release();(_p)=nullptr;}

bool					g_InitDX11 = false;//2�d�������h�~
D3D_DRIVER_TYPE			g_DriverType = D3D_DRIVER_TYPE_NULL;
D3D_FEATURE_LEVEL		g_FeatureLevel = D3D_FEATURE_LEVEL_11_0;

ID3D11Device* g_pDevice = nullptr;
ID3D11DeviceContext* g_pDevCtx = nullptr;
IDXGISwapChain* g_pSwapChain = nullptr;
ID3D11RenderTargetView*	g_pRTView = nullptr;

namespace {

// �V�F�[�_�̃R���p�C��
HRESULT CompileShaderFromFile( const WCHAR* fname, LPCSTR entry_point, LPCSTR shd_model, ID3DBlob** pp_blob_out )
{
	HRESULT hr = S_OK;

	DWORD shd_flags = D3DCOMPILE_ENABLE_STRICTNESS;
#if defined( DEBUG ) || defined( _DEBUG )
	shd_flags |= D3DCOMPILE_DEBUG;
#endif

	ID3DBlob* err_blob;
	hr = D3DCompileFromFile( fname, nullptr, D3D_COMPILE_STANDARD_FILE_INCLUDE,
					entry_point, shd_model, 
					shd_flags, 0, pp_blob_out, &err_blob );
	if( FAILED(hr) ){
		if( err_blob != NULL ){
			OutputDebugStringA( (char*)err_blob->GetBufferPointer() );
		}
		if( err_blob ) err_blob->Release();
		return hr;
	}
	if( err_blob ){
		err_blob->Release();
	}
	return S_OK;
}

}//ns


//---------------------------------------------------------
HRESULT InitDX11(HWND hWnd)
{

	{
		// �v���v���Z�b�T
		zg::Preprocessor pp;
		pp.RunFile("data\\test.fx");
		const void* result = pp.getResult();
		const void* error = pp.getError();
		if(result)OutputDebugStringA( (const char*)result );
		if(error)OutputDebugStringA( (const char*)error );
		
		// FX�t�@�C�����
		if( result ){
			zgfx::ZGFXCompiler compile;
			compile.Compile(static_cast<const char*>(result), pp.getResultSize());
		}
	}

	if(g_InitDX11)return S_FALSE;//���łɏ�����
	
	HRESULT hr = S_OK;
	
	RECT rc;
	GetClientRect( hWnd, &rc );
	UINT width = rc.right - rc.left;
	UINT height = rc.bottom - rc.top;

	UINT cdev_flags = 0;
#ifdef _DEBUG
	cdev_flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

	// DirectX11&�n�[�h�E�F�A�Ή��̂�
	D3D_FEATURE_LEVEL feature_level = D3D_FEATURE_LEVEL_11_0;
	g_DriverType = D3D_DRIVER_TYPE_HARDWARE;

	// �X���b�v�`�F�C���ݒ�
	DXGI_SWAP_CHAIN_DESC sd;
	ZeroMemory( &sd, sizeof( sd ) );
	sd.BufferCount = 1;
	sd.BufferDesc.Width = width;
	sd.BufferDesc.Height = height;
	sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	sd.BufferDesc.RefreshRate.Numerator = 60;
	sd.BufferDesc.RefreshRate.Denominator = 1;	//1/60 = 60fps
	sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	sd.OutputWindow = hWnd;
	sd.SampleDesc.Count = 1;
	sd.SampleDesc.Quality = 0;
	sd.Windowed = TRUE;

	// DirectX11�f�o�C�X�ƃX���b�v�`�F�C���쐬
	hr = D3D11CreateDeviceAndSwapChain( NULL, g_DriverType, NULL,
										cdev_flags, &feature_level, 1, D3D11_SDK_VERSION, &sd,
										&g_pSwapChain, &g_pDevice, &g_FeatureLevel, &g_pDevCtx );
	if( FAILED( hr ) ){
		return hr;
	}


	ID3D11Texture2D* back_buff = nullptr;
	hr = g_pSwapChain->GetBuffer( 0, __uuidof( ID3D11Texture2D ), ( LPVOID* )&back_buff );
	if( FAILED( hr ) ){
		return hr;
	}

	hr = g_pDevice->CreateRenderTargetView( back_buff, nullptr, &g_pRTView );
	back_buff->Release();//GetBuffer�Ŏ擾�A�g�p���Release
	if( FAILED( hr ) ){
		return hr;
	}

	g_pDevCtx->OMSetRenderTargets( 1, &g_pRTView, nullptr );

	// viewport
	D3D11_VIEWPORT vp;
	vp.Width = (FLOAT)width;
	vp.Height = (FLOAT)height;
	vp.MinDepth = 0.0f;
	vp.MaxDepth = 1.0f;
	vp.TopLeftX = 0;
	vp.TopLeftY = 0;
	g_pDevCtx->RSSetViewports( 1, &vp );

	g_InitDX11 = true;

	{//�V�F�[�_�R���p�C������
		ID3DBlob* vshd = nullptr;
		ID3DBlob* pshd = nullptr;
		ID3DBlob* fxshd = nullptr;
		HRESULT hr = CompileShaderFromFile(L"data\\test.fx", "vsBasic","vs_5_0", &vshd);
		hr = CompileShaderFromFile(L"data\\test.fx", "psBasic","ps_5_0", &pshd);
		hr = CompileShaderFromFile(L"data\\test.fx", NULL,"fx_5_0", &fxshd);
		
		ID3D11ShaderReflection* ps_ref;
		hr = D3DReflect( pshd->GetBufferPointer(),pshd->GetBufferSize(),
					IID_ID3D11ShaderReflection, (void**)&ps_ref);
		// dxguid.lib�̃����N���K�v
 
		// �V�F�[�_���擾
		D3D11_SHADER_DESC shd_desc;
		hr = ps_ref->GetDesc(&shd_desc);

		// ���̓p�����[�^
		for(size_t i=0;i<shd_desc.BoundResources;++i){
			D3D11_SIGNATURE_PARAMETER_DESC in_param;
			ps_ref->GetInputParameterDesc(i, &in_param);
			int a=0;
		}

		// ���\�[�X
		for(size_t i=0;i<shd_desc.InputParameters;++i){
			D3D11_SHADER_INPUT_BIND_DESC res;
			ps_ref->GetResourceBindingDesc(i, &res);
			int a=0;
		}

		if(ps_ref)ps_ref->Release();
		if(vshd)vshd->Release();
		if(pshd)pshd->Release();
	}

	return S_OK;
}

//---------------------------------------------------------
void ExitDX11()
{
	SAFE_RELEASE(g_pDevice);
	SAFE_RELEASE(g_pDevCtx);
	SAFE_RELEASE(g_pSwapChain);
	SAFE_RELEASE(g_pRTView);
}

//---------------------------------------------------------
void RenderDX11()
{
	float ClearColor[4] = { 0.2f, 0.4f, 0.8f, 1.0f }; //red,green,blue,alpha
	if(!g_InitDX11)return;

	g_pDevCtx->ClearRenderTargetView( g_pRTView, ClearColor );

    g_pSwapChain->Present( 0, 0 );
}
