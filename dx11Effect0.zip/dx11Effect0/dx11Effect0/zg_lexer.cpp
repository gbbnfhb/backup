#include "stdafx.h"

#include "zg_lexer.h"

namespace zg {
namespace lex {

namespace {

#define LEXCHAR_MAX 0xFF
#define LEXCHAR( _str ) _str

#define LEXCHAR_EOF 0

LexInt toInt(const LexChar* str)
{
	return atoi(str);
}

LexInt toInt(const LexString& str)
{
	return toInt(str.c_str());
}

LexFloat toFloat(const LexString& str)
{
	return static_cast<LexFloat>(atof(str.c_str()));
}

LexInt HexToInt(const LexString& str)
{
	LexChar* endptr;
	return strtoul(str.c_str(), &endptr, 16);
}

bool isDigit(LexChar c)
{
	return isdigit(c)!=0;
}

bool isXDigit(LexChar c)
{
	return isxdigit(c)!=0;
}

bool isAlpha(LexChar c)
{
	return isalpha(c) || c==LEXCHAR('_');
}

bool isSpace(LexChar c)
{
	return ( c == LEXCHAR(' ') )
		|| ( c == LEXCHAR('\t') )
		|| ( c == LEXCHAR('\r') );
}

bool isReturn(LexChar c)
{
	return c == LEXCHAR('\n');
}

}//ns

//-------
Lexer::Lexer(LexRead* lread)
	: pRead(lread), valCur(0), strCur(), iToken(0), bEof(false)
	, nCurLine(1), nCurColumn(1), strCurFile("")
{
	Next();
}

//-------
LexToken Lexer::Lex()
{
	while( !isEof() )
	{
		// �󔒕���
		SkipSpace();

		switch(getCur()){
		//--- ���s ---
		case LEXCHAR('\n'):
			++nCurLine;
			Token( LEXCHAR('\n') );
			NextCol();
			nCurColumn = 1;
			strLine = "";
			continue;
		// --- �s�R�����g or #line�}�N��
		case LEXCHAR('#'):
			LineComment();
			continue;
		case LEXCHAR('/'):
			NextCol();
			switch(getCur()){
			//case * / �R�����g�Ή��Ȃ�
			case LEXCHAR('='):
				NextCol();
				return RetToken(TK_DIVEQ);
			default:
				return RetToken(LEXCHAR('/'));
			}
		case LEXCHAR('='):
			NextCol();
			if (getCur() != LEXCHAR('=')){ return RetToken('='); }
			else { NextCol(); return RetToken(TK_EQ); }
		case LEXCHAR('<'):
			NextCol();
			switch(getCur()) {
			case LEXCHAR('='):
				NextCol(); return RetToken(TK_LE);
			case LEXCHAR('<'):
				NextCol(); return RetToken(TK_SHIFTL);
			}
			return RetToken(LEXCHAR('<'));
		case LEXCHAR('>'):
			NextCol();
			switch(getCur()) {
			case LEXCHAR('='):
				NextCol(); return RetToken(TK_GE);
			case LEXCHAR('>'):
				NextCol(); return RetToken(TK_SHIFTR);
			}
			return RetToken(LEXCHAR('>'));
		case LEXCHAR('!'):
			NextCol();
			if (getCur() != LEXCHAR('=')){ return RetToken(LEXCHAR('!'));}
			else { NextCol(); return RetToken(TK_NE); }
		case LEXCHAR('{'): case LEXCHAR('}'):
		case LEXCHAR('('): case LEXCHAR(')'):
		case LEXCHAR('['): case LEXCHAR(']'):
		case LEXCHAR(';'): case LEXCHAR(','): case LEXCHAR('?'):
		case LEXCHAR('^'): case LEXCHAR('~'): case LEXCHAR('.'):
		case LEXCHAR(':'):
			{LexToken ret = getCur();
			NextCol();
			return RetToken(ret);}
		case LEXCHAR('\"'):
			if( ReadString() ){
				return RetToken( TK_STRING );
			}
			Error( "Invalid String Liteal" );
			return TK_ERROR;
		case LEXCHAR('&'):
			NextCol();
			if (getCur() != LEXCHAR('&')){ return RetToken(LEXCHAR('&')); }
			else { NextCol(); return RetToken(TK_AND); }
		case LEXCHAR('|'):
			NextCol();
			if (getCur() != LEXCHAR('|')){ return RetToken(LEXCHAR('|')); }
			else { NextCol(); return RetToken(TK_OR); }
		case LEXCHAR('*'):
			NextCol();
			if (getCur() == LEXCHAR('=')){ NextCol(); return RetToken(TK_MULEQ);}
			else return RetToken(LEXCHAR('*'));
		case LEXCHAR('%'):
			NextCol();
			if (getCur() == LEXCHAR('=')){ NextCol(); return RetToken(TK_MODEQ);}
			else return RetToken(LEXCHAR('%'));
		case LEXCHAR('-'):
			NextCol();
			if (getCur() == LEXCHAR('=')){ NextCol(); return RetToken(TK_MINUSEQ);}
			else if  (getCur() == LEXCHAR('-')){ NextCol(); return RetToken(TK_MINUSMINUS);}
			else return RetToken(LEXCHAR('-'));
		case LEXCHAR('+'):
			NextCol();
			if (getCur() == LEXCHAR('=')){ NextCol(); return RetToken(TK_PLUSEQ);}
			else if (getCur() == LEXCHAR('+')){ NextCol(); return RetToken(TK_PLUSPLUS);}
			else return RetToken(LEXCHAR('+'));
		default:
			if( isDigit(getCur()) ){
				LexInt ret = ReadNumber();
				return RetToken(ret);
			}else if( isAlpha(getCur()) ){
				LexInt ret = ReadID();
				return RetToken(ret);
			}else{
				 Error(LEXCHAR("Unexpected Character"));
				NextCol();
				return RetToken(TK_ERROR);
			}
		}

		NextCol();
	}
	return 0;
}

//-------	
void Lexer::SkipSpace()
{
	while( !isEof() && isSpace(getCur()) ){
		NextCol();
	}
}

//-------	
void Lexer::LineComment()
{
	NextCol();
	
	LexString str[2];

	// line ���� 
	for(int idx=0;idx<2;++idx){
		while( !isEof() && !isReturn(getCur()) ){
			if( isSpace(getCur()) )break;
			str[idx] += getCur();
			NextCol();
		}
		SkipSpace();
	}
	
	// #line
	if(str[0] == LEXCHAR("line")){
		if( str[1] != "" ){
			int line_no = toInt(str[1]);
			nCurLine = line_no-1;

			// �t�@�C���p�X
			if( getCur() == LEXCHAR('\"') ){
				if(ReadString()){
					strCurFile = valString;
				}
			}
		}
	}

	// ���s�܂ŃX�L�b�v
	while( !isEof() && !isReturn(getCur()) ){
		NextCol();
	}
	// �����ŉ��s�R�[�h�̏��������Ȃ�
	// Current='\n'�̏�Ԃ�return
}

//-------	
bool Lexer::ReadString()
{
	// �P���ȑΉ��̂�
	// �}���`�o�C�g�A\�@���Ή�
	strCur = "";
	if( getCur() != '\"' )return false;
	NextCol();
	if( isEof() )return false;
	while( getCur() != '\"' ){
		strCur += getCur();
		NextCol();
		if( isEof() ){
			return false;
		}
	}
	NextCol();
	valString = strCur;
	return true;
}

//-------
LexToken Lexer::ReadNumber()
{
	strCur = "";
	LexChar top = getCur();
	NextCol();
	enum{
		TINT = 1,
		TFLOAT = 2,
		THEX = 3,
	};
	int type = TINT;
	
	//16�i��
	if( top == LEXCHAR('0') && toupper(getCur())==LEXCHAR('X') ){
		NextCol();
		while(isXDigit(getCur())) {
			strCur += getCur();
			NextCol();
		}
		type = THEX;
	}else{
		//int float  +e�\�L���Ή�
		strCur += top;
		while (getCur() == LEXCHAR('.') || isDigit(getCur()) ){
			if( getCur() == LEXCHAR('.') ) type = TFLOAT;
			strCur += getCur();
			NextCol();
		}
		if( getCur() == LEXCHAR('f') ){
			type = TFLOAT;
			NextCol();
		}
	}
	switch(type) {
	case TINT:
		valInt = toInt(strCur);
		return TK_INTEGER;
	case TFLOAT:
		valFloat = toFloat(strCur);
		return TK_FLOAT;
	case THEX:
		valInt = HexToInt(strCur);
		return TK_INTEGER;
	}
	return TK_ERR_NUMBER;
}

//-------
LexToken Lexer::ReadID()
{
	strCur = "";
	do {
		strCur += getCur();
		NextCol();
	}while( isAlpha(getCur()) || isDigit(getCur()) );
	valString = strCur;
	
	return getKeyToken(valString);
}

//-------
void Lexer::AddKeyword(const LexString& key, LexToken tk)
{
	mapKeywords.insert( std::pair<LexString,LexToken>(key,tk));
}

//-------
LexToken Lexer::getKeyToken(const LexString& key) const
{
	std::map<LexString,LexToken>::const_iterator it;
	it = mapKeywords.find( key );
	if(it != mapKeywords.end())return it->second;
	return TK_IDENTIFIER;
}

// ��͏I���H
bool Lexer::isEof() const
{ 
	return bEof || (getCur() == LEXCHAR_EOF);
}
	
// ���݂̎���ID
LexToken Lexer::getToken() const
{
	return iToken;
}

// ���݂̐����l
LexInt Lexer::getIntVal() const
{
	return valInt;
}
	
// ���݂̕��������l
LexFloat Lexer::getFloatVal() const
{
	return valFloat;
}
	
// ���݂̕�����
const LexString& Lexer::getStrVal() const
{
	return valString;
}

//-------------
void Lexer::Next()
{
	LexInt t = pRead->Read();
	if(t > LEXCHAR_MAX){ Error( LEXCHAR("Invalid character") ); }
	if( t == 0){
		valCur = LEXCHAR_EOF;
		bEof = true;
	}else{
		valCur = static_cast<LexChar>(t); 
	}
}

//-------------
void Lexer::NextCol()
{
	Next();
	++nCurColumn;
}

//-------------
void Lexer::Token(LexToken t)
{
	iToken = t;
}

//-------------
LexToken Lexer::RetToken(LexToken t)
{
	Token(t);
	return t;
}

//-------------
void Lexer::Error(const LexChar* error)
{

}

//-------------
LexInt Lexer::getCur() const { return valCur;}
//-------------
const LexString& Lexer::getCurString() const { return strCur; }

}//lex
}//zg

