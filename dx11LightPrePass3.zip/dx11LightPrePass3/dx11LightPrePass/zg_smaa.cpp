#include "stdafx.h"

#include "zg_smaa.h"

#include "zg_dx11_utils.h"

// SMMA�p�e�N�X�`��
#include "smaa/AreaTex.h"
#include "smaa/SearchTex.h"

// DXTrace���Ȃ��̂�
#include <boost/format.hpp>
namespace{
inline HRESULT DXTrace(const char* file_name, DWORD line , HRESULT hr, const WCHAR* msg, bool pop_msg)
{
	std::wstring text = (boost::wformat(L"%1%(%2%): %3%") % strrchr(file_name,'\\') % line % msg ).str();
	OutputDebugStringW( text.c_str() );
	return hr;
}

#if defined(DEBUG) || defined(_DEBUG)
#ifndef V
#define V(x) { hr = (x); if (FAILED(hr)) { DXTrace(__FILE__ , (DWORD)__LINE__, hr, L#x, true); } }
#endif
#ifndef V_RETURN
#define V_RETURN(x) { hr = (x); if (FAILED(hr)) { return DXTrace(__FILE__, (DWORD)__LINE__, hr, L#x, true); } }
#endif
#else
#ifndef V
#define V(x) { hr = (x); }
#endif
#ifndef V_RETURN
#define V_RETURN(x) { hr = (x); if( FAILED(hr) ) { return hr; } }
#endif
#endif


}

namespace zix11 {//directX11����
namespace{

//�萔�o�b�t�@
struct CBuffSMAA
{
	int subsampleIndices[4];
	float blendFactor;
	float threshld;
	float maxSearchSteps;
	float maxSearchStepsDiag;
	float cornerRounding;
};

// ��ԕۑ�
struct SaveState
{
	SaveState(const IDevCtxPtr& devctx)
		: pDevCtx(devctx)
	{
		if(pDevCtx){
			// Viewport
			pDevCtx->RSGetViewports(&numViewport,nullptr);
			if(numViewport > 0){
				aViewport.resize(numViewport);
				pDevCtx->RSGetViewports(&numViewport, aViewport.data());
			}

			// RenderTarget
			pDevCtx->OMGetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, aRTV, &pDSV);
		}
	}

	~SaveState()
	{
		if(pDevCtx){
	        pDevCtx->RSSetViewports(numViewport, aViewport.data());
			pDevCtx->OMSetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, aRTV, pDSV);
		}
		for(auto& r : aRTV){
			if(r)r->Release();
		}
		if(pDSV)pDSV->Release();
	}

	UINT numViewport;
	std::vector<D3D11_VIEWPORT> aViewport;
	ID3D11RenderTargetView* aRTV[D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT];
	ID3D11DepthStencilView* pDSV;
	
	IDevCtxPtr pDevCtx;
};

}//ns

SMAA::SMAA(const IDevicePtr& dev, int width, int height)
	: pDev(dev), uWidth(width), uHeight(height)
{
	HRESULT hr;

	// ��Ɨp�o�b�t�@�쐬�i�G�b�W���o�ƃu�����h�E�G�C�g�j
	{
		DXGI_SAMPLE_DESC smpl_desc;
		smpl_desc.Count = 1;
		smpl_desc.Quality = 0;

		D3D11_TEXTURE2D_DESC tex_desc;
		ZeroMemory( &tex_desc, sizeof(tex_desc) );
		tex_desc.Width = width;
		tex_desc.Height = height;
		tex_desc.MipLevels = 1;
		tex_desc.ArraySize = 1;
		tex_desc.SampleDesc = smpl_desc;
		tex_desc.Usage = D3D11_USAGE_DEFAULT;
		tex_desc.CPUAccessFlags = 0;
		tex_desc.MiscFlags = 0;
		tex_desc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
		tex_desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;

		ITex2DPtr edge_tex;
		V( pDev->CreateTexture2D( &tex_desc, NULL, GSET_DXPTR(edge_tex) ) );
		V( pDev->CreateRenderTargetView( edge_tex.get(), nullptr, GSET_DXPTR(pEdgeRTV)) );
		V( pDev->CreateShaderResourceView( edge_tex.get(), nullptr, GSET_DXPTR(pEdgeSRV)) );
		
		ITex2DPtr blend_tex;
		V( pDev->CreateTexture2D( &tex_desc, NULL, GSET_DXPTR(blend_tex) ) );
		V( pDev->CreateRenderTargetView( blend_tex.get(), nullptr, GSET_DXPTR(pBlendRTV)) );
		V( pDev->CreateShaderResourceView( blend_tex.get(), nullptr, GSET_DXPTR(pBlendSRV)) );
	}

	// ���O�v�Z�̃e�N�X�`���ǂݍ��݁i�w�b�_�t�@�C���Œ�`�j
	{//AreaTex.h
		D3D11_SUBRESOURCE_DATA data;
		data.pSysMem = areaTexBytes;
		data.SysMemPitch = AREATEX_PITCH;
		data.SysMemSlicePitch = 0;

		D3D11_TEXTURE2D_DESC descTex;
		descTex.Width = AREATEX_WIDTH;
		descTex.Height = AREATEX_HEIGHT;
		descTex.MipLevels = descTex.ArraySize = 1;
		descTex.Format = DXGI_FORMAT_R8G8_UNORM;
		descTex.SampleDesc.Count = 1;
		descTex.SampleDesc.Quality = 0;
		descTex.Usage = D3D11_USAGE_DEFAULT;
		descTex.BindFlags = D3D11_BIND_SHADER_RESOURCE;
		descTex.CPUAccessFlags = 0;
		descTex.MiscFlags = 0;
		V( pDev->CreateTexture2D(&descTex, &data, GSET_DXPTR(pAreaTex)) );

		D3D11_SHADER_RESOURCE_VIEW_DESC descSRV;
		descSRV.Format = descTex.Format;
		descSRV.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
		descSRV.Texture2D.MostDetailedMip = 0;
		descSRV.Texture2D.MipLevels = 1;
		V( pDev->CreateShaderResourceView(pAreaTex.get(), &descSRV, GSET_DXPTR(pAreaSRV)) );
	}
	{//SearchTex.h
		D3D11_SUBRESOURCE_DATA data;
		data.pSysMem = searchTexBytes;
		data.SysMemPitch = SEARCHTEX_PITCH;
		data.SysMemSlicePitch = 0;

		D3D11_TEXTURE2D_DESC descTex;
		descTex.Width = SEARCHTEX_WIDTH;
		descTex.Height = SEARCHTEX_HEIGHT;
		descTex.MipLevels = descTex.ArraySize = 1;
		descTex.Format = DXGI_FORMAT_R8_UNORM;
		descTex.SampleDesc.Count = 1;
		descTex.SampleDesc.Quality = 0;
		descTex.Usage = D3D11_USAGE_DEFAULT;
		descTex.BindFlags = D3D11_BIND_SHADER_RESOURCE;
		descTex.CPUAccessFlags = 0;
		descTex.MiscFlags = 0;
		V( pDev->CreateTexture2D(&descTex, &data, GSET_DXPTR(pSearchTex)) );

		D3D11_SHADER_RESOURCE_VIEW_DESC descSRV;
		descSRV.Format = descTex.Format;
		descSRV.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
		descSRV.Texture2D.MostDetailedMip = 0;
		descSRV.Texture2D.MipLevels = 1;
		V( pDev->CreateShaderResourceView(pSearchTex.get(), &descSRV, GSET_DXPTR(pSearchSRV)) );
	}

	// �V�F�[�_
	pShader = CreateShaderEffectFromFile(L"smaa/smaa.fx");
	
	// �X�v���C�g�`��i�S��ʕ`��j
	CreateSpriteGeom cquad;
	//std::swap(cquad.vPosLT.y, cquad.vPosRB.y);
	GeometryX11 quad;
	cquad.Create(quad);

	CinfoShaderPass ci_spass;
	ci_spass.pGeom = &quad;
	ci_spass.pEffect = pShader.get();
	ci_spass.idxTech = 0;//�G�b�W���o
	ci_spass.idxPass = 0;

	CreateShaderPass(ci_spass, renEdge);

	ci_spass.idxTech = 1;//�u�����h���v�Z
	CreateShaderPass(ci_spass, renBlendWeight);

	ci_spass.idxTech = 2;//AA����
	CreateShaderPass(ci_spass, renBlending);
	
	//�T���v��
	D3D11_SAMPLER_DESC sampDesc;
	ZeroMemory( &sampDesc, sizeof(sampDesc) );
	sampDesc.Filter = D3D11_FILTER_MIN_MAG_LINEAR_MIP_POINT;
	sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	sampDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
	sampDesc.MinLOD = 0;
	sampDesc.MaxLOD = D3D11_FLOAT32_MAX;
	V( pDev->CreateSamplerState( &sampDesc, GSET_DXPTR(pLinearSampler)) );
	
	sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
	V( pDev->CreateSamplerState( &sampDesc, GSET_DXPTR(pPointSampler)) );

}

void SMAA::Go(const IDevCtxPtr& dtvctx, const ISRViewPtr& color_srv, const IRTViewPtr& out_rtv)
{
	if( !dtvctx )return;
	SaveState save_state(dtvctx);

    dtvctx->OMSetRenderTargets(0, NULL, NULL);
	
	D3D11_VIEWPORT vp;
	vp.Width = (FLOAT)uWidth;
	vp.Height = (FLOAT)uHeight;
	vp.MinDepth = 0.0f;
	vp.MaxDepth = 1.0f;
	vp.TopLeftX = 0;
	vp.TopLeftY = 0;
	dtvctx->RSSetViewports( 1, &vp );

    float clear[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
    dtvctx->ClearRenderTargetView(pEdgeRTV.get(), clear);
    dtvctx->ClearRenderTargetView(pBlendRTV.get(), clear);
	
	{// �G�b�W���o
		ID3D11RenderTargetView* rtv = pEdgeRTV.get();
	    dtvctx->OMSetRenderTargets(1, &rtv, nullptr);

		// ���@�V�F�[�_�R�[�h����X���b�g�ԍ����擾����K�v����
		renEdge.apSpState[0] = pLinearSampler;
		renEdge.apSpState[1] = pPointSampler;
		renEdge.apSRView[0] = color_srv;
		RenderShaderPass(dtvctx, renEdge);
	}

	{// �u�����h���v�Z
		ID3D11RenderTargetView* rtv = pBlendRTV.get();
		dtvctx->OMSetRenderTargets(1, &rtv, nullptr);
		renBlendWeight.apSpState[0] = pLinearSampler;
		renBlendWeight.apSpState[1] = pPointSampler;
		renBlendWeight.apSRView[1] = pEdgeSRV;
		renBlendWeight.apSRView[3] = pAreaSRV;
		renBlendWeight.apSRView[4] = pSearchSRV;
		RenderShaderPass(dtvctx, renBlendWeight);
	}
	{// AA
		ID3D11RenderTargetView* rtv = out_rtv.get();
		dtvctx->OMSetRenderTargets(1, &rtv, nullptr);
		renBlending.apSpState[0] = pLinearSampler;
		renBlending.apSpState[1] = pPointSampler;
		renBlending.apSRView[0] = color_srv;
		renBlending.apSRView[2] = pBlendSRV;
		RenderShaderPass(dtvctx, renBlending);
	}
}


}//zix11