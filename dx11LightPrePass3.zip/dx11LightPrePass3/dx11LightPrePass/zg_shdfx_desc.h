#include "zg_types.h"
#include <d3d11.h>

#include "zg_stl.h"

namespace zix11{

// technique��pass�̒�`
class ShaderFXDesc
{
public:
	struct SHADER{
		zgstl::String strTarget;
		zgstl::String strEntry;
	};
	struct PASS{
		PASS();
		PASS(const zgstl::String& name);
		zgstl::String strName;
		SHADER shdVertex;
		SHADER shdPixel;
		SHADER shdGeometry;
		D3D11_RASTERIZER_DESC descRS;
		D3D11_BLEND_DESC descBD;
		D3D11_DEPTH_STENCIL_DESC descDS;
		UINT uStencilRef;

	};
	struct TECHNIQUE{
		TECHNIQUE(){}
		TECHNIQUE(const zgstl::String& name) : strName(name){}
		zgstl::String strName;
		zgstl::Vector<PASS>::T aPass;
	};

	zgstl::Vector<TECHNIQUE>::T aTech;
private:
};

// #ifdef ZGSFX #endif�ň͂܂ꂽ��������͂���ShaderFXDesc�쐬
bool CreateShaderFxDesc(const char* data, size_t size, ShaderFXDesc& desc);

}//zix11
