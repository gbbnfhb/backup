#include "stdafx.h"
#include "zg_mmd.h"

#include "zg_utils.h"
#include "zg_model.h"

#include <directxmath.h>
#include <fstream>
#include <codecvt>

#include <boost/format.hpp>


using namespace DirectX;

namespace{

bool get_byte(const void* &ptr, const void* end, void* buff, size_t n)
{
	const zgU8* last = (zgU8*)ptr + n;
	if(last > end)return false;//�͈̓I�[�o�[

	memcpy(buff, ptr, n);
	ptr = last;
	return true;
}

template <typename TYPE>
bool get_val(const void* &ptr, const void* end, TYPE& v)
{
	return get_byte(ptr,end, &v, sizeof(TYPE));
}

XMVECTOR ToXMVec(const ZGVECTOR3& v)
{
	return XMVectorSet(v.x,v.y,v.z, 0);
}
XMVECTOR ToXMVec(const ZGVECTOR4& v)
{
	return XMVectorSet(v.x,v.y,v.z,v.w);
}
XMVECTOR ToXMVecW1(const ZGVECTOR3& v)
{
	return XMVectorSet(v.x,v.y,v.z, 1);
}
void ToXMMat(XMMATRIX& xmm, const ZGMATRIX44& m44)
{
	xmm.r[0] = ToXMVec(m44.m[0]);
	xmm.r[1] = ToXMVec(m44.m[1]);
	xmm.r[2] = ToXMVec(m44.m[2]);
	xmm.r[3] = ToXMVec(m44.m[3]);
}

ZGVECTOR3 ToVec3(XMVECTOR v)
{
	return ZGVECTOR3(XMVectorGetX(v),XMVectorGetY(v),XMVectorGetZ(v));
}
ZGVECTOR4 ToVec4(XMVECTOR v)
{
	return ZGVECTOR4(XMVectorGetX(v),XMVectorGetY(v),XMVectorGetZ(v),XMVectorGetW(v));
}
ZGQUAT ToQuat(XMVECTOR v)
{
	return ZGQUAT(XMVectorGetX(v),XMVectorGetY(v),XMVectorGetZ(v),XMVectorGetW(v));
}

void ToMatrix44(ZGMATRIX44& m44, const XMMATRIX& xmm)
{
	m44.m[0] = ToVec4(xmm.r[0]);
	m44.m[1] = ToVec4(xmm.r[1]);
	m44.m[2] = ToVec4(xmm.r[2]);
	m44.m[3] = ToVec4(xmm.r[3]);
}

}//ns

//--------------------------------------------------------
bool CreatePMD(const WCHAR* file, PMDModel& pmd)
{
	std::ifstream input;
	input.open(file, std::ios::binary);
	if( !input.is_open() )return false;
	size_t fsize = (size_t)input.seekg(0, std::ios::end).tellg();
	input.seekg(0, std::ios::beg);
	BinObject blob(fsize);
	if( !blob.get() )return false;
	char* b = static_cast<char*>(blob.get());
	input.read(b, blob.size());

	const void* ptr = b;
	const void* end = b + blob.size();

	get_val(ptr,end, pmd.Header.magic);
	get_val(ptr,end, pmd.Header.version);
	get_val(ptr,end, pmd.Header.model_name);
	get_val(ptr,end, pmd.Header.comment);

	zgU32 vertex_num = 0;
	get_val(ptr,end, vertex_num);
	pmd.aVertex.resize(vertex_num);

	for(zgU32 vi=0;vi<vertex_num;++vi){
		PMDVertex& vertex = pmd.aVertex[vi];
		get_val(ptr,end, vertex.pos);
		get_val(ptr,end, vertex.normal);
		get_val(ptr,end, vertex.uv);
		get_val(ptr,end, vertex.bone_idx);
		get_val(ptr,end, vertex.bone_weight);
		get_val(ptr,end, vertex.edge_flag);
		//padding������̂�get_val(ptr,end, vertex);�͂���
	}

	zgU32 face_vidx_num = 0;
	get_val(ptr,end, face_vidx_num);
	pmd.aFaceVidx.resize(face_vidx_num);

	for(zgU32 fi=0;fi<face_vidx_num;++fi){
		zgU16& face_vidx = pmd.aFaceVidx[fi];
		get_val(ptr,end, face_vidx);
	}

	zgU32 material_num = 0;
	get_val(ptr,end, material_num);
	pmd.aMaterial.resize(material_num);

	for(zgU32 mi=0;mi<material_num;++mi){
		PMDMaterial& material = pmd.aMaterial[mi];
		get_val(ptr,end, material.diffuse);
		get_val(ptr,end, material.specularity);
		get_val(ptr,end, material.specular);
		get_val(ptr,end, material.ambient);
		get_val(ptr,end, material.toon_index);
		get_val(ptr,end, material.edge_flag);
		get_val(ptr,end, material.face_vert_count);
		get_val(ptr,end, material.texfile_name);
	}

	zgU16 bone_num = 0;
	get_val(ptr,end, bone_num);
	pmd.aBone.resize(bone_num);

	for(zgU32 bi=0;bi<bone_num;++bi){
		PMDBone& bone = pmd.aBone[bi];
		get_val(ptr,end, bone.bone_name);
		get_val(ptr,end, bone.parent_bidx);
		get_val(ptr,end, bone.tail_pos_bidx);
		get_val(ptr,end, bone.bone_type);
		get_val(ptr,end, bone.ik_parent_bidx);
		get_val(ptr,end, bone.bone_head_pos);
	}

	zgU16 ik_num = 0;
	get_val(ptr, end, ik_num);
	pmd.aIK.resize(ik_num);
	for(auto& ik : pmd.aIK){
		get_val(ptr,end, ik.bone_index);
		get_val(ptr,end, ik.target_bone_index);
		get_val(ptr,end, ik.chain_length);
		get_val(ptr,end, ik.iterations);
		get_val(ptr,end, ik.control_weight);
		ik.child_bone_index.resize(ik.chain_length);
		for(auto& cb : ik.child_bone_index){
			get_val(ptr, end, cb);
		}
	}

	zgU16 skin_num = 0;
	get_val(ptr, end, skin_num);
	for(zgU32 i=0;i<skin_num;++i){
		char skin_name[20];
		zgU32 skin_vert_count; // �\��p�̒��_��
		zgU8 skin_type; // �\��̎�� // 0�Fbase�A1�F�܂�A2�F�ځA3�F���b�v�A4�F���̑�
		get_val(ptr, end, skin_name);
		get_val(ptr, end, skin_vert_count);
		get_val(ptr, end, skin_type);
		for(zgU32 j=0;j<skin_vert_count;++j){
			zgU32 skin_vert_index; // �\��p�̒��_�̔ԍ�(���_���X�g�ɂ���ԍ�)
			zgF32 skin_vert_pos[3]; // x, y, z // �\��p�̒��_�̍��W(���_���̂̍��W)
			get_val(ptr, end, skin_vert_index);
			get_val(ptr, end, skin_vert_pos);
		}	
	}

	zgU8 skin_disp_count; // �\��g�ɕ\������\�
	get_val(ptr, end, skin_disp_count);
	for(zgU32 i=0;i<skin_disp_count;++i){
		zgU16 skin_index;// �\��ԍ�
		get_val(ptr, end, skin_index);
	}

	//�{�[���g�p�g�����X�g
	zgU8 bone_disp_name_count; // �{�[���g�p�̘g����
	get_val(ptr, end, bone_disp_name_count);
	for(zgU32 i=0;i<bone_disp_name_count;++i){
		char disp_name[50];//[bone_disp_name_count]; // �g��(50Bytes/�g)
		get_val(ptr, end, disp_name);
	}

	//�{�[���g�p�\�����X�g
	zgU16 bone_disp_count; // �{�[���g�ɕ\������{�[���� (�g0(�Z���^�[)�������A���ׂẴ{�[���g�̍��v)
	get_val(ptr, end, bone_disp_count);
	for(zgU32 i=0;i<bone_disp_count;++i){
		//t_bone_disp bone_disp[bone_disp_count]; // �g�p�{�[���f�[�^ (3Bytes/bone)
		zgU16 bone_index; // �g�p�{�[���ԍ�
		zgU8 bone_disp_frame_index; // �\���g�ԍ�
		get_val(ptr, end, bone_index);
		get_val(ptr, end, bone_disp_frame_index);
	}
	// �s���ȃf�[�^
	zgU16 unknown16;
	get_val(ptr, end, unknown16);

	pmd.aToon.resize(10);
	pmd.aToon[0] = "toon01.bmp";
	pmd.aToon[1] = "toon02.bmp";
	pmd.aToon[2] = "toon03.bmp";
	pmd.aToon[3] = "toon04.bmp";
	pmd.aToon[4] = "toon05.bmp";
	pmd.aToon[5] = "toon06.bmp";
	pmd.aToon[6] = "toon07.bmp";
	pmd.aToon[7] = "toon08.bmp";
	pmd.aToon[8] = "toon09.bmp";
	pmd.aToon[9] = "toon10.bmp";

	if(ptr==end)return true;
	//�g���@�g�D�[���e�N�X�`���܂ŉ���
	
	//�P�P�D�w�b�_(�p��)
	zgU8 english_name_compatibility; // �p���Ή�(01:�p���Ή�����)
	get_val(ptr, end, english_name_compatibility);
	if(english_name_compatibility){
		char model_name_eg[20]; // ���f����(�p��)
		char comment_eg[256]; // �R�����g(�p��)
		get_val(ptr, end, model_name_eg);
		get_val(ptr, end, comment_eg);

		//������Ɖ����� 
		//�P�Q�D�{�[�����X�g(�p��)
		zgU16 bone_count = bone_num;
		for(zgU32 i=0;i<bone_count;++i){
			char bone_name_eg[20];//[bone_count]; // �{�[����(�p��)
			get_val(ptr, end, bone_name_eg);
		}
		//�P�R�D�\��X�g(�p��)
		//0x0007 1C04�` // skin_count == 16 // base�͉p�����o�^����Ȃ��̂�15�� (total 300Bytes)
		for(zgS32 i=0;i<zgS32(skin_num)-1;++i){
			char skin_name_eg[20];//[skin_count - 1]; // �\�(�p��)	}
			get_val(ptr, end, skin_name_eg);
		}
		//�P�S�D�{�[���g�p�g�����X�g(�p��)
		for(zgU32 i=0;i<bone_disp_name_count;++i){
			char disp_name_eg[50];//[bone_disp_name_count]; // �g��(�p��) // MMD�ł́u�敪���v
			get_val(ptr, end, disp_name_eg);
		}
	}

	//�P�T�D�g�D�[���e�N�X�`�����X�g
	// ����10�Œ� (total 1000Bytes)
	for(zgU32 i=0;i<10;++i){
		char toon_file_name[100];// �g�D�[���e�N�X�`���t�@�C����
		get_val(ptr, end, toon_file_name);
		pmd.aToon[i] = toon_file_name;
	}
	return true;
}

//---------------------------------------------
bool CreateVMD(const WCHAR* file, VMDMotion& vmd)
{
	std::ifstream input;
	input.open(file, std::ios::binary);
	if( !input.is_open() )return false;
	size_t fsize = (size_t)input.seekg(0, std::ios::end).tellg();
	input.seekg(0, std::ios::beg);
	BinObject blob(fsize);
	if( !blob.get() )return false;
	char* b = static_cast<char*>(blob.get());
	input.read(b, blob.size());

	const void* ptr = b;
	const void* end = b + blob.size();

	get_val(ptr,end, vmd.Header.Header);
	get_val(ptr,end, vmd.Header.ModelName);

	zgU32 key_num = 0;
	get_val(ptr,end, key_num);
	vmd.aKeyFrame.resize(key_num);
	for(zgU32 ik=0;ik<key_num;++ik){
		VMDKeyFlame& key = vmd.aKeyFrame[ik];
		get_val(ptr,end, key.BoneName);
		get_val(ptr,end, key.FlameNo);
		get_val(ptr,end, key.Location);
		get_val(ptr,end, key.Rotatation);
		get_val(ptr,end, key.Interpolation);
	}

	return true;
}

namespace{
//-----
bool utf16_to_utf8(const wchar_t* utf16, zgU32 len, zgstl::String& str)
{
	size_t size;
	if( 0!= wcstombs_s(&size, NULL, 0, utf16, len*sizeof(wchar_t)) ){
		return false;
	}
	std::vector<char> ch(size);
	if( 0!= wcstombs_s(&size, ch.data(), ch.size(), utf16, len*sizeof(wchar_t)) ){
		return false;
	}
	str = ch.data();
	return true;
}

//-----
bool get_pmx_text(const PMXHeader& head, const void* &ptr, const void* end, zgstl::String& text)
{
	zgU32 size = 0;
	if( !get_val(ptr, end, size) )return false;

	zgstl::String str;
	if(head.aConfig[PMXHeader::ENCODE] == PMXHeader::ENCODE_UTF16){
		std::vector<wchar_t> buff;
		buff.resize(size/sizeof(wchar_t)+1);
		if( (buff.size()-1)*sizeof(wchar_t) != size)return false;
		if( !get_byte(ptr, end, buff.data(), size) )return false;
		buff[size/sizeof(wchar_t)] = 0;

		if( !utf16_to_utf8( buff.data(), buff.size(), str) )return false;

	}else{
		// UTF8�@���m�F
		std::vector<char> buff;
		buff.resize(size+1);
		if( (buff.size()-1) != size)return false;
		if( !get_byte(ptr, end, buff.data(), size) )return false;
		buff[size] = 0;

		str = buff.data();
	}
	text = std::move(str);
	return true;
}
//-----
bool get_pmx_idx(zgU8 byte_size, const void* &ptr, const void* end, zgU32& idx)
{
	zgU8 i8;
	zgU16 i16;
	zgU32 i32;
	switch(byte_size){
	case 1:get_val(ptr,end, i8); idx=i8; break;
	case 2:get_val(ptr,end, i16); idx=i16; break;
	case 4:get_val(ptr,end, i32); idx=i32; break;
	default:
		return false;
	}
	return true;
}

//-----
bool get_pmx_vertex(const PMXHeader& header, const void* &ptr, const void* end, PMXVertex& v)
{
	get_val(ptr, end, v.vPos);
	get_val(ptr, end, v.vNor);
	get_val(ptr, end, v.vUV);

	zgU32 add_uv = header.aConfig[PMXHeader::ADDUV];
	if(add_uv >= PMXVertex::ADDUV_MAX)return false;
	for(zgU32 a=0;a<add_uv;++a){
		get_val(ptr, end, v.avAdd[a]);
	}
	zgU8 btype;
	get_val(ptr, end, btype);

	ZGUVECTOR4 bidx(0,0,0,0);
	ZGVECTOR4 bwgt(1.0f,0,0,0);
	zgU32 bidx_num = 0;
	zgU32 bwgt_num = 0;
	switch(btype){
	case PMXVertex::BDEF1:
		bidx_num = 1;
		bwgt_num = 0;
		break;
	case PMXVertex::BDEF2:
		bidx_num = 2;
		bwgt_num = 1;
		break;
	case PMXVertex::BDEF4:
		bidx_num = 4;
		bwgt_num = 4;
		break;
	case PMXVertex::SDEF:
		bidx_num = 2;
		bwgt_num = 1;
		break;
	default:
		return false;
	}
	for(zgU32 ib=0;ib<bidx_num;++ib){
		if( !get_pmx_idx(header.aConfig[PMXHeader::BIDX],ptr,end, bidx.v[ib]) ){
			return false;
		}
	}
	for(zgU32 iw=0;iw<bwgt_num;++iw){
		get_val(ptr,end, bwgt.v[iw]);
	}

	if( bwgt_num == 0){
		 bwgt.v[0] = 1.0f;
	}
	if( bwgt_num == 1){
		 bwgt.v[1] = 1.0f - bwgt.v[0];
	}
	v.vBidx = bidx;
	v.vBwgt = bwgt;

	get_val(ptr,end, v.fEdge);

	return true;
}
//-----
bool get_pmx_material(const PMXHeader& header, const void* &ptr, const void* end, PMXMaterial& m)
{
	PMXMaterial tmp;
	if( !get_pmx_text(header, ptr,end, tmp.strName) )return false;
	if( !get_pmx_text(header, ptr,end, tmp.strNameEn) )return false;
	get_val(ptr,end, tmp.colDiff);
	get_val(ptr,end, tmp.colSpec);
	get_val(ptr,end, tmp.colAmb);
	get_val(ptr,end, tmp.bitFlag);
	get_val(ptr,end, tmp.colEdge);
	get_val(ptr,end, tmp.fEdge);
	if( !get_pmx_idx(header.aConfig[PMXHeader::TIDX], ptr,end, tmp.idxTex0) )return false;
	if( !get_pmx_idx(header.aConfig[PMXHeader::TIDX], ptr,end, tmp.idxTex1) )return false;
	get_val(ptr,end, tmp.bitTex);
	get_val(ptr,end, tmp.bToon);
	if( tmp.bToon ){
		//���L
		get_val(ptr,end, tmp.idxToon);
		tmp.idxToonTex = 0;
	}else{
		tmp.idxToon = 0;
		if( !get_pmx_idx(header.aConfig[PMXHeader::TIDX], ptr,end, tmp.idxToonTex) )return false;
	}
	if( !get_pmx_text(header, ptr,end, tmp.strComment) )return false;
	get_val(ptr,end, tmp.numVertex);

	m = std::move(tmp);
	return true;
}
//-----
bool get_pmx_bone(const PMXHeader& header, const void* &ptr, const void* end, PMXBone& b)
{
	PMXBone tmp;
	if( !get_pmx_text(header, ptr,end, tmp.strName) )return false;
	if( !get_pmx_text(header, ptr,end, tmp.strNameEn) )return false;
	get_val(ptr,end, tmp.vPos);
	
	if( !get_pmx_idx(header.aConfig[PMXHeader::BIDX], ptr,end, tmp.idxParent) )return false;
	get_val(ptr,end, tmp.Hierarchy);
	get_val(ptr,end, tmp.bitFlag);

	if(tmp.bitFlag & PMXBone::BIT_JOINT){
		if( !get_pmx_idx(header.aConfig[PMXHeader::BIDX], ptr,end, tmp.idxJoint) )return false;
	}else{
		get_val(ptr,end, tmp.vJoint);
	}

	if(tmp.bitFlag & (PMXBone::BIT_GIVE_ROT|PMXBone::BIT_GIVE_MOVE)){
		if( !get_pmx_idx(header.aConfig[PMXHeader::BIDX], ptr,end, tmp.idxGive) )return false;
		get_val(ptr,end, tmp.fGive);
	}

	if(tmp.bitFlag & PMXBone::BIT_FIX_AXIS){
		get_val(ptr,end, tmp.vFixAxis);
	}

	if(tmp.bitFlag & PMXBone::BIT_LOCAL_AXIS){
		get_val(ptr,end, tmp.vAxisX);
		get_val(ptr,end, tmp.vAxisZ);
	}

	if(tmp.bitFlag & PMXBone::BIT_EXT_PARENT){
		get_val(ptr,end, tmp.iExtParent);
	}
	
	if(tmp.bitFlag & PMXBone::BIT_IK){
		if( !get_pmx_idx(header.aConfig[PMXHeader::BIDX], ptr,end, tmp.Ik.idxBone) )return false;
		get_val(ptr,end, tmp.Ik.nLoop);
		get_val(ptr,end, tmp.Ik.fLimitAng);
		zgU32 iknum;
		if( !get_val(ptr, end, iknum) )return false;
		tmp.Ik.aLink.resize(iknum);
		if(tmp.Ik.aLink.size() != iknum) return false;
		for(auto& l : tmp.Ik.aLink){
			if( !get_pmx_idx(header.aConfig[PMXHeader::BIDX], ptr,end, l.idxBone) )return false;
			get_val(ptr,end, l.bLimit);
			if(	l.bLimit ){
				get_val(ptr,end, l.vMin);
				get_val(ptr,end, l.vMax);
			}
		}
	}

	b = std::move(tmp);
	return true;
}

}//ns

//---------------------------------------------
bool CreatePMX(const WCHAR* file, PMXModel& pmx)
{
	std::ifstream input;
	input.open(file, std::ios::binary);
	if( !input.is_open() )return false;
	size_t fsize = (size_t)input.seekg(0, std::ios::end).tellg();
	input.seekg(0, std::ios::beg);
	BinObject blob(fsize);
	if( !blob.get() )return false;
	char* b = static_cast<char*>(blob.get());
	input.read(b, blob.size());

	const void* ptr = b;
	const void* end = b + blob.size();

	PMXModel tmp;

	// �w�b�_
	PMXHeader& header = tmp.Header;
	get_val(ptr,end, header.pmx);
	if( memcmp(header.pmx, "PMX ", 4) != 0)return false;
	get_val(ptr,end, header.version);
	get_val(ptr,end, header.numConfig);
	if( header.numConfig != 8 )return false;//8�Œ�
	get_val(ptr,end, header.aConfig);

	if( !get_pmx_text(header, ptr, end, header.strName) )return false;
	if( !get_pmx_text(header, ptr, end, header.strNameEn) )return false;
	if( !get_pmx_text(header, ptr, end, header.strComment) )return false;
	if( !get_pmx_text(header, ptr, end, header.strCommentEn) )return false;

	// ���_�f�[�^
	zgU32 vnum;
	if( !get_val(ptr, end, vnum) )return false;
	tmp.aVertex.resize(vnum);
	if(tmp.aVertex.size() != vnum) return false;
	for(auto& v : tmp.aVertex){
		if( !get_pmx_vertex(header, ptr,end, v) )return false;
	}

	// ��
	zgU32 fnum;
	if( !get_val(ptr, end, fnum) )return false;
	tmp.aFaceVidx.resize(fnum);
	if(tmp.aFaceVidx.size() != fnum) return false;
	for(auto& v : tmp.aFaceVidx){
		if( !get_pmx_idx(header.aConfig[PMXHeader::VIDX], ptr,end, v) ){
			return false;
		}
	}

	// �e�N�X�`��
	zgU32 tnum;
	if( !get_val(ptr, end, tnum) )return false;
	tmp.aTexPath.resize(tnum);
	if(tmp.aTexPath.size() != tnum) return false;
	for(auto& t : tmp.aTexPath){
		if( !get_pmx_text(header, ptr,end, t) ){
			return false;
		}
	}

	// �}�e���A��
	zgU32 mnum;
	if( !get_val(ptr, end, mnum) )return false;
	tmp.aMaterial.resize(mnum);
	if(tmp.aMaterial.size() != mnum) return false;
	for(auto& m : tmp.aMaterial){
		if( !get_pmx_material(header, ptr,end, m) ){
			return false;
		}
	}

	// �{�[��
	zgU32 bnum;
	if( !get_val(ptr, end, bnum) )return false;
	tmp.aBone.resize(bnum);
	if(tmp.aBone.size() != bnum) return false;
	for(auto& b : tmp.aBone){
		if( !get_pmx_bone(header, ptr,end, b) ){
			return false;
		}
	}

	pmx = std::move(tmp);
	return true;
}


//-------------------------------------------
zgmdl::ModelPtr CreateModel(const PMDModel& pmd)
{
	using zgmdl::ModelPtr;
	using zgmdl::Model;
	using zgmdl::Material;
	using zgmdl::Object;
	using zgmdl::Vertex;
	using zgmdl::Mesh;
	using zgmdl::Bone;
	using zgmdl::Hierarchy;
	using zgmdl::InstList;
	
	ModelPtr model(new Model);
	if(!model)return ModelPtr();

	model->ResizeInstList(1);
	InstList* ilist = model->getInstList(0);
	if(!ilist)return ModelPtr();

	//�}�e���A��
	zgU32 mat_num = pmd.aMaterial.size();
	model->ResizeMat(mat_num);
	for(zgU32 m=0;m<mat_num;++m){
		Material* mat = model->getMat(m);
		if(!mat)break;
		mat->strName = (boost::format("mat%1%") % m).str().c_str();

		const PMDMaterial& pmdmat = pmd.aMaterial[m];
		
		mat->strShader = "lpp_pmd";

		//�e�N�X�`���t�@�C��
		//*�X�t�B�A�}�b�v�̕��� texfile_name��0�ŏI���Ȃ��悤�Ȃ̂Ŗʓ|
		auto& texfile_name = pmdmat.texfile_name;
		char texfile[sizeof(texfile_name)+1];
		strncpy_s(texfile, texfile_name, sizeof(texfile_name));
		texfile[sizeof(texfile_name)] = 0;
		char* str = strchr(texfile,'*');
		char* sphere = nullptr;
		if(str){
			*str = 0;
			sphere = str+1;
		}
		mat->numTex = 3;
		mat->aTex[0].strTex = texfile;
		if( pmdmat.toon_index < pmd.aToon.size()){
			mat->aTex[1].strTex = pmd.aToon[pmdmat.toon_index];
		}else{
			mat->aTex[1].strTex = "notex.png";
		}
		if( sphere ){
			mat->aTex[2].strTex = sphere;
		}else{
			mat->aTex[2].strTex = "zero.png";
		}
		mat->v4Diff = pmd.aMaterial[m].diffuse;
		const ZGVECTOR3& spc = pmd.aMaterial[m].specular;
		mat->v4Spec = ZGVECTOR4(spc.x,spc.y,spc.z, pmd.aMaterial[m].specularity);
	}

	model->ResizeObj(1);
	Object* obj = model->getObj(0);
	if(!obj)return ModelPtr();
	
	//���b�V��
	obj->ResizeMesh(mat_num);
	zgU32 vidx_start = 0;
	for(zgU32 m=0;m<mat_num;++m){
		Mesh* mesh = obj->getMesh(m);
		if(!mesh)return ModelPtr();
		
		mesh->setMatIdx(m);

		zgU32 face_vidx_num = pmd.aMaterial[m].face_vert_count;
		mesh->ResizeVertex(5);
		Vertex* pos = mesh->getVertex(0);
		Vertex* nor = mesh->getVertex(1);
		Vertex* tc0 = mesh->getVertex(2);
		Vertex* boneidx = mesh->getVertex(3);
		Vertex* bonewgt = mesh->getVertex(4);
		Vertex& idx = mesh->getIndex();
		if( !pos || !nor || !tc0 || !boneidx || !bonewgt){
			return ModelPtr();
		}
		// ���_�錾
		mesh->ResizeDecl(5);
		mesh->setDecl(0, 0, 0, "POSITION");
		mesh->setDecl(1, 1, 0, "NORMAL");
		mesh->setDecl(2, 2, 0, "TEXCOORD");
		mesh->setDecl(3, 3, 1, "BONEINDEX");
		mesh->setDecl(4, 4, 1, "BONEWEIGHT");

		pos->Create(Vertex::POSITION, face_vidx_num, Vertex::FMT_F32, 3);
		nor->Create(Vertex::NORMAL, face_vidx_num, Vertex::FMT_F32, 3);
		tc0->Create(Vertex::TEXCRD0, face_vidx_num, Vertex::FMT_F32, 2);
		boneidx->Create(Vertex::BONEINDEX, face_vidx_num, Vertex::FMT_U16, 4);
		bonewgt->Create(Vertex::BONEWEIGHT, face_vidx_num, Vertex::FMT_U8, 4);
		idx.Create(Vertex::INDEX, face_vidx_num, Vertex::FMT_U32, 1);


		for(zgU32 v=0;v<face_vidx_num;++v){
			zgU32 vidx = pmd.aFaceVidx[vidx_start + v]; 
			auto& vtx = pmd.aVertex[vidx];
			pos->setData(v, vtx.pos);
			nor->setData(v, vtx.normal);
			tc0->setData(v, vtx.uv);

			// �{�[���E�G�C�g
			zgU16 bidx[4] = {vtx.bone_idx[0], vtx.bone_idx[1], 0, 0};
			zgU8 bwgt[4] = {vtx.bone_weight, 100-vtx.bone_weight, 0, 0};

			// ���I�I�@vtx.edge_flag�����p�Ƀ{�[���E�G�C�g��w���g�p
			bwgt[3] = vtx.edge_flag? 0 : 1;
			
			boneidx->setData(v, bidx);
			bonewgt->setData(v, bwgt);

			// ���L���_�����ׂĕ���
			// ���ԃ��f���ōēx���_�̋��L�i�}�[�W�j�\��
			idx.setData(v, v);
		}

		vidx_start += face_vidx_num;

		// �`�惊�X�g�ɒǉ�
		ilist->aElem.push_back( InstList::Elem(0,0,m,m) );
	}


	//�{�[��
	zgU32 bone_num = pmd.aBone.size();
	model->ResizeBone(bone_num);
	for(zgU32 ib=0;ib<bone_num;++ib){
		Bone* bone = model->getBone(ib);
		Hierarchy* hier = model->getHier(ib);
		if(!bone || !hier)break;
		bone->strName = pmd.aBone[ib].bone_name;
		hier->idxParent = pmd.aBone[ib].parent_bidx;


		if(hier->idxParent >= bone_num) hier->idxParent = zgU32(-1);
		hier->idxSelf = ib;

		// �Ƃ肠������]�𖳎��i�P�ʍs��Œ�j�����K�w�\��
		// �{�[���̈ʒu�ɍ��킹���p���ɂ���ƃ��[�V���������܂��Đ��ł��Ȃ�
		// ������ۂ������Ă���̂ŁA�Ƃ肠������񂵂�
		// MMD�Ń{�[���̕��������Ă݂��
		// ���̃{�[����-Y������
		// �r�̃{�[����+X������
		// �ǂ�������Ń{�[���̕��������肵�Ă��邩�s��
		// ���Ԃ�{�[����head-tail�����Ɉ�ԋ߂����Ǝv������

		const PMDBone& pmd_bone = pmd.aBone[ib];

		XMVECTOR head_pos = ToXMVec(pmd_bone.bone_head_pos);
		XMVECTOR parent_pos =  {0,0,0,1};
		if( hier->idxParent < bone_num ){
			parent_pos = ToXMVec( pmd.aBone[ hier->idxParent ].bone_head_pos );
		}

		XMVECTOR tail_pos = {0,0,0,1};
		if( pmd_bone.tail_pos_bidx < bone_num ){
			tail_pos = ToXMVec(pmd.aBone[ pmd_bone.tail_pos_bidx ].bone_head_pos);
		}
		XMVECTOR local_pos = XMVectorSubtract(head_pos, parent_pos);

		bone->vPos = ToVec3(local_pos);
		bone->vScale = ZGVECTOR3(1.0f, 1.0f, 1.0f);
		bone->qRot = ToQuat(XMQuaternionIdentity());
		
	}

	//���_�}�[�W
	MergeVertex(*model);

	//return model;
	{// �֊s�����b�V���A�}�e���A���̍쐬�ǉ�
		Mesh outline_mesh, sdwvol_mesh;
		zgmdl::CreateGeoOutline(*obj, outline_mesh);
		zgmdl::CreateShadowVol(*obj, sdwvol_mesh);

		zgU32 mesh_num = obj->MeshNum();
		obj->ResizeMesh(mesh_num+2);

		zgU32 mat_num = model->MatNum();
		model->ResizeMat(mat_num+2);
		Material* oline_mat = model->getMat(mat_num);
		oline_mat->strShader = "outline_b";
		outline_mesh.setMatIdx(mat_num);

		// ���@�V���h�E�{�����[��
		Material* sdwvol_mat = model->getMat(mat_num+1);
		sdwvol_mat->strShader = "shadow_b";
		sdwvol_mesh.setMatIdx(mat_num+1);
		// �Ƃ肠�����R�s�[
		// ���_�f�[�^�Ȃǂ����L����悤�ɕύX�\��

		*obj->getMesh(mesh_num) = std::move( outline_mesh );
		*obj->getMesh(mesh_num+1) = std::move( sdwvol_mesh );


		// �֊s�����b�V���C���X�^���X
		model->ResizeInstList(3);
		{
			InstList* ilist = model->getInstList(1);
			if(ilist){
				ilist->aElem.push_back( InstList::Elem(0,0,mat_num,mesh_num) );
			}
		}
		{
			InstList* ilist = model->getInstList(2);
			if(ilist){
				ilist->aElem.push_back( InstList::Elem(0,0,mat_num+1,mesh_num+1) );
			}
		}
	}
	
	return model;
}
//-------------------------------------------
bool CreateModel(const PMXModel& pmx, zgmdl::Model& model)
{

	using zgmdl::ModelPtr;
	using zgmdl::Model;
	using zgmdl::Material;
	using zgmdl::Object;
	using zgmdl::Vertex;
	using zgmdl::Mesh;
	using zgmdl::Bone;
	using zgmdl::Hierarchy;
	using zgmdl::InstList;

	Model tmp;
	
	tmp.ResizeInstList(1);
	InstList* ilist = tmp.getInstList(0);
	if(!ilist)return false;

	//�}�e���A��
	zgU32 mat_num = pmx.aMaterial.size();
	tmp.ResizeMat(mat_num);
	for(zgU32 m=0;m<mat_num;++m){
		Material* mat = tmp.getMat(m);
		if(!mat)break;
		const PMXMaterial& pmxmat = pmx.aMaterial[m];
		mat->strName = pmxmat.strName;
		mat->strShader = "lpp_pmx";
		mat->v4Diff = pmxmat.colDiff;
		mat->v4Spec = pmxmat.colSpec;
		mat->numTex = 3;
		
		// �ʏ�e�N�X�`��
		if( pmxmat.idxTex0 < pmx.aTexPath.size() ){
			mat->aTex[0].strTex = pmx.aTexPath[pmxmat.idxTex0];
		}

		// �g�D�[���e�N�X�`��
		if(pmxmat.bToon == 0){
			if( pmxmat.idxToonTex < pmx.aTexPath.size() ){
				mat->aTex[1].strTex = pmx.aTexPath[pmxmat.idxToonTex];
			}else{
				mat->aTex[1].strTex = "notex.png";
			}
		}else{
			//���L�g�D�[���e�N�X�`��
			const char* const toon_tex[10] = {
				"toon01.bmp",
				"toon02.bmp",
				"toon03.bmp",
				"toon04.bmp",
				"toon05.bmp",
				"toon06.bmp",
				"toon07.bmp",
				"toon08.bmp",
				"toon09.bmp",
				"toon10.bmp"
			};
			if( pmxmat.idxToon < 10){
				mat->aTex[1].strTex = toon_tex[pmxmat.idxToon];
			}
		}

		//�X�t�B�A�}�b�v
		if( pmxmat.bitTex != PMXMaterial::TBIT_NONE && pmxmat.idxTex1 < pmx.aTexPath.size() ){
			mat->aTex[2].strTex = pmx.aTexPath[pmxmat.idxTex1];
		}else{
			// ���@�V�F�[�_�͉��Z�X�t�B�A�}�b�v�̂�
			mat->aTex[2].strTex = "zero.png";
		}

	}
	tmp.ResizeObj(1);
	Object* obj = tmp.getObj(0);
	if(!obj)return false;

	//���b�V��
	obj->ResizeMesh(mat_num);//���b�V�������}�e���A����
	zgU32 vidx_start = 0;
	for(zgU32 m=0;m<mat_num;++m){
		Mesh* mesh = obj->getMesh(m);
		if(!mesh)return ModelPtr();
		
		mesh->setMatIdx(m);

		zgU32 face_vidx_num = pmx.aMaterial[m].numVertex;

		//���_�f�[�^�@�ǉ�UV�͖���
		mesh->ResizeVertex(5);
		Vertex* pos = mesh->getVertex(0);
		Vertex* nor = mesh->getVertex(1);
		Vertex* tc0 = mesh->getVertex(2);
		Vertex* boneidx = mesh->getVertex(3);
		Vertex* bonewgt = mesh->getVertex(4);
		Vertex& idx = mesh->getIndex();
		if( !pos || !nor || !tc0 || !boneidx || !bonewgt){
			return ModelPtr();
		}
		// ���_�錾
		mesh->ResizeDecl(5);
		mesh->setDecl(0, 0, 0, "POSITION");
		mesh->setDecl(1, 1, 0, "NORMAL");
		mesh->setDecl(2, 2, 0, "TEXCOORD");
		mesh->setDecl(3, 3, 1, "BONEINDEX");
		mesh->setDecl(4, 4, 1, "BONEWEIGHT");

		pos->Create(Vertex::POSITION, face_vidx_num, Vertex::FMT_F32, 3);
		nor->Create(Vertex::NORMAL, face_vidx_num, Vertex::FMT_F32, 3);
		tc0->Create(Vertex::TEXCRD0, face_vidx_num, Vertex::FMT_F32, 2);
		boneidx->Create(Vertex::BONEINDEX, face_vidx_num, Vertex::FMT_U16, 4);
		bonewgt->Create(Vertex::BONEWEIGHT, face_vidx_num, Vertex::FMT_U8, 4);
		idx.Create(Vertex::INDEX, face_vidx_num, Vertex::FMT_U32, 1);
		
		for(zgU32 v=0;v<face_vidx_num;++v){
			zgU32 vidx = pmx.aFaceVidx[vidx_start + v]; 
			auto& vtx = pmx.aVertex[vidx];
			pos->setData(v, vtx.vPos);
			nor->setData(v, vtx.vNor);
			tc0->setData(v, vtx.vUV);

			// �{�[���E�G�C�g
			zgU16 bidx[4];
			zgU8 bwgt[4];
			zgS32 wgt_sum = 0;
			for(zgU32 i=0;i<4;i++){
				bidx[i] = vtx.vBidx.v[i];
				zgS32 w = zgS32(vtx.vBwgt.v[i]*255 + 0.0000001f);
				wgt_sum += w;
				bwgt[i] = static_cast<zgU8>(w);
			}
			if( wgt_sum > 0 ){
				bwgt[0] += (255 - wgt_sum);
				if(bwgt[0] > 255)bwgt[0] = 255;
			}

			// ���I�I�@vtx.edge_flag�����p�Ƀ{�[���E�G�C�g��w���g�p
			//bwgt[3] = vtx.edge_flag? 0 : 1;
			
			boneidx->setData(v, bidx);
			bonewgt->setData(v, bwgt);

			// ���L���_�����ׂĕ���
			// ���ԃ��f���ōēx���_�̋��L�i�}�[�W�j�\��
			idx.setData(v, v);
		}

		vidx_start += face_vidx_num;
		
		// �`�惊�X�g�ɒǉ�
		ilist->aElem.push_back( InstList::Elem(0,0,m,m) );
	}

	//�{�[��
	zgU32 bone_num = pmx.aBone.size();
	tmp.ResizeBone(bone_num);
	for(zgU32 ib=0;ib<bone_num;++ib){
		Bone* bone = tmp.getBone(ib);
		Hierarchy* hier = tmp.getHier(ib);
		if(!bone || !hier)break;
		bone->strName = pmx.aBone[ib].strName;
		hier->idxParent = pmx.aBone[ib].idxParent;
		
		if(hier->idxParent >= bone_num) hier->idxParent = zgU32(-1);
		hier->idxSelf = ib;

		// �Ƃ肠������]�𖳎��i�P�ʍs��Œ�j�����K�w�\��
		// �{�[���̈ʒu�ɍ��킹���p���ɂ���ƃ��[�V���������܂��Đ��ł��Ȃ�
		// ������ۂ������Ă���̂ŁA�Ƃ肠������񂵂�
		const PMXBone& pmd_bone = pmx.aBone[ib];

		XMVECTOR head_pos = ToXMVec(pmd_bone.vPos);
		XMVECTOR parent_pos =  {0,0,0,1};
		if( hier->idxParent < bone_num ){
			parent_pos = ToXMVec( pmx.aBone[ hier->idxParent ].vPos );
		}

		XMVECTOR local_pos = XMVectorSubtract(head_pos, parent_pos);

		bone->vPos = ToVec3(local_pos);
		bone->vScale = ZGVECTOR3(1.0f, 1.0f, 1.0f);
		bone->qRot = ToQuat(XMQuaternionIdentity());
	}

	//���_�}�[�W
	MergeVertex(tmp);

	model = std::move(tmp);
	return true;
}
