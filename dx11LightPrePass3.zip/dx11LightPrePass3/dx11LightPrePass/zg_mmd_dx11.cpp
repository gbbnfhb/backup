#include "stdafx.h"

#include "zg_mmd_dx11.h"
#include "zg_ptrx11.h"
#include "zg_mdlx11.h"
using namespace zix11;
using namespace DirectX;

namespace{

XMVECTOR ToXMVec(const ZGVECTOR3& v)
{
	return XMVectorSet(v.x,v.y,v.z, 0);
}
XMVECTOR ToXMVecW1(const ZGVECTOR3& v)
{
	return XMVectorSet(v.x,v.y,v.z, 1);
}
XMVECTOR ToXMVec(const ZGVECTOR4& v)
{
	return XMVectorSet(v.x,v.y,v.z,v.w);
}
XMVECTOR ToXMVec(const ZGQUAT& v)
{
	return XMVectorSet(v.x,v.y,v.z,v.w);
}
ZGVECTOR3 ToVec3(XMVECTOR v)
{
	return ZGVECTOR3(XMVectorGetX(v),XMVectorGetY(v),XMVectorGetZ(v));
}
ZGQUAT ToQuat(XMVECTOR v)
{
	return ZGQUAT(XMVectorGetX(v),XMVectorGetY(v),XMVectorGetZ(v),XMVectorGetW(v));
}


// http://d.hatena.ne.jp/edvakf/20111016/1318716097
float Bezier(float x1, float x2, float y1, float y2, float x)
{
	x1 = x1/127.0f;
	y1 = y1/127.0f;
	x2 = x2/127.0f;
	y2 = y2/127.0f;
	float t = 0.5f, s = 0.5f;
	for (int i = 0; i < 15; i++) {
		float ft = (3*s*s *t *x1) + (3*s *t*t *x2) + (t*t*t) - x;
		if (ft == 0) break;
		if (ft > 0){
			t -= 1.0f / float(4 << i);
		}else{ // ft < 0
			t += 1.0f / float(4 << i);
		}
		s = 1 - t;
	}
	return (3*s*s *t *y1) + (3*s *t*t *y2) + (t*t*t);
}

}//ns

namespace mmdx11
{

//--------------------------------------
// �X�P�[���A��]�A�ړ��s��
XMMATRIX SRTMatrix(XMVECTOR scale, XMVECTOR quat_rot, XMVECTOR trans)
{
	return XMMatrixMultiply(
					XMMatrixMultiply(
						XMMatrixScalingFromVector( scale),
						XMMatrixRotationQuaternion( quat_rot) ),
					XMMatrixTranslationFromVector( trans ) );
}

//--------------------------------------
//�p���s��X�V
void MeshModel::UpdatePose()
{
	MeshBone* bone = reinterpret_cast<MeshBone*>(binBone.get());
	XMMATRIX* mtx_pose = reinterpret_cast<XMMATRIX*>(binMtxPose.get());

	// �K�w�v�Z
	for(zgU32 ib=0;ib<numBone;++ib){
		mtx_pose[ib] = SRTMatrix(bone[ib].vScale, bone[ib].qRot, bone[ib].vPos);

		if( bone[ib].idxParent < numBone){
			mtx_pose[ib] = XMMatrixMultiply(mtx_pose[ib], mtx_pose[bone[ib].idxParent]);
		}
	}
}
//--------------------------------------------
bool CreateMeshModel(const VMDMotion& vmd, const zgmdl::Model& model, MeshModel& mmodel)
{
	zgU32 bone_num = model.BoneNum();
	mmodel.numBone = bone_num;
		
	//�s��p�������m�ہ@16byte align�ɂ��Ȃ��ƃx�N�g���v�Z�ŃG���[
	mmodel.binBone.Alloc(sizeof(MeshBone)*bone_num,16);
	mmodel.binMtxPose.Alloc(sizeof(XMMATRIX)*bone_num,16);
	mmodel.binMtxInitBone.Alloc(sizeof(XMMATRIX)*bone_num,16);
	mmodel.binMtxSubBone.Alloc(sizeof(XMVECTOR)*3*bone_num,16);//float3x4

	MeshBone* bone = reinterpret_cast<MeshBone*>(mmodel.binBone.get());
	XMMATRIX* mtx_pose = reinterpret_cast<XMMATRIX*>(mmodel.binMtxPose.get());
	XMMATRIX* mtx_init = reinterpret_cast<XMMATRIX*>(mmodel.binMtxInitBone.get());
	MATRIX43* mtx_sub = reinterpret_cast<MATRIX43*>(mmodel.binMtxSubBone.get());

	for(zgU32 ib=0;ib<bone_num;++ib){
		const zgmdl::Bone* mdl_bone = model.getBone(ib);
		const zgmdl::Hierarchy* mdl_hier =  model.getHier(ib);
		bone[ib].idxParent = mdl_hier->idxParent;
		bone[ib].qRot = ToXMVec(mdl_bone->qRot);
		bone[ib].vPos = ToXMVec(mdl_bone->vPos);
		bone[ib].vScale = ToXMVec(mdl_bone->vScale);
		strcpy_s(bone[ib].name, mdl_bone->strName.c_str());
		bone[ib].ik_min = XMVectorSet(-XM_PI,-XM_PI,-XM_PI,0);
		bone[ib].ik_max = XMVectorSet(XM_PI,XM_PI,XM_PI,0);

		//���O��"�Ђ�"�����������]����
		if(zgstl::String::npos != mdl_bone->strName.find("�Ђ�")){
			bone[ib].ik_min = XMVectorSet(-XM_PI,0,0,0);
			bone[ib].ik_max = XMVectorSet(0,0,0,0);
		}

		//���[���h�s��v�Z
		mtx_pose[ib] = SRTMatrix( bone[ib].vScale, bone[ib].qRot, bone[ib].vPos);
		if( bone[ib].idxParent < bone_num){
			mtx_pose[ib] = XMMatrixMultiply(mtx_pose[ib], mtx_pose[bone[ib].idxParent]);
		}

		mtx_init[ib] = mtx_pose[ib];
		XMMATRIX iden = XMMatrixIdentity();
		mtx_sub[ib].r[0] = iden.r[0];
		mtx_sub[ib].r[1] = iden.r[1];
		mtx_sub[ib].r[2] = iden.r[2];
	}

	// �Ƃ肠�������[�V�����f�[�^�쐬
	// �{�[�����ƂɎd�����A�L�[�l�Ń\�[�g
	Motion& mot = mmodel.Mot;
	for( auto& key : vmd.aKeyFrame){
		zgU32 midx = 0;
		for( auto& m : mot.aData){
			if(m.strBoneName == key.BoneName){
				break;
			}
			++midx;
		}
		if( midx >= mot.aData.size()){
			mot.aData.push_back(MotionData());
		}
		MotionData& data = mot.aData[midx];
		data.strBoneName = key.BoneName;


		KeyFrame frame;
		frame.pos = key.Location;
		frame.rot = key.Rotatation;
		frame.time = key.FlameNo;
		memcpy(frame.Intp, key.Interpolation, sizeof(frame.Intp));

		//���Βl�����Βl�ɕύX
		zgU32 bidx = 0;
		for(bidx=0;bidx<bone_num;++bidx){
			if(data.strBoneName == bone[bidx].name){
				data.idxBone = bidx;
				frame.pos.v[0] += XMVectorGetX(bone[bidx].vPos);
				frame.pos.v[1] += XMVectorGetY(bone[bidx].vPos);
				frame.pos.v[2] += XMVectorGetZ(bone[bidx].vPos);
				break;
			}
		}
		//���̂����������������ǋC�ɂ��Ȃ�

		data.Key.push_back(frame);

	}
	// �\�[�g�@�f�[�^�̕��т��ł���߂Ȃ̂�
	for( auto& m : mot.aData){
		std::sort(m.Key.begin(),m.Key.end());
	}
	return true;
}

//-------------------------------------------
// �Ƃ肠�����A�j���[�V����
bool VMDAnimation(float key_time, MeshModel& model)
{
	if( model.numBone == 0 )return false;

	MeshBone* bone = reinterpret_cast<MeshBone*>(model.binBone.get());
	XMMATRIX* mtx_pose = reinterpret_cast<XMMATRIX*>(model.binMtxPose.get());

	Motion& mot = model.Mot;
	for(auto& m : mot.aData){
		if(m.Key.size() == 0)continue;
		
		//�L�[����
#if 1
		typedef zgstl::Vector<KeyFrame>::T::iterator key_ite;
		key_ite next = std::lower_bound(m.Key.begin(), m.Key.end(), key_time,
						[](const KeyFrame& k,float t){return k.time < t;} );
		
		if(next == m.Key.end()){ next = m.Key.end()-1; }
		key_ite prev = next;
		if(prev>m.Key.begin()){ --prev; }
		KeyFrame& key0 = *prev;
		KeyFrame& key1 = *next;
#else
		zgU32 next = 0;
		for(auto& k : m.Key){
			if(k.time >= key_time){
				break;
			}
			++next;
		}
		if(next >= m.Key.size())next = m.Key.size()-1;

		zgU32 prev = next;
		if(next>0)prev = next-1;
		KeyFrame& key0 = m.Key[prev];
		KeyFrame& key1 = m.Key[next];
#endif
		float t = 1.0f;
		if(next!=prev){
			t = float(key_time - key0.time )/float(key1.time - key0.time);
		}
		if(t < 0.0f)t = 0.0f;
		if(t > 1.0f)t = 1.0f;
		zgU32 ib = m.idxBone;
		if(ib < model.numBone){
			XMVECTOR pos0 = ToXMVec(key0.pos);
			XMVECTOR pos1 = ToXMVec(key1.pos);
			XMVECTOR rot0 = ToXMVec(key0.rot);
			XMVECTOR rot1 = ToXMVec(key1.rot);
			// key0.Intp[] = 
			// X_x1, Y_x1, Z_x1, R_x1, X_y1,Y_y1,Z_y1,R_y1,
			// X_x2,Y_x2,Z_x2,R_x2,X_y2,Y_y2,Z_y2,R_y2,
			float tx = Bezier(key0.Intp[0],key0.Intp[8], key0.Intp[4], key0.Intp[12], t);
			float ty = Bezier(key0.Intp[1],key0.Intp[9], key0.Intp[5], key0.Intp[13], t);
			float tz = Bezier(key0.Intp[2],key0.Intp[10], key0.Intp[6], key0.Intp[14], t);
			float tr = Bezier(key0.Intp[3],key0.Intp[11], key0.Intp[7], key0.Intp[15], t);

			bone[ib].vPos = XMVectorLerpV(pos0, pos1, XMVectorSet(tx,ty,tz,0.0f));
			bone[ib].qRot = XMQuaternionSlerp(rot0, rot1, tr);
		}
	}
	return true;
}

//-------------------------------------------
// �Ƃ肠����IK
bool PMDIkAnimation(MeshModel& model)
{
	if( model.numBone == 0 )return false;
	
	MeshBone* bone = reinterpret_cast<MeshBone*>(model.binBone.get());
	XMMATRIX* mtx_pose = reinterpret_cast<XMMATRIX*>(model.binMtxPose.get());
	
	// IK�v�Z
	XMVECTOR eps0 = {0.0000001f,0.0000001f,0.0000001f,0.0000001f};
	for(auto& ik : model.aIK){
		for(zgU32 ite=0;ite<ik.iterations;++ite){
			zgU32 tg_idx = ik.target_bone_index;
			zgU32 ik_idx = ik.bone_index;
			XMVECTOR target_pos = mtx_pose[tg_idx].r[3];
			for(zgU32 chn=0;chn<ik.chain_length;++chn){
				zgU32 pa_idx = ik.child_bone_index[chn];//
						
				//�e�̃��[�J����Ԃɕϊ�
				XMMATRIX inv_mtx = XMMatrixInverse(nullptr, mtx_pose[pa_idx]);
				XMVECTOR tg_pos = XMVector4Transform(target_pos, inv_mtx);
				XMVECTOR ik_pos = XMVector4Transform( mtx_pose[ik_idx].r[3], inv_mtx);

				//�ڕW����
				XMVECTOR ik_dir = XMVector3Normalize(ik_pos);
				XMVECTOR tg_dir = XMVector3Normalize(tg_pos);
				if( XMVector3NearEqual(tg_dir, ik_dir, eps0) ){
					continue;
				}

				// ��]���Ɗp�x 
				XMVECTOR rot_axis = XMVector3Cross(tg_dir, ik_dir);
				if(XMVector3NearEqual(rot_axis,XMVectorSet(0,0,0,0),eps0)){
					continue;
				}
				rot_axis = XMVector3Normalize(rot_axis);
				float ang = XMVectorGetX( XMVectorACos(XMVector3Dot(tg_dir, ik_dir)) );

				//tg_dir��ik_dir�Ɉ�v�����邽�߂̉�]
				XMVECTOR rot = XMQuaternionRotationAxis(rot_axis,ang*ik.control_weight);

				bone[pa_idx].qRot = XMQuaternionMultiply( rot ,bone[pa_idx].qRot );	

				// ��]����
				XMMATRIX mtx = XMMatrixRotationQuaternion(bone[pa_idx].qRot);

				//ZYX�@Y=-90�`90��Y�����˂������
				//�ʏ�X�����{�[���̕����iX����]���˂���j�����ǁAPMD�̑��{�[����Y��
				float rx = -atan2f(XMVectorGetY(mtx.r[2]),XMVectorGetZ(mtx.r[2]));
				float ry = asinf(XMVectorGetX(mtx.r[2]));
				float rz = -atan2f(XMVectorGetX(mtx.r[1]),XMVectorGetX(mtx.r[0]));
				XMVECTOR rot_xyz = {rx,ry,rz,0};
				rot_xyz = XMVectorMax(rot_xyz, bone[pa_idx].ik_min);
				rot_xyz = XMVectorMin(rot_xyz, bone[pa_idx].ik_max);
				mtx = XMMatrixRotationZ( XMVectorGetZ(rot_xyz) );
				mtx = XMMatrixMultiply(mtx, XMMatrixRotationY( XMVectorGetY(rot_xyz) ));
				mtx = XMMatrixMultiply(mtx, XMMatrixRotationX( XMVectorGetX(rot_xyz) ));
				bone[pa_idx].qRot = XMQuaternionRotationMatrix(mtx);
						
				//���[���h�s��X�V
				mtx_pose[pa_idx] = SRTMatrix( bone[pa_idx].vScale, bone[pa_idx].qRot, bone[pa_idx].vPos);
				if( bone[pa_idx].idxParent < model.numBone){
					mtx_pose[pa_idx] = XMMatrixMultiply(mtx_pose[pa_idx], mtx_pose[bone[pa_idx].idxParent]);
				}
				mtx_pose[tg_idx] = SRTMatrix( bone[tg_idx].vScale, bone[tg_idx].qRot, bone[tg_idx].vPos);
				if( bone[tg_idx].idxParent < model.numBone){
					mtx_pose[tg_idx] = XMMatrixMultiply(mtx_pose[tg_idx], mtx_pose[bone[tg_idx].idxParent]);
				}
						
				//�ڕW�ʒu�X�V
				target_pos = mtx_pose[tg_idx].r[3];
			}
		}

		//IK�̌v�Z���ʂ��q�K�w�ɔ��f
		model.UpdatePose();
	}

	return true;
}


}//mmdx11