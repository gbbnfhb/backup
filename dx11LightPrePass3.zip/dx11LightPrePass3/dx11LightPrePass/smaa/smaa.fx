// SMAA.h�ŕK�v��define��`

// �V�F�[�_���f���@DX11�Ȃ̂�4.1
#define SMAA_HLSL_4_1	1	

// �s�N�Z���T�C�Y�i��ʉ𑜓x�j
#define SMAA_PIXEL_SIZE float2(1.0/640.0, 1.0/480.0)

// �i��
//#define SMAA_PRESET_LOW		1	//(%60 of the quality)
//#define SMAA_PRESET_MEDIUM	1	//(%80 of the quality)
#define SMAA_PRESET_HIGH	1	//(%95 of the quality)
//#define SMAA_PRESET_ULTRA	1	//(%99 of the quality)


#include "SMAA.h"

//SMAA 1x�̂ݑΉ�

Texture2D<float4> txColor : register( t0 );		// AA�Ώۂ̉摜�i�����_�����O���ʁj
Texture2D<float4> txEdge : register( t1 );		// �G�b�W���o����
Texture2D<float4> txBlend : register( t2 );		// �u�����h���v�Z����
Texture2D<float4> txArea : register( t3 );		// ���O�v�Z�e�N�X�`��
Texture2D<float4> txSearch : register( t4 );	// ���O�v�Z�e�N�X�`��

//----------------------------------------
// �G�b�W���o
void EdgeDetectionVS(
		float4 position : POSITION,
		out float4 svPosition : SV_POSITION,
		inout float2 texcoord : TEXCOORD0,
		out float4 offset[3] : TEXCOORD1 )
{
	SMAAEdgeDetectionVS(position, svPosition, texcoord, offset);
}

float4 EdgeDetectionPS(
		float4 position : SV_POSITION,
		float2 texcoord : TEXCOORD0,
		float4 offset[3] : TEXCOORD1) : SV_TARGET
{
	//return SMAAColorEdgeDetectionPS(texcoord, offset, txColor);
	return SMAALumaEdgeDetectionPS(texcoord, offset, txColor);
}

//-----------------------------------------
// �u�����h���v�Z
void BlendingWeightCalculationVS(
		float4 position : POSITION,
		out float4 svPosition : SV_POSITION,
		inout float2 texcoord : TEXCOORD0,
		out float2 pixcoord : TEXCOORD1,
		out float4 offset[3] : TEXCOORD2 )
{
    SMAABlendingWeightCalculationVS(position, svPosition, texcoord, pixcoord, offset);
}

float4 BlendingWeightCalculationPS(
		float4 position : SV_POSITION,
		float2 texcoord : TEXCOORD0,
		float2 pixcoord : TEXCOORD1,
		float4 offset[3] : TEXCOORD2) : SV_TARGET
{
	int4 subsampleIndices = {0, 0, 0, 0};
    return SMAABlendingWeightCalculationPS(texcoord, pixcoord, offset, txEdge, txArea, txSearch, subsampleIndices);
}

//---------------------------------
// AA���s
void NeighborhoodBlendingVS(
		float4 position : POSITION,
		out float4 svPosition : SV_POSITION,
		inout float2 texcoord : TEXCOORD0,
		out float4 offset[2] : TEXCOORD1 )
{
    SMAANeighborhoodBlendingVS(position, svPosition, texcoord, offset);
}

float4 NeighborhoodBlendingPS(
		float4 position : SV_POSITION,
		float2 texcoord : TEXCOORD0,
		float4 offset[2] : TEXCOORD1,
		uniform SMAATexture2D colorTex,
		uniform SMAATexture2D blendTex) : SV_TARGET
{
    return SMAANeighborhoodBlendingPS(texcoord, offset, txColor, txBlend);
}

//�V�F�[�_�G�t�F�N�g��`
#ifdef ZGFX

	technique EdgeDetection
	{
		pass P0
		{
			CullMode = NONE;
			DepthEnable = FALSE;
			AlphaToCoverageEnable = FALSE;
			BlendEnable[0] = FALSE;
			
			VertexShader = compile vs_5_0 EdgeDetectionVS();
			PixelShader = compile ps_5_0 EdgeDetectionPS();
		}
	}

	technique BlendingWeightCalculation
	{
		pass P0
		{
			CullMode = NONE;
			DepthEnable = FALSE;
			AlphaToCoverageEnable = FALSE;
			BlendEnable[0] = FALSE;
			
			VertexShader = compile vs_5_0 BlendingWeightCalculationVS();
			PixelShader = compile ps_5_0 BlendingWeightCalculationPS();
		}
	}
	
	technique NeighborhoodBlending
	{
		pass P0
		{
			CullMode = NONE;
			DepthEnable = FALSE;
			AlphaToCoverageEnable = FALSE;
			BlendEnable[0] = FALSE;
			
			VertexShader = compile vs_5_0 NeighborhoodBlendingVS();
			PixelShader = compile ps_5_0 NeighborhoodBlendingPS();
		}
	}
	

#endif//ZGFX