Texture2D txDiffuse : register( t0 );
SamplerState samLinear : register( s0 );

#include "cb_main.h"

struct VS_INPUT_BONE
{
	float4 Pos : POSITION;
	float3 Nor : NORMAL;
	uint4 Bidx : BONEINDEX;
	uint4 Bwgt : BONEWEIGHT;
};

struct GS_INPUT
{
	float4 Pos : SV_POSITION;
	float Edge : COLOR;
};

struct PS_INPUT
{
	float4 Pos : SV_POSITION;
};


//-------------------------
//�{�[���ό`�����_�u�����h
GS_INPUT vsBasicBlend( VS_INPUT_BONE input)
{
	GS_INPUT output = (GS_INPUT)0;
	matrix world_mtx = mul(Object.mtxWorld, Model.mtxModel);
	
	float4 pos = input.Pos;
	
	// �X�N���[���V���b�g�p�떂�����@�@���̉e������
	if(input.Bwgt.w < 0.01){
		pos.xyz += 0.1*input.Nor;
	}
	float3 bpos0 = input.Bwgt[0]*mul(pos, getBoneMatrix(input.Bidx.x));
	float3 bpos1 = input.Bwgt[1]*mul(pos, getBoneMatrix(input.Bidx.y));
	pos.xyz = (bpos0.xyz + bpos1.xyz)/100;
	
	output.Pos = mul( pos, world_mtx );
	output.Edge = input.Bwgt.w;
	return output;
}

//---------------------------
//�œK���V���h�E�{�����[��
bool vec_equal(float3 a, float3 b)
{
//	return length(a-b)<0.0000001;
	return a.x==b.x && a.y==b.y && a.z==b.z;
}
// �W�I���g���V�F�[�_
[maxvertexcount(12)]
void gsBasic( triangleadj GS_INPUT input[6],
			uint primID : SV_PrimitiveID,
			inout TriangleStream<PS_INPUT> Stream )
{
	float3 sdw_dir = -normalize(Light.vDirLight[0].xyz);
	float4 v0 = input[0].Pos;
	float4 va01 = input[1].Pos;
	float4 v1 = input[2].Pos;
	float4 va12 = input[3].Pos;
	float4 v2 = input[4].Pos;
	float4 va20 = input[5].Pos;
	float4 vs0 = v0 + float4(sdw_dir*100.0,0);
	float4 vs1 = v1 + float4(sdw_dir*100.0,0);
	float4 vs2 = v2 + float4(sdw_dir*100.0,0);
	
	// �덷 �|���S���̖ʐςȂǂŒ������K�v
	const float d_eps = 0.0000001;

	float dl0 = dot( cross(v1.xyz - v0.xyz ,v2.xyz - v0.xyz).xyz, sdw_dir);
	if( dl0 > d_eps)return;

	float dl1 = dot( cross(va01.xyz - v0.xyz ,v1.xyz - v0.xyz).xyz, sdw_dir);
	float dl2 = dot( cross(va12.xyz - v1.xyz ,v2.xyz - v1.xyz).xyz, sdw_dir);
	float dl3 = dot( cross(va20.xyz - v2.xyz ,v0.xyz - v2.xyz).xyz, sdw_dir);
	
	float4x4 vpmtx = mul(Scene.mtxView, Scene.mtxProj);
	float4 pv0 = mul(v0, vpmtx);
	float4 pv1 = mul(v1, vpmtx);
	float4 pv2 = mul(v2, vpmtx);
	float4 pvs0 = mul(vs0, vpmtx);
	float4 pvs1 = mul(vs1, vpmtx);
	float4 pvs2 = mul(vs2, vpmtx);
	
	PS_INPUT vo0,vo1;

	//�אڃ|���S���̕`��ő��E�����ꍇ�́A�`�悵�Ȃ�
	//�אڃ|���S���������΂̏ꍇ�A�אڃ|���S���Ȃ��@�K���`��
	if(dl1 > d_eps || vec_equal(v2.xyz,va01.xyz)){
		vo0.Pos = pv0;
		vo1.Pos = pvs0;
		Stream.Append(vo0);
		Stream.Append(vo1);
		vo0.Pos = pv1;
		vo1.Pos = pvs1;
		Stream.Append(vo0);
		Stream.Append(vo1);
		Stream.RestartStrip();
	}
	if(dl2 > d_eps || vec_equal(v0.xyz,va12.xyz)){
		vo0.Pos = pv1;
		vo1.Pos = pvs1;
		Stream.Append(vo0);
		Stream.Append(vo1);
		vo0.Pos = pv2;
		vo1.Pos = pvs2;
		Stream.Append(vo0);
		Stream.Append(vo1);
		Stream.RestartStrip();
	}
	if(dl3 > d_eps || vec_equal(v1.xyz,va20.xyz)){
		vo0.Pos = pv2;
		vo1.Pos = pvs2;
		Stream.Append(vo0);
		Stream.Append(vo1);
		vo0.Pos = pv0;
		vo1.Pos = pvs0;
		Stream.Append(vo0);
		Stream.Append(vo1);
		Stream.RestartStrip();
	}
}

//-------------------------
//�s�N�Z���V�F�[�_
void psBasic( PS_INPUT input )
{
}

//-------------------------
//�V�F�[�_�G�t�F�N�g��`
#ifdef ZGFX

	technique Basic
	{
		pass P0
		{
			CullMode = NONE;
			DepthEnable = TRUE;
			DepthFunc = LESS;
			DepthWriteMask = ZERO;

			StencilEnable = TRUE;
			StencilReadMask = 0xff;
			StencilWriteMask = 0xff;
			FrontFaceStencilFail = KEEP;
			FrontFaceStencilDepthFail = KEEP;
			FrontFaceStencilPass = INCR;
			FrontFaceStencilFunc = ALWAYS;
			BackFaceStencilFail = KEEP;
			BackFaceStencilDepthFail = KEEP;
			BackFaceStencilPass = DECR;
			BackFaceStencilFunc = ALWAYS;
			
			VertexShader = compile vs_4_0 vsBasicBlend();
			GeometryShader = compile gs_4_0 gsBasic();
			PixelShader = compile ps_4_0 psBasic();
		}
	}

#endif//ZGFX

