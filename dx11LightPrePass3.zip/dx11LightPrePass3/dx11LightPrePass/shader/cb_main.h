//C++�̃w�b�_�Ɠ����\����
struct SCBScene
{
    matrix mtxProj;
    matrix mtxView;
    matrix mtxInvView;
	float4 vViewport;
};

struct SCBLight
{
    float4 vDirLight[4];
    float4 colDirLight[4];
	float4 vHemiDir;
	float4 colHemiSky;
	float4 colHemiGrd;
	float4 posPLight[4];
	float4 colPLight[4];
	float4 prmPLight[4];
};

struct SBCModel
{
	float4 colModel;
    matrix mtxModel;
};

struct SBCObject
{
    matrix mtxWorld;
};

struct SBCMaterial
{
	float4 Diffuse;
	float4 Specular;
};

struct SBCBoneMatrix
{
	matrix mtxBone[4];
};

cbuffer CB1 : register( b1 )
{
	SCBScene Scene;
};


cbuffer CB2 : register( b2 )
{
	SCBLight Light;
};

cbuffer CB3 : register( b3 )
{
	SBCModel Model;
};

cbuffer CB4 : register( b4 )
{
    SBCObject Object;
}

cbuffer CB5 : register( b5 )
{
	SBCMaterial Material;
}

#define CB_LOCAL_SLOT b6

cbuffer CB7 : register( b7 )
{
	float4x3 BoneMatrix[2] :  packoffset(c0);
	float4x3 BoneMatrixDmmy[253] :  packoffset(c6);
	float4x3 BoneMatrixEnd :  packoffset(c765);
}
float4x3 getBoneMatrix(int idx)
{
	return BoneMatrix[idx];
}



#define EXTTEX_SLOT0 t8
#define EXTTEX_SLOT1 t9
#define EXTTEX_SLOT2 t10
#define EXTTEX_SLOT3 t11
#define EXTSS_SLOT0 s8
#define EXTSS_SLOT1 s9
#define EXTSS_SLOT2 s10
#define EXTSS_SLOT3 s11
