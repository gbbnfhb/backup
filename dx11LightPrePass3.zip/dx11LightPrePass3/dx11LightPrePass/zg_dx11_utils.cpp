#include "stdafx.h"

#include "zg_dx11_utils.h"

#include "zg_renctx11.h"

using namespace DirectX;

zix11::RenContextX11& GetRenContext();

namespace zix11{

IBuffPtr CreateBuffer::Create(UINT size, const void* ptr)
{
	if( size == 0)return IBuffPtr();

	RenContextX11& renctx =  GetRenContext();
	IBuffPtr vtxbuff;

	D3D11_BUFFER_DESC bd;
	ZeroMemory( &bd, sizeof(bd) );
	bd.Usage = eUsage;
	bd.ByteWidth = size;
	bd.BindFlags = bitBind;
	bd.CPUAccessFlags = 0;
	if( ptr ){
		D3D11_SUBRESOURCE_DATA inidat;
		ZeroMemory( &inidat, sizeof(inidat) );
		inidat.pSysMem = ptr;
		hResult = renctx.pDev->CreateBuffer( &bd, &inidat, GSET_DXPTR(vtxbuff) );
	}else{
		hResult = renctx.pDev->CreateBuffer( &bd, nullptr, GSET_DXPTR(vtxbuff) );
	}
	if( FAILED(hResult) )return IBuffPtr();
	return vtxbuff;
}


//---------------------------------------------------
bool CreateSpriteGeom::Create(GeometryX11& geom)
{
	RenContextX11& renctx =  GetRenContext();
		
	GeometryX11 tmp;
	tmp.aInputDesc.push_back( InputDescX11("POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0) );
	tmp.aInputDesc.push_back( InputDescX11("TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12 ) );
	tmp.aInputDesc.push_back( InputDescX11("COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 20) );

	// ��ʍ���(-1,1)�A�E���i1,-1)�ł̍��W�n
	zgF32 left = 2.0f*vPosLT.x - 1.0f;
	zgF32 right = 2.0f*vPosRB.x - 1.0f;
	zgF32 top = 1.0f - 2.0f*vPosLT.y;
	zgF32 bottom = 1.0f - 2.0f*vPosRB.y;

	float vertex[4*9] = {
		left, top, 0.0f,  0.0f,0.0f,  1.0f,1.0f,1.0f,1.0f,
		right, top, 0.0f,  1.0f,0.0f,  1.0f,1.0f,1.0f,1.0f,
		left, bottom, 0.0f,  0.0f,1.0f,  1.0f,1.0f,1.0f,1.0f,
		right, bottom, 0.0f,  1.0f,1.0f,  1.0f,1.0f,1.0f,1.0f,
	};

	IBuffPtr vtxbuff;
	D3D11_BUFFER_DESC bd;
	ZeroMemory( &bd, sizeof(bd) );
	bd.Usage = D3D11_USAGE_DEFAULT;
	bd.ByteWidth = sizeof( vertex );
	bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	bd.CPUAccessFlags = 0;
	D3D11_SUBRESOURCE_DATA inidat;
	ZeroMemory( &inidat, sizeof(inidat) );
	inidat.pSysMem = vertex;
	HRESULT hr = renctx.pDev->CreateBuffer( &bd, &inidat, GSET_DXPTR(vtxbuff) );
	if( FAILED(hr) )return false;

	tmp.aVBuff.push_back( VertexBuffX11(vtxbuff, 36) );

	zgU16 index[4] = {0,1,2,3};
	bd.BindFlags = D3D11_BIND_INDEX_BUFFER;
	bd.ByteWidth = sizeof( index );
	inidat.pSysMem = index;
	hr = renctx.pDev->CreateBuffer( &bd, &inidat, GSET_DXPTR(tmp.pIdxBuff) );
	if( FAILED(hr) )return false;
	tmp.eIdxFormat = DXGI_FORMAT_R16_UINT;
	tmp.nCount = 4;
	tmp.eTopo = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP;

	geom = std::move(tmp);
	return true;
}

//---------------------------------------------------
bool CreateSphereGeom::Create(GeometryX11& geom)
{
	if( fRadius < 0.00000001f || uDivH<3 || uDivV<3)return false;
	RenContextX11& renctx =  GetRenContext();

	zgU32 vnum = (uDivV+1)*uDivH;
	std::vector<ZGVECTOR3> vertex(vnum);
	zgU32 iv = 0;
	for(zgU32 h=0;h<uDivH;++h){
		zgF32 angh = zgF32(h)/zgF32(uDivH)*3.1415926f*2.0f;
		for(zgU32 v=0;v<uDivV+1;++v){
			zgF32 angv = zgF32(v)/zgF32(uDivV)*3.1415926f;
			ZGVECTOR3 v0(0, fRadius*cosf(angv), fRadius*sinf(angv));
			vertex[iv++] = ZGVECTOR3( v0.z*sinf(angh), v0.y, v0.z*cosf(angh) );
		}
	}
	GeometryX11 tmp;
	tmp.aInputDesc.push_back( InputDescX11("POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0) );

	IBuffPtr vtxbuff;
	D3D11_BUFFER_DESC bd;
	ZeroMemory( &bd, sizeof(bd) );
	bd.Usage = D3D11_USAGE_DEFAULT;
	bd.ByteWidth = vertex.size()*12;
	bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	bd.CPUAccessFlags = 0;
	D3D11_SUBRESOURCE_DATA inidat;
	ZeroMemory( &inidat, sizeof(inidat) );
	inidat.pSysMem = vertex.data();
	HRESULT hr = renctx.pDev->CreateBuffer( &bd, &inidat, GSET_DXPTR(vtxbuff) );
	if( FAILED(hr) )return false;

	tmp.aVBuff.push_back( VertexBuffX11(vtxbuff, 12) );

	std::vector<zgU16> index(uDivV*uDivH*6);
	
	zgU32 ii = 0;
	for(zgU32 h=0;h<uDivH;++h){
		zgU32 h0 = h;
		zgU32 h1 = (h+1)%uDivH;
		for(zgU32 v=0;v<uDivV;++v){
			zgU32 v0 = v;
			zgU32 v1 = v+1;
			index[ii++] = (uDivV+1)*h0 + v0;
			index[ii++] = (uDivV+1)*h0 + v1;
			index[ii++] = (uDivV+1)*h1 + v0;
			index[ii++] = (uDivV+1)*h1 + v0;
			index[ii++] = (uDivV+1)*h0 + v1;
			index[ii++] = (uDivV+1)*h1 + v1;
		}
	}
	if(ii!=index.size())return false;

	bd.BindFlags = D3D11_BIND_INDEX_BUFFER;
	bd.ByteWidth = index.size()*2;
	inidat.pSysMem = index.data();
	hr = renctx.pDev->CreateBuffer( &bd, &inidat, GSET_DXPTR(tmp.pIdxBuff) );
	if( FAILED(hr) )return false;
	
	tmp.eIdxFormat = DXGI_FORMAT_R16_UINT;
	tmp.nCount = index.size();
	tmp.eTopo = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;

	geom = std::move(tmp);
	return true;
}

//---------------------------------
GPUPerformance::GPUPerformance()
	: idxPerfQuery(0)
{
}

//-----------------------------------
bool GPUPerformance::Create()
{
	RenContextX11& renctx =  GetRenContext();
	HRESULT hr;
	D3D11_QUERY_DESC query_desc;

	query_desc.MiscFlags = 0;
	query_desc.Query = D3D11_QUERY_PIPELINE_STATISTICS;
	for( auto& q : g_pPerfQuery){
		hr = renctx.pDev->CreateQuery(&query_desc, GSET_DXPTR(q));
		if( FAILED(hr) )return false;
	}
	D3D11_QUERY_DESC qocc_desc;
	qocc_desc.MiscFlags = 0;
	qocc_desc.Query = D3D11_QUERY_OCCLUSION;
	for( auto& q : g_pPerfQueryOcc){
		hr = renctx.pDev->CreateQuery(&qocc_desc, GSET_DXPTR(q));
		if( FAILED(hr) )return false;
	}	
	return  true;
}
//--------------------------------
// ����J�n
void GPUPerformance::Begin()
{
	RenContextX11& renctx =  GetRenContext();
	renctx.pImCtx->Begin(g_pPerfQuery[idxPerfQuery].get());
	renctx.pImCtx->Begin(g_pPerfQueryOcc[idxPerfQuery].get());
}

//--------------------------------
// ����I��
void GPUPerformance::End()
{
	RenContextX11& renctx =  GetRenContext();
	renctx.pImCtx->End(g_pPerfQueryOcc[idxPerfQuery].get());
	renctx.pImCtx->End(g_pPerfQuery[idxPerfQuery].get());
	
	idxPerfQuery = (idxPerfQuery+1)%PerfQueryNum;
}

//--------------------------------
bool GPUPerformance::Get( D3D11_QUERY_DATA_PIPELINE_STATISTICS& data )
{
	RenContextX11& renctx =  GetRenContext();
	ZeroMemory(&data, sizeof(data));
	zgU32 wait_cnt = 0;
	while(1){
		zgU32 idx = (idxPerfQuery)%PerfQueryNum;
		HRESULT hr = renctx.pImCtx->GetData( g_pPerfQuery[idx].get(), &data, sizeof(data),0);
		if(hr == S_OK)break;
		if(hr != S_FALSE)return false;//�G���[
		++wait_cnt;
	}
	return true;
}

//--------------------------------
bool GPUPerformance::GetPixelWrite(zgU64& count)
{
	RenContextX11& renctx =  GetRenContext();
	count = 0;
	zgU32 wait_cnt = 0;
	while(1){
		zgU32 idx = (idxPerfQuery)%PerfQueryNum;
		HRESULT hr = renctx.pImCtx->GetData( g_pPerfQueryOcc[idx].get(), &count, sizeof(count),0);
		if(hr == S_OK)break;
		if(hr != S_FALSE)return false;//�G���[
		++wait_cnt;
	}
	return true;
}

}//zix11
