#pragma once

// DirectX11���f���f�[�^

#include "zg_types.h"
#include "zg_utils.h"
#include "zg_model.h"

#include "zg_ptrx11.h"
#include "zg_shdfx.h"

#include <directxmath.h>
#include <string>
#include "zg_stl.h"

namespace zix11{

class ShaderPass;
class ShaderTech;
class TextureX11;
class MaterialX11;
class MeshX11;
class GeometryX11;
class ModelObjectX11;
class ModelX11;
typedef SPtr<ShaderPass>::Type SPassPtr;
typedef SPtr<ShaderTech>::Type STechPtr;
typedef SPtr<MaterialX11>::Type MatX11Ptr;
typedef SPtr<TextureX11>::Type TexX11Ptr;
typedef SPtr<MeshX11>::Type MeshX11Ptr;
typedef SPtr<GeometryX11>::Type GeomX11Ptr;
typedef SPtr<ModelObjectX11>::Type ModelObjX11Ptr;
typedef SPtr<ModelX11>::Type ModelX11Ptr;

class RenElemX11
{
public:
	zgU32 idxPass;
	SPassPtr pPass;
};

class RenListX11
{
public:
	zgstl::Vector<RenElemX11>::T aDList;
};


// ���f��
class ModelX11
{
public:
	ModelX11() : numBoneMtx(0), sizeBoneMtx(0){}
	
	zgstl::Vector<ModelObjX11Ptr>::T apObj;
	zgstl::Vector<MatX11Ptr>::T apMat;

	IBuffPtr pCBModel;//SCBModel�萔�o�b�t�@
	IBuffPtr pCBBoneMtx;//�{�[���s��
	zgU32 numBoneMtx;
	zgU32 sizeBoneMtx;

	// �C���X�^���X�@�H����
	zgstl::Vector<zgmdl::InstList>::T aInst;
	zgU32 CreateRenList(zgU32 ren_idx, zgU32 tech_idx, RenListX11& renlist);
};

// �e�N�X�`��
class TextureX11
{
public:
	ISRViewPtr pSRView;
	ISpStatePtr pSpState;
};

// �}�e���A��
class MaterialX11
{
public:
	MaterialX11() :	vDiffuse(1,1,1,1), vSpecular(0,0,0,0){}
	
	ZGVECTOR4 vDiffuse;
	ZGVECTOR4 vSpecular;
	zgstl::Vector<TextureX11>::T aTex;
	SEffectPtr pEffect;

	IBuffPtr pCBMateiral;//SCBMaterial�萔�o�b�t�@
};

// �I�u�W�F�N�g
class ModelObjectX11
{
public:
	ModelObjectX11(){}

	zgstl::Vector<MeshX11Ptr>::T apMesh;
	IBuffPtr pCBObject;//SCBObject�萔�o�b�t�@
};

struct VertexBuffX11
{
	VertexBuffX11() : uStride(0), uOffset(0){}
	VertexBuffX11(const IBuffPtr& buff, UINT s, UINT o=0)
		: pVBuff(buff), uStride(s), uOffset(0){}

	IBuffPtr pVBuff;
	UINT uStride;
	UINT uOffset;
};

struct InputDescX11
{
	InputDescX11(){}
	InputDescX11(const char* sema, UINT sidx, DXGI_FORMAT fmt, UINT slot, UINT ofs)
		: SemanticName(sema), SemanticIndex(sidx), Format(fmt), InputSlot(slot), AlignedByteOffset(ofs){}
	zgstl::String SemanticName;
	UINT SemanticIndex;
	DXGI_FORMAT Format;
	UINT InputSlot;
    UINT AlignedByteOffset;
};

// ���b�V��
class MeshX11
{
public:
	MeshX11() : idxMat(-1){}
	~MeshX11(){}

	zgU32 idxMat;
	GeomX11Ptr pGeom;
private:
};

// �W�I���g��
class GeometryX11
{
public:
	GeometryX11() : nCount(0){}
	zgstl::Vector<InputDescX11>::T aInputDesc;
	zgstl::Vector<VertexBuffX11>::T aVBuff;
	IBuffPtr pIdxBuff;
	DXGI_FORMAT eIdxFormat;
	zgU32 nCount;
	D3D_PRIMITIVE_TOPOLOGY eTopo;
};

//----------------------------------
// �V�F�[�_�p�X�i�`��̍ŏ��P�ʁj
class ShaderPass
{
public:
	static const zgU32 VBUFF_MAXNUM = 8;
	static const zgU32 TEX_MAXNUM = 12;
	static const zgU32 CBUFF_MAXNUM = 8;//16;
	// �������Ȃ��̂ŌŒ�̔z��
	
	//���_�f�[�^
	zgU32 numVBuff;
	Array<UINT, VBUFF_MAXNUM>::Type aStride;
	Array<UINT, VBUFF_MAXNUM>::Type aOffset;
	Array<IBuffPtr, VBUFF_MAXNUM>::Type	apVBuff;	
	IBuffPtr	pIdxBuff;
	DXGI_FORMAT eIdxFormat;
	IILayoutPtr	pLayout;

	// ���
	IRsStatePtr pRsState;
	IBdStatePtr pBdState;
	IDsStatePtr pDsState;
	UINT uStencilRef;

	// �V�F�[�_
	IVShaderPtr	pVShader;
	IGShaderPtr pGShader;
	IPShaderPtr	pPShader;

	//�e�N�X�`��
	Array<ISRViewPtr, TEX_MAXNUM>::Type	apSRView;	
	Array<ISpStatePtr, TEX_MAXNUM>::Type apSpState;
	//�O���e�N�X�`��

	//�萔�o�b�t�@
	zgU32 numCBuff;
	Array<IBuffPtr, CBUFF_MAXNUM>::Type apCBuff;
	//�Ƃ肠�������_�ƃs�N�Z���Œ萔���L

	zgU32 nCount;
	D3D_PRIMITIVE_TOPOLOGY eTopo;
	ShaderPass() : numVBuff(0), uStencilRef(0), numCBuff(0), nCount(0)
					,eTopo(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST){}
};

//-------------------------------------------
// DX11�����_�����O���f���̍쐬
ModelX11Ptr CreateModelX11(zgmdl::Model& model);

//---------------------------
struct CinfoShaderPass
{
	CinfoShaderPass() : pGeom(0), pEffect(0), idxTech(0), idxPass(0), numCBuff(0){}

	// �`��
	GeometryX11* pGeom;

	// �V�F�[�_
	ShaderEffect* pEffect;
	zgU32 idxTech;
	zgU32 idxPass;

	// �e�N�X�`��
	//zgU32 numTex;
	Array<TextureX11,ShaderPass::TEX_MAXNUM>::Type aTex;
	
	// �萔�o�b�t�@�@apCBuff[n] -> register( bn )
	zgU32 numCBuff;
	Array<IBuffPtr, ShaderPass::CBUFF_MAXNUM>::Type apCBuff;
};

// ShaderPass�쐬
bool CreateShaderPass(const CinfoShaderPass& cinfo,  ShaderPass& pass);

bool RenderShaderPass(const IDevCtxPtr& dtvctx, ShaderPass& pass);




}//zix11 
