#include "stdafx.h"

#include "zg_dx11.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <directxmath.h>
#include "DirectXTex/DirectXTex.h"
#include "DirectXTK/SpriteFont.h"

#include "zg_mqo.h"
#include "zg_mmd.h"
#include "zg_model.h"

#include "zg_renctx11.h"
#include "zg_ptrx11.h"
#include "zg_mdlx11.h"
#include "zg_shdfx.h"

#include "zg_mmd_dx11.h"
#include "zg_dx11_utils.h"

#include "zg_smaa.h"

#include <fstream>
#include <string>
#include <stdlib.h>
#include <locale>


#include <boost/format.hpp>

#include "sample_data.h"

using namespace zix11;
using namespace DirectX;
using namespace mmdx11;

bool					g_InitDX11 = false;//2�d�������h�~
D3D_DRIVER_TYPE			g_DriverType = D3D_DRIVER_TYPE_NULL;
D3D_FEATURE_LEVEL		g_FeatureLevel = D3D_FEATURE_LEVEL_11_0;

RenContextX11 g_RenCtx;
RenContextX11& GetRenContext()
{
	return g_RenCtx;
}


namespace{

// �����_�����O
bool RenderRenList(RenListX11& ren_list);

// ���f���`��
zgstl::Vector<SPtr<MeshModel>::Type>::T g_aModel;

// �����_�����O���X�g
zgstl::Vector<RenListX11>::T g_RLGeometry;		//�W�I���g���o�b�t�@
zgstl::Vector<RenListX11>::T g_RLMain;			//���C�������_�����O
zgstl::Vector<RenListX11>::T g_OLineRenList;	//�֊s���`��
zgstl::Vector<RenListX11>::T g_ShadowRenList;	//�X�e���V���V���h�E

// �����v�Z�p�X�p�����_�����O
zgstl::Vector<ShaderPass>::T g_aLPPLight;	//�����v�Z�p�v���~�e�B�u�����_�����O

// �ŏI�摜�����i���ؗp4�����\���j
SPassPtr g_pOMergePass;

// SMAA
std::unique_ptr<SMAA> g_pSMAA;

//�X�v���C�g�t�H���g
std::unique_ptr<SpriteBatch> g_SpriteBatch;
std::unique_ptr<SpriteFont> g_SpriteFont;

//GPU�v��
std::unique_ptr<GPUPerformance> g_pGpuPerf;

// �����_�����O�^�[�Q�b�g
enum {
	RT_NORMAL		= 0,	// �@��
	RT_SPECULAR_POW	= 1,	// SpecularPow
	RT_DIFFUSE		= 2,	// Diffuse�����v�Z
	RT_SPECULAR		= 3,	// Specular�����v�Z
	RT_MAIN			= 4,	// ���C�������_�����O
	RT_SMAA_EDGE	= 5,	// SMAA�G�b�W
	RT_SMAA_BLEND	= 6,	// SMAA�u�����g
};

//MRT
struct MRTResource
{
	IRTViewPtr pRTView;	// RenderTargetView
	ITex2DPtr pTex2D;
	ISRViewPtr pSRView;	// �V�F�[�_���\�[�X
};

zgstl::Vector<MRTResource>::T g_aMRT;	//g_aMRT[RT_????]
IDSViewPtr g_pDSView;	// DepthStencil
IDSViewPtr g_pDSViewRO;	// ReadOnly Depth&Stencil
IDSViewPtr g_pDSViewROD;// ReadOnly Depth
ISRViewPtr g_pDSRView;	// �f�v�X�l�擾�p�V�F�[�_���\�[�X
ISRViewPtr g_pSSRView;	// �X�e���V���l�擾�p�V�F�[�_���\�[�X

//�����_�[�^�[�Q�b�g�쐬
bool CreateMRT();

// �_�����p�����[�^
struct CBPtLight
{
	CBPtLight(){}
	CBPtLight( XMVECTOR pos, XMVECTOR col, float rmin, float rmax, float rpow)
		: Pos(pos), Col(col)
	{
		setPrm(rmin, rmax, rpow);
	}
	static const zgU32 CBSLOT = SCBLocal::CBSLOT;//�X���b�g�ԍ�
	XMVECTOR Pos;
	XMVECTOR Col;
	XMVECTOR Prm;//���� = x*r^w + y, z=rmax

	void setPrm(float rmin, float rmax, float rpow)
	{
		const float rmin_n = powf(rmin, rpow);
		const float rmax_n = powf(rmax, rpow);
		Prm = XMVectorSet(-1.0f/(rmax_n-rmin_n), rmax_n/(rmax_n-rmin_n), rmax, rpow);
	}
};

// ������(�_�����̏W���Ƃ��Čv�Z�ː��l�ϕ��H�j
struct CBLnLight
{
	CBLnLight(){}
	CBLnLight( XMVECTOR p0, XMVECTOR p1, XMVECTOR col, float rmin, float rmax, float rpow)
		: Pos0(p0),  Pos1(p1), Col(col)
	{
		setPrm(rmin, rmax, rpow);
	}
	static const zgU32 CBSLOT = SCBLocal::CBSLOT;//�X���b�g�ԍ�

	XMVECTOR Pos0,Pos1;//����
	XMVECTOR Col;
	XMVECTOR Prm;//���� = x*r^w + y, z=rmax

	void setPrm(float rmin, float rmax, float rpow)
	{
		const float rmin_n = powf(rmin, rpow);
		const float rmax_n = powf(rmax, rpow);
		Prm = XMVectorSet(-1.0f/(rmax_n-rmin_n), rmax_n/(rmax_n-rmin_n), rmax, rpow);
	}
};

}

//---------------------------------------------------------
HRESULT InitDX11(HWND hWnd)
{
	if(g_InitDX11)return S_FALSE;//���łɏ�����
	
	HRESULT hr = S_OK;
	
	RECT rc;
	GetClientRect( hWnd, &rc );
	UINT width = rc.right - rc.left;
	UINT height = rc.bottom - rc.top;

	UINT cdev_flags = 0;
#ifdef _DEBUG
	cdev_flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
	RenContextX11& renctx =  GetRenContext();
	ResLibrary<SEffectPtr>& efflib = renctx.libEffect;//�V�F�[�_�G�t�F�N�g

	// DirectX11&�n�[�h�E�F�A�Ή��̂�
	D3D_FEATURE_LEVEL feature_level = D3D_FEATURE_LEVEL_11_0;
	g_DriverType = D3D_DRIVER_TYPE_HARDWARE;

	//�f�o�C�X�쐬
	hr = D3D11CreateDevice(	NULL, D3D_DRIVER_TYPE_HARDWARE,	NULL, cdev_flags,
							&feature_level, 1, D3D11_SDK_VERSION, GSET_DXPTR(renctx.pDev),
							&g_FeatureLevel, GSET_DXPTR(renctx.pImCtx) );
	if( FAILED( hr ) ){
		return hr;
	}
	
	// MSAA�Ȃ�
	DXGI_SAMPLE_DESC smpl_desc;
	smpl_desc.Count = 1;
	smpl_desc.Quality = 0;

	DXPtr<IDXGIDevice>::Type dxgi_dev;
	hr = renctx.pDev->QueryInterface(__uuidof(IDXGIDevice), (void**)GSET_DXPTR(dxgi_dev));
	if( FAILED( hr ) ){
		return hr;
	}
	DXPtr<IDXGIAdapter>::Type dxgi_adapter;
	hr = dxgi_dev->GetAdapter(GSET_DXPTR(dxgi_adapter));
	if( FAILED( hr ) ){
		return hr;
	}
	DXPtr<IDXGIFactory>::Type dxgi_factory;
	hr = dxgi_adapter->GetParent(__uuidof(IDXGIFactory), (void**)GSET_DXPTR(dxgi_factory));
	if( FAILED( hr ) ){
		return hr;
	}

	// �X���b�v�`�F�C���쐬
	DXGI_SWAP_CHAIN_DESC sd;
	ZeroMemory( &sd, sizeof( sd ) );
	sd.BufferCount = 1;
	sd.BufferDesc.Width = width;
	sd.BufferDesc.Height = height;
	sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	sd.BufferDesc.RefreshRate.Numerator = 60;
	sd.BufferDesc.RefreshRate.Denominator = 1;	//1/60 = 60fps
	sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	sd.OutputWindow = hWnd;
	sd.SampleDesc = smpl_desc;
	sd.Windowed = TRUE;
	hr = dxgi_factory->CreateSwapChain(renctx.pDev.get(), &sd, GSET_DXPTR(renctx.pSwapChain));
	if( FAILED( hr ) ){
		return hr;
	}

	renctx.uWidth = width;
	renctx.uHeight = height;

	// �X���b�v�`�F�C���ɗp�ӂ��ꂽ�o�b�t�@�i2D�e�N�X�`���j���擾
	ITex2DPtr back_buff;
	hr = renctx.pSwapChain->GetBuffer( 0, __uuidof( ID3D11Texture2D ), (LPVOID*)GSET_DXPTR(back_buff) );
	if( FAILED( hr ) ){
		return hr;
	}

	// �ŏI�o�͏ꏊ�i�E�C���h�E�ɔ��f�����j
	hr = renctx.pDev->CreateRenderTargetView( back_buff.get(), NULL, GSET_DXPTR(renctx.pRTView) );
	if( FAILED( hr ) ){
		return hr;
	}

	if( !CreateMRT() ){
		return E_FAIL;
	}

	g_pSMAA = std::unique_ptr<SMAA>(new SMAA(renctx.pDev,renctx.uWidth,renctx.uHeight));

	// viewport
	D3D11_VIEWPORT vp;
	vp.Width = (FLOAT)renctx.uWidth;
	vp.Height = (FLOAT)renctx.uHeight;
	vp.MinDepth = 0.0f;
	vp.MaxDepth = 1.0f;
	vp.TopLeftX = 0;
	vp.TopLeftY = 0;
	renctx.pImCtx->RSSetViewports( 1, &vp );

	D3D11_BUFFER_DESC bd;
	ZeroMemory( &bd, sizeof(bd) );
	// �萔�o�b�t�@�쐬
	bd.Usage = D3D11_USAGE_DEFAULT;
	bd.CPUAccessFlags = 0;
	bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	
	// �萔�o�b�t�@�@�V�[���p�����[�^
	bd.ByteWidth = sizeof(SCBScene);
	hr = renctx.pDev->CreateBuffer( &bd, NULL, GSET_DXPTR(renctx.pCBScene) );
	if( FAILED( hr ) ){
		return hr;
	}

	// �萔�o�b�t�@�@�����p�����[�^
	bd.ByteWidth = sizeof(SCBLight);
	hr = renctx.pDev->CreateBuffer( &bd, NULL, GSET_DXPTR(renctx.pCBLight) );
	if( FAILED( hr ) ){
		return hr;
	}

	// �����p�����[�^�̍X�V
	SCBLight& scblight = renctx.scbLight;
	ZeroMemory( &scblight, sizeof(scblight) );
	scblight.vDirLight[0] = XMVector3Normalize( XMVectorSet(0.5f,0.5f,-0.2f, 0) );
	scblight.colDirLight[0] = XMVectorSet(0.7f*0.5f,0.7f*0.5f,0.7f*0.5f,0);
	scblight.vHemiDir = XMVectorSet(0,1,0,0);
	scblight.colHemiSky = XMVectorSet(0.35f*0.5f,0.45f*0.5f,0.45f*0.5f,0.0f);
	scblight.colHemiGrd = XMVectorSet(0.45f*0.5f,0.45f*0.5f,0.45f*0.5f,0.0f);
	renctx.pImCtx->UpdateSubresource( renctx.pCBLight.get(), 0, NULL, &scblight, 0, 0 );

	// �t�H���g
	g_SpriteBatch = std::unique_ptr<SpriteBatch>(new SpriteBatch(renctx.pImCtx.get()));
	try {
		g_SpriteFont = std::unique_ptr<SpriteFont>(new SpriteFont(renctx.pDev.get(), ASCII_FONT_FILE));
	} catch(...){
		g_SpriteFont.reset();
	}
	if(g_SpriteFont)g_SpriteFont->SetDefaultCharacter(L'@');

	// GPU�v��
	g_pGpuPerf = std::unique_ptr<GPUPerformance>(new GPUPerformance);
	g_pGpuPerf->Create();

	{// �V�F�[�_
		const WCHAR* shader_file[] = {
			OUTLINE_BLEND_SHADER_FX_FILE,
			SHADOW_BLEND_SHADER_FX_FILE,
			SCREEN_FILL_SHADER_FX_FILE,
			LPP_BASIC_LIGHTING_FX_FILE,
			LPP_POINT_LIGHTING_FX_FILE,
			LPP_LINE_LIGHTING_FX_FILE,
			LPP_PMD_FX_FILE,
			LPP_PMX_FX_FILE,
			LPP_MQO_FX_FILE,
		};
		const char* shader_name[] = {
			"outline_b",
			"shadow_b",
			"screen_fill",
			"lpp_light",
			"lpp_ptlight",
			"lpp_lnlight",
			"lpp_pmd",
			"lpp_pmx",
			"lpp_mqo",
		};
		zgU32 cnt = 0;
		for(auto& file : shader_file){
			SEffectPtr seffect;
			//�V�K�쐬
			seffect = CreateShaderEffectFromFile(file);
			if(!seffect){
				MessageBox( NULL, L"�V�F�[�_�G�t�F�N�g�쐬���s", file, MB_OK );
			}else{
				// �ǉ�
				efflib.AddRes(shader_name[cnt], seffect);
			}
			cnt++;
		}
	}

	for(int i=0;i<2;++i){
		g_aModel.push_back(SPtr<MeshModel>::Type(new MeshModel));
	}

	{//�w�i���f��
		PMXModel pmx;
		if( CreatePMX(PMX_MODEL_FILE, pmx) ){
			zgmdl::Model model;
			CreateModel(pmx, model);
			g_aModel[0]->pModel = CreateModelX11(model);
			g_aModel[0]->v3Pos = ZGVECTOR3(0,0,0);
			g_aModel[0]->colModel = ZGVECTOR4(1,1,1,1);
			VMDMotion vmd;
			//���̃A�j���[�V���������@VMD�Đ���IK����
			CreateMeshModel(vmd, model, *g_aModel[0]);
		}else{
			MQOModel mqo;
			CreateMQOFromFile(L"data\\plane.mqo", mqo);
			zgmdl::ModelPtr zgmodel_mqo = CreateModel(mqo);
			g_aModel[0]->pModel = CreateModelX11(*zgmodel_mqo);
			g_aModel[0]->v3Pos = ZGVECTOR3(0,0,0);
			g_aModel[0]->colModel = ZGVECTOR4(1,1,1,1);
		}
	}
	if(1){//PMD���f��
		PMDModel pmd;
		VMDMotion vmd;
		bool load_pmd = CreatePMD(PMD_MODEL_FILE, pmd);
		bool load_vmd = CreateVMD(VMD_MOTION_FILE, vmd);
		if(!load_pmd || !load_vmd){
			MessageBox(NULL,  L"PMD�AVMD�t�@�C����������܂���B\nsample_data.h�Ƀt�@�C���p�X��ݒ肵�Ă��������B",L"",MB_OK);
		}

		zgmdl::ModelPtr zgmodel_pmd = CreateModel(pmd);
		g_aModel[1]->pModel = CreateModelX11(*zgmodel_pmd);
		g_aModel[1]->v3Pos = ZGVECTOR3(0,0,-3);
		g_aModel[1]->colModel = ZGVECTOR4(1,1,1,1);
		g_aModel[1]->aIK = pmd.aIK;
	
		//���̃A�j���[�V���������@VMD�Đ���IK����
		CreateMeshModel(vmd, *zgmodel_pmd, *g_aModel[1]);
	}

	D3D11_SAMPLER_DESC sampDesc;
	ZeroMemory( &sampDesc, sizeof(sampDesc) );
	sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
	sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
	sampDesc.MinLOD = 0;
	sampDesc.MaxLOD = D3D11_FLOAT32_MAX;
	ISpStatePtr spstate_depth;
	renctx.pDev->CreateSamplerState( &sampDesc, GSET_DXPTR(spstate_depth) );

	sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	ISpStatePtr spstate;
	renctx.pDev->CreateSamplerState( &sampDesc, GSET_DXPTR(spstate) );
	
	// �����_�����O���X�g�쐬
	for(auto& mdl : g_aModel){
		if(!mdl)continue;
		MeshModel& model = *mdl;
		if(!model.pModel)continue;

		//�e�N�j�b�N�w��@���O�Ō��������ɒ���index�w��
		const zgU32 GPASS_TECH_IDX = 0; 
		const zgU32 MAIN_TECH_IDX = 1; 

		{//�W�I���g���p�X
			RenListX11 ren_list;
			if( model.pModel->CreateRenList(0, GPASS_TECH_IDX, ren_list) ){
				g_RLGeometry.push_back(std::move(ren_list));
			}
		}
		{//���C���p�X
			RenListX11 ren_list;
			if( model.pModel->CreateRenList(0, MAIN_TECH_IDX, ren_list) ){

				// ���@�����v�Z���ʂ��V�F�[�_�ɓn��
				for(auto& rl : ren_list.aDList){
					if(!rl.pPass)continue;
					ShaderPass& pass = *rl.pPass;
				//	pass.numExtTex = 3;
					pass.apSRView[11] = g_aMRT[RT_DIFFUSE].pSRView;
					pass.apSpState[11] = spstate;
					pass.apSRView[10] = g_aMRT[RT_SPECULAR].pSRView;
					pass.apSpState[10] = spstate;
					pass.apSRView[9] = g_pSSRView;
					pass.apSpState[9] = spstate_depth;
				}

				g_RLMain.push_back(std::move(ren_list));
			}
			
		}
		if(0){//�֊s�� SMAA�Ƃ̑����������̂łƂ肠��������
			RenListX11 ren_list;
			if( model.pModel->CreateRenList(1, 0, ren_list) ){
				g_OLineRenList.push_back(std::move(ren_list));
			}
		}
		{//�V���h�E�{�����[��
			RenListX11 ren_list;
			if( model.pModel->CreateRenList(2, 0, ren_list) ){
				g_ShadowRenList.push_back(std::move(ren_list));
			}
		}
	}

	{// �����v�Z�p�v���~�e�B�u�`��
		// ���s�����Ɣ������C�g
		SEffectPtr seffect;
		if(efflib.getRes("lpp_light", seffect) ){
			ShaderPass spass;
			GeometryX11 geom;
			CreateSpriteGeom csgeom;
			csgeom.Create(geom);

			CinfoShaderPass ci_spass;
			ci_spass.pGeom = &geom;
			ci_spass.pEffect = seffect.get();
			ci_spass.idxTech = 0;
			ci_spass.idxPass = 0;

			ci_spass.aTex[0].pSpState = spstate_depth;
			ci_spass.aTex[0].pSRView = g_pDSRView;
			ci_spass.aTex[1].pSpState = spstate;
			ci_spass.aTex[1].pSRView = g_aMRT[RT_NORMAL].pSRView;
			ci_spass.aTex[2].pSpState = spstate;
			ci_spass.aTex[2].pSRView = g_aMRT[RT_SPECULAR_POW].pSRView;

			ci_spass.numCBuff = ci_spass.apCBuff.size();
			ci_spass.apCBuff[SCBScene::CBSLOT] = renctx.pCBScene;
			ci_spass.apCBuff[SCBLight::CBSLOT] = renctx.pCBLight;

			if( CreateShaderPass(ci_spass, spass) ){
				g_aLPPLight.push_back( std::move(spass) );
			}		
		}

		{//�_�����Ȃ�
			struct LightCInfo
			{
				const char* fx_name;
				IBuffPtr cbuff;
			};

			//��
			CBPtLight light0( XMVectorSet(24,18,0,0), XMVectorSet(0.5f,0.4f,0.4f,0), 10.0f, 80.0f, 1.0f);
			
			//�d��X�^���h
			CBPtLight light1( XMVectorSet(-1.5f,10,11,0), XMVectorSet(0.1f,0.6f,0.3f,0), 1.0f, 20.0f, 1.0f);

			//�u����
			CBLnLight light2(	XMVectorSet(2,24,26,0), XMVectorSet(14,24,26,0),
								XMVectorSet(0.3f,0.3f,1.4f,0),
								5.0f, 50.0f, 1.0f);

			CreateBuffer crbuff(D3D11_BIND_CONSTANT_BUFFER);
			LightCInfo cinfo[] = {
				{ "lpp_ptlight", crbuff.CreateObj(light0) },
				{ "lpp_ptlight", crbuff.CreateObj(light1) },
				{ "lpp_lnlight", crbuff.CreateObj(light2) },
			};

			GeometryX11 geom;
			//�_�����̉e���͈͂����������쐬(���a�P�A�ʒu�O)
			//�ʒu�Ɣ��a�͒��_�V�F�[�_�ŕϊ�
			//��ԋ߂��ʒu��1�ȏ�ɂȂ�悤�ɕ␳�i���p�`�̋ߎ��Ȃ̂Łj
			CreateSphereGeom csgeom(1.1f,10);//���m�ɂ͕���������␳�l������
			csgeom.Create(geom);

			for(auto& ci : cinfo){
				if( !efflib.getRes(ci.fx_name, seffect)
					|| seffect->aTech.size()==0 ){
					continue;
				}

				zgU32 ip = 0;
				for(auto& p : seffect->aTech[0].aPass){
					CinfoShaderPass ci_spass;
					ci_spass.pGeom = &geom;
					ci_spass.pEffect = seffect.get();
					ci_spass.idxTech = 0;
					ci_spass.idxPass = ip++;
					ci_spass.aTex[0].pSpState = spstate_depth;
					ci_spass.aTex[0].pSRView = g_pDSRView;
					ci_spass.aTex[1].pSpState = spstate;
					ci_spass.aTex[1].pSRView = g_aMRT[RT_NORMAL].pSRView;
					ci_spass.aTex[2].pSpState = spstate;
					ci_spass.aTex[2].pSRView = g_aMRT[RT_SPECULAR_POW].pSRView;

					ci_spass.numCBuff = ci_spass.apCBuff.size();
					ci_spass.apCBuff[SCBScene::CBSLOT] = renctx.pCBScene;
					ci_spass.apCBuff[SCBLight::CBSLOT] = renctx.pCBLight;
					ci_spass.apCBuff[CBPtLight::CBSLOT] = ci.cbuff;
					
					ShaderPass spass;
					if( CreateShaderPass(ci_spass, spass) ){
						g_aLPPLight.push_back( std::move(spass) );
					}
				}
			}			
		}

	}

	// ���ؗp���ʕ\��(���4����)
	g_pOMergePass = SPassPtr(new ShaderPass);
	if( g_pOMergePass ){
		SEffectPtr seffect;
		if( efflib.getRes("screen_fill", seffect) ){

			ShaderPass spass;
			CreateSpriteGeom csgeom;
			GeometryX11 geom;
			csgeom.Create(geom);

			CinfoShaderPass ci_spass;
			ci_spass.pGeom = &geom;
			ci_spass.pEffect = seffect.get();
			ci_spass.idxTech = 0;
			ci_spass.idxPass = 0;
			ci_spass.aTex[0].pSpState = spstate_depth;
			ci_spass.aTex[0].pSRView = g_pDSRView;
			ci_spass.aTex[1].pSpState = spstate_depth;
			ci_spass.aTex[1].pSRView = g_pSSRView;
			ci_spass.aTex[2].pSpState = spstate;
			ci_spass.aTex[2].pSRView = g_aMRT[RT_NORMAL].pSRView;
			ci_spass.aTex[3].pSpState = spstate;
			ci_spass.aTex[3].pSRView = g_aMRT[RT_SPECULAR_POW].pSRView;
			ci_spass.aTex[4].pSpState = spstate;
			ci_spass.aTex[4].pSRView = g_aMRT[RT_DIFFUSE].pSRView;
			ci_spass.aTex[5].pSpState = spstate;
			ci_spass.aTex[5].pSRView = g_aMRT[RT_SPECULAR].pSRView;
			ci_spass.aTex[6].pSpState = spstate;
			ci_spass.aTex[6].pSRView = g_aMRT[RT_MAIN].pSRView;
			ci_spass.numCBuff = 0;

			if( CreateShaderPass(ci_spass, spass) ){
				*g_pOMergePass = std::move(spass);
			}
		}
	}
#if 0//�Ƃ肠�����g���Ă݂�
#ifdef _DEBUG
	DXPtr<ID3D11InfoQueue>::Type info;
	if( FAILED( renctx.pDev->QueryInterface( __uuidof( ID3D11InfoQueue ), (void**)GSET_DXPTR(info)) ) ){
		info = nullptr;
	}
	if(info){
		D3D11_INFO_QUEUE_FILTER filter;
		D3D11_MESSAGE_ID msg[] = {
			D3D11_MESSAGE_ID_DEVICE_PSSETSHADERRESOURCES_HAZARD,
			D3D11_MESSAGE_ID_DEVICE_OMSETRENDERTARGETS_HAZARD,
		};
		ZeroMemory(&filter,sizeof(filter));
		filter.DenyList.NumIDs = _countof(msg);
		filter.DenyList.pIDList = msg;
		info->AddStorageFilterEntries(&filter);
		// ������const���Ȃ��@�ł������ŃR�s�[����Ă���݂���
	}
#endif//_DEBUG
#endif

	g_InitDX11 = true;
	return S_OK;
}

//---------------------------------------------------------
void ExitDX11()
{
	RenContextX11& renctx = GetRenContext();
	if( renctx.pImCtx ) renctx.pImCtx->ClearState();
	
	g_aModel.clear();
	g_RLGeometry.clear();
	g_RLMain.clear();
	g_OLineRenList.clear();
	g_ShadowRenList.clear();

	g_SpriteBatch.reset();
	g_SpriteFont.reset();

	g_pGpuPerf.reset();

	g_aLPPLight.clear();
	g_pOMergePass.reset();

	g_pSMAA.reset();

	g_aMRT.clear();
	g_pDSView.reset();
	g_pDSViewRO.reset();
	g_pDSViewROD.reset();
	g_pDSRView.reset();
	g_pSSRView.reset();

	g_RenCtx.Clear();

	if(!g_InitDX11)return;//���������ĂȂ�
	g_InitDX11 = false;
}

//---------------------------------------------------------
void RenderDX11()
{
 	RenContextX11& renctx = GetRenContext();
	ResLibrary<SEffectPtr>& efflib = renctx.libEffect;//�V�F�[�_�G�t�F�N�g

	static DWORD dwTimeStart = 0;
	DWORD dwTimeCur = GetTickCount();
	if( dwTimeStart == 0 ) dwTimeStart = dwTimeCur;

	float key_time = float( dwTimeCur - dwTimeStart ) / 33.333f;

	// �萔�o�b�t�@ �ϊ��s��i�v���W�F�N�V�����A�r���[�j�̍X�V
	SCBScene& scbscn =  renctx.scbScene;
	XMVECTOR Up = XMVectorSet( 0.0f, 1.0f, 0.0f, 0.0f );
	XMVECTOR Eye = XMVectorSet( -19.0f, 15.0f, -40.0f, 0.0f );
	XMVECTOR At = XMVectorSet( 0.0f, 10.0f, 0.0f, 0.0f );

	zgF32 NearZ = 0.5f;
	zgF32 FarZ = 500.0f;
	XMMATRIX mtx_proj = XMMatrixPerspectiveFovLH( XM_PIDIV4*1.0f, (FLOAT)renctx.uWidth / (FLOAT)renctx.uHeight, NearZ, FarZ );
	XMMATRIX mtx_view = XMMatrixLookAtLH( Eye, At, Up );
	scbscn.mtxView = XMMatrixTranspose(mtx_view);
	scbscn.mtxProj = XMMatrixTranspose(mtx_proj);
	scbscn.mtxInvView = XMMatrixTranspose( XMMatrixInverse(nullptr, mtx_view) );
	scbscn.vViewport = XMVectorSet((float)renctx.uWidth,(float)renctx.uHeight, 0, 1);
	renctx.pImCtx->UpdateSubresource( renctx.pCBScene.get(), 0, NULL, &scbscn, 0, 0 );


	XMMATRIX mmmm = XMMatrixIdentity();
	zgU32 mdl_cnt = 0;
	for(auto& mdl : g_aModel){
		if(!mdl)continue;
		MeshModel& model = *mdl;

		if(!model.pModel)continue;
		ModelX11& mdx11 = *model.pModel;

		//�{�[���s��X�V
		if( mdx11.numBoneMtx > 0 && model.numBone==mdx11.numBoneMtx ){

			// �A�j���[�V����
			VMDAnimation(key_time, model);

			// �A�j���[�V�����Ń��[�J���s�񂪕ύX���ꂽ�̂�
			// ���[���h�s����Čv�Z
			model.UpdatePose();

			// IK
			PMDIkAnimation(model);
		}

		// �{�[�������s��̍쐬�A�萔�o�b�t�@�ɓ]��
		if( mdx11.numBoneMtx > 0 && mdx11.pCBBoneMtx ){
			XMMATRIX* mtx_pose = reinterpret_cast<XMMATRIX*>(model.binMtxPose.get());
			XMMATRIX* mtx_init = reinterpret_cast<XMMATRIX*>(model.binMtxInitBone.get());
			MATRIX43* mtx_sub = reinterpret_cast<MATRIX43*>(model.binMtxSubBone.get());
			if( mtx_pose && mtx_init && mtx_sub){
				for(zgU32 ib=0;ib<mdx11.numBoneMtx;++ib){
					XMMATRIX mtx = XMMatrixMultiplyTranspose(
										XMMatrixInverse(nullptr,mtx_init[ib]),mtx_pose[ib]);
					mtx_sub[ib].r[0] = mtx.r[0];
					mtx_sub[ib].r[1] = mtx.r[1];
					mtx_sub[ib].r[2] = mtx.r[2];
				}
				if( model.binMtxSubBone.size() <= mdx11.sizeBoneMtx){
					renctx.pImCtx->UpdateSubresource( mdx11.pCBBoneMtx.get(), 0, NULL, model.binMtxSubBone.get(), 0, 0 );
				}
			}
		}

		// ���f���p�����[�^�X�V
		SCBModel sbc_model;
		sbc_model.colModel = XMVectorSet(model.colModel.x,model.colModel.y,model.colModel.z,model.colModel.w);
		sbc_model.mtxModel = XMMatrixTranspose( XMMatrixTranslation( model.v3Pos.x, model.v3Pos.y, model.v3Pos.z) );
		renctx.pImCtx->UpdateSubresource( mdx11.pCBModel.get(), 0, NULL, &sbc_model, 0, 0 );

		++mdl_cnt;
	}

	//�v���J�n
	g_pGpuPerf->Begin();
	
	float ClearColor[4] = { 0.2f, 0.4f, 0.8f, 1.0f }; //red,green,blue,alpha
	float ClearZero[4] = { 0,0,0,0 };

	{//Geometory : Normal & Specular Pow
		ID3D11RenderTargetView* rtvs[2];
		rtvs[0] = g_aMRT[RT_NORMAL].pRTView.get();
		rtvs[1] = g_aMRT[RT_SPECULAR_POW].pRTView.get();
		renctx.pImCtx->OMSetRenderTargets( 2, rtvs, g_pDSView.get() );

		renctx.pImCtx->ClearRenderTargetView( g_aMRT[0].pRTView.get(), ClearZero );//Normal
		renctx.pImCtx->ClearRenderTargetView( g_aMRT[1].pRTView.get(), ClearZero );//Specular Pow
		renctx.pImCtx->ClearDepthStencilView( g_pDSView.get(), D3D11_CLEAR_DEPTH|D3D11_CLEAR_STENCIL, 1.0f, 0 );
	
		for(auto& rl : g_RLGeometry){
			RenderRenList(rl);
		}
	}

	{//Lighting : Diffuse and Specular
		ID3D11RenderTargetView* rtvs[2];
		rtvs[0] = g_aMRT[RT_DIFFUSE].pRTView.get();
		rtvs[1] = g_aMRT[RT_SPECULAR].pRTView.get();
		renctx.pImCtx->OMSetRenderTargets( 2, rtvs, g_pDSViewROD.get() );

		// �ŏ��ɑS��ʂ̌����v�Z���s���ꍇ�N���A�s�v
	//	renctx.pImCtx->ClearRenderTargetView( g_aMRT[RT_DIFFUSE].pRTView.get(), ClearZero );//Diffuse
	//	renctx.pImCtx->ClearRenderTargetView( g_aMRT[RT_SPECULAR].pRTView.get(), ClearZero );//Specular
		// �f�v�X�o�b�t�@�̓N���A���Ȃ�

		// �����v�Z�p�v���~�e�B�u�`��
		for(auto& lt : g_aLPPLight){
			RenderShaderPass( renctx.pImCtx, lt );
		}
	}

	{//�X�e���V���V���h�E
		
		// �X�e���V���N���A
		renctx.pImCtx->ClearDepthStencilView( g_pDSView.get(), D3D11_CLEAR_STENCIL, 1.0f, 0 );

		renctx.pImCtx->OMSetRenderTargets( 0, nullptr, g_pDSView.get() );
		for(auto& rl : g_ShadowRenList){
			RenderRenList(rl);
		}
	}

	{//���C�������_�����O

		ID3D11RenderTargetView* rtvs[1];
		rtvs[0] = g_aMRT[RT_MAIN].pRTView.get();
		renctx.pImCtx->OMSetRenderTargets( 1, rtvs, g_pDSViewRO.get() );
		renctx.pImCtx->ClearRenderTargetView( g_aMRT[RT_MAIN].pRTView.get(), ClearColor );
		
		for(auto& rl : g_RLMain){
			RenderRenList(rl);
		}

		//�֊s��
		for(auto& rl : g_OLineRenList){
			RenderRenList(rl);
		}
	}

#if 1
	// AA���ʂ��ŏI�o�͂̃����_�[�^�[�Q�b�g�ցi�E�C���h�E�\���j
	if(g_pSMAA)g_pSMAA->Go(renctx.pImCtx, g_aMRT[RT_MAIN].pSRView, renctx.pRTView);

#else
	// AA�Ȃ�

	// �e�p�X�ŕ`�悵���摜�̍���
	do{
		SEffectPtr seffect;
		if( !efflib.getRes("screen_fill", seffect) )break;
		
		// �ŏI�o�͂̃����_�[�^�[�Q�b�g
		ID3D11RenderTargetView* const rtvs[] = {renctx.pRTView.get(),};
		renctx.pImCtx->OMSetRenderTargets( 1, rtvs, nullptr);
	
		if( g_pOMergePass ){
			RenderShaderPass(renctx.pImCtx, *g_pOMergePass );
		}
	
	}while(0);
#endif

	//�v���I��
	g_pGpuPerf->End();
	
	//���ԁA�p�t�H�[�}���X�v��
	D3D11_QUERY_DATA_PIPELINE_STATISTICS query_data;
	zgU64 occ_count = 0;
	g_pGpuPerf->Get(query_data);
	g_pGpuPerf->GetPixelWrite(occ_count);

	if(1){
		static LARGE_INTEGER last_count = {0};
		LARGE_INTEGER count;
		QueryPerformanceCounter(&count);
		if( last_count.QuadPart == 0 )last_count = count;
		zgS64 time = count.QuadPart - last_count.QuadPart;
		last_count = count;

		LARGE_INTEGER freq;
		QueryPerformanceFrequency(&freq);
		static float avg_time = 0;
		float t = float(double(time)/double(freq.QuadPart));
		avg_time += (t-avg_time)/10.0f;

		// ���Ԋu�ŕ\���X�V
		static float print_time = 1.0f;
		static float update_time = 0;
		static D3D11_QUERY_DATA_PIPELINE_STATISTICS print_query;
		static zgU64 print_occ_count;
		update_time += t;
		if( update_time > 0.3f){
			print_time = avg_time;
			print_query = query_data;
			print_occ_count = occ_count;
			update_time -= 0.3f;
		}

		if(g_SpriteFont){
			std::wstring str;
			str += (boost::wformat(L"FPS    = %1%\n") % (1.0f/print_time)).str();
			str += (boost::wformat(L"STL Mem= %1%kb(%2%)\n")
						% (zgstl::Debug_GetMallocSize()/1024)
						% (zgstl::Debug_GetMallocCount()) ).str();
			str += (boost::wformat(L"Vertex = %1%\n") % print_query.VSInvocations).str();
			str += (boost::wformat(L"Prim   = %1%\n") % print_query.CPrimitives).str();
			str += (boost::wformat(L"PShader= %1%\n") % print_query.PSInvocations).str();
			str += (boost::wformat(L"PWrite = %1%\n") % print_occ_count).str();
		
			// �ŏI�o�͂̃����_�[�^�[�Q�b�g
			ID3D11RenderTargetView* const rtvs[] = {renctx.pRTView.get(),};
			renctx.pImCtx->OMSetRenderTargets( 1, rtvs, nullptr);
			g_SpriteBatch->Begin();
			g_SpriteFont->DrawString(g_SpriteBatch.get(), str.c_str(), XMVectorSet(0,0,0,0));
			g_SpriteBatch->End();
		}
	}
	//���ʂ��E�C���h�E�ɔ��f
    renctx.pSwapChain->Present( 0, 0 );
}

namespace{
//-----------------------------
bool CreateMRT()
{
	RenContextX11& renctx =  GetRenContext();
	HRESULT hr;

	zgU32 width = 640;
	zgU32 height = 480;

	DXGI_SAMPLE_DESC smpl_desc;
	smpl_desc.Count = 1;
	smpl_desc.Quality = 0;

	D3D11_TEXTURE2D_DESC tex_desc;
	ZeroMemory( &tex_desc, sizeof(tex_desc) );
	tex_desc.Width = width;
	tex_desc.Height = height;
	tex_desc.MipLevels = 1;
	tex_desc.ArraySize = 1;
	tex_desc.SampleDesc = smpl_desc;
	tex_desc.Usage = D3D11_USAGE_DEFAULT;
	tex_desc.CPUAccessFlags = 0;
	tex_desc.MiscFlags = 0;


	D3D11_TEXTURE2D_DESC mrt_desc[5] = {tex_desc, tex_desc, tex_desc, tex_desc, tex_desc,};
	D3D11_TEXTURE2D_DESC depth_desc[1] = {tex_desc};
	// Pass0
	{// �f�v�X
		D3D11_TEXTURE2D_DESC& dep_decs = depth_desc[0];
		dep_decs.Format = DXGI_FORMAT_R24G8_TYPELESS;
		dep_decs.BindFlags = D3D11_BIND_DEPTH_STENCIL | D3D11_BIND_SHADER_RESOURCE;
	}
	{// �@���o�b�t�@
		D3D11_TEXTURE2D_DESC& nor_decs = mrt_desc[0];
		nor_decs.Format = DXGI_FORMAT_R11G11B10_FLOAT;
		nor_decs.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	}
	{// SpecularPow,-,-,-
		D3D11_TEXTURE2D_DESC& nor_decs = mrt_desc[1];
		nor_decs.Format = DXGI_FORMAT_R8_UNORM;
		nor_decs.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	}

	// Pass1
	{// Diffuse
		D3D11_TEXTURE2D_DESC& nor_decs = mrt_desc[2];
		nor_decs.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
		nor_decs.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	}
	{// Specular
		D3D11_TEXTURE2D_DESC& nor_decs = mrt_desc[3];
		nor_decs.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
		nor_decs.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	}

	// Pass2
	{// ���C�������_�����O
		DXGI_SAMPLE_DESC smpl_desc;
		smpl_desc.Count = 1;
		smpl_desc.Quality = 0;

		D3D11_TEXTURE2D_DESC& main_decs = mrt_desc[4];
		main_decs.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
		main_decs.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
		main_decs.SampleDesc = smpl_desc;
		
	}

	zgstl::Vector<MRTResource>::T mrtres;
	IDSViewPtr dsview,dsview_ro,dsview_rod;
	ISRViewPtr dsrview, ssrview;

	{
		auto& desc = depth_desc[0];
		ITex2DPtr tex;
		IRTViewPtr rtview;
		hr = renctx.pDev->CreateTexture2D( &desc, NULL, GSET_DXPTR(tex) );
		if( FAILED( hr ) ){ 
			return false;
		}
		// �f�v�X�o�b�t�@
		D3D11_DEPTH_STENCIL_VIEW_DESC dsv_desc;
		ZeroMemory( &dsv_desc, sizeof(dsv_desc) );
		dsv_desc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
		dsv_desc.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
		dsv_desc.Flags = 0;

		hr = renctx.pDev->CreateDepthStencilView( tex.get(), &dsv_desc, GSET_DXPTR(dsview) );
		if( FAILED( hr ) ){
			return false;
		}
		// �f�v�X�o�b�t�@�iRead Only)
		dsv_desc.Flags = D3D11_DSV_READ_ONLY_DEPTH|D3D11_DSV_READ_ONLY_STENCIL;
		hr = renctx.pDev->CreateDepthStencilView( tex.get(), &dsv_desc, GSET_DXPTR(dsview_ro) );
		if( FAILED( hr ) ){
			return false;
		}
		dsv_desc.Flags = D3D11_DSV_READ_ONLY_DEPTH;
		hr = renctx.pDev->CreateDepthStencilView( tex.get(), &dsv_desc, GSET_DXPTR(dsview_rod) );
		if( FAILED( hr ) ){
			return false;
		}
			

		// �f�v�X�l���V�F�[�_����
		D3D11_SHADER_RESOURCE_VIEW_DESC srv_desc;
		ZeroMemory( &srv_desc, sizeof(srv_desc) );
		srv_desc.Format = DXGI_FORMAT_R24_UNORM_X8_TYPELESS;
		srv_desc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
		srv_desc.Texture2D.MipLevels = 1;
		srv_desc.Texture2D.MostDetailedMip = 0;
		hr = renctx.pDev->CreateShaderResourceView( tex.get(), &srv_desc, GSET_DXPTR(dsrview) );
		if( FAILED( hr ) ){
			return false;
		}

		// �X�e���V���l���V�F�[�_����
		srv_desc.Format = DXGI_FORMAT_X24_TYPELESS_G8_UINT;
		srv_desc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
		hr = renctx.pDev->CreateShaderResourceView( tex.get(), &srv_desc, GSET_DXPTR(ssrview) );
		if( FAILED( hr ) ){
			return false;
		}
	}

	for(auto& d : mrt_desc){
		MRTResource mrt;
		IRTViewPtr rtview;
		hr = renctx.pDev->CreateTexture2D( &d, NULL, GSET_DXPTR(mrt.pTex2D) );
		if( FAILED( hr ) ){ 
			return false;
		}

		hr = renctx.pDev->CreateRenderTargetView( mrt.pTex2D.get(), nullptr, GSET_DXPTR(mrt.pRTView) );
		if( FAILED( hr ) ){
			return false;
		}
		if( d.BindFlags & D3D11_BIND_SHADER_RESOURCE ){
			hr = renctx.pDev->CreateShaderResourceView( mrt.pTex2D.get(), nullptr, GSET_DXPTR(mrt.pSRView) );
			if( FAILED( hr ) ){
				return false;
			}
		}

		mrtres.push_back(mrt);
	}
	
	g_pDSView = std::move(dsview);
	g_pDSViewRO = std::move(dsview_ro);
	g_pDSViewROD = std::move(dsview_rod);
	g_pDSRView = std::move(dsrview);
	g_pSSRView = std::move(ssrview);
	g_aMRT = std::move(mrtres);
	
	return true;
}

//---------------------------------------------------
bool RenderRenList(RenListX11& ren_list)
{
	RenContextX11& renctx =  GetRenContext();

	for(auto& ren : ren_list.aDList){
		RenderShaderPass( renctx.pImCtx, *ren.pPass );
	}
	return true;
}

}//ns
