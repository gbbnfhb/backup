#pragma once

#include <string>
#include "zg_types.h"
#include "zg_stl.h"

//-----------------------------
struct MQOMaterial
{
	zgstl::String strName;
	zgstl::String strTexName;
	ZGVECTOR4 v4Col;
	ZGVECTOR4 v4Spec;//w=pow
};

//-----------------------------
struct MQOFace
{
	// �O�p�`�|���S���̂� 
	zgU32 idxMat;
	zgU32 aVidx[3];
	ZGVECTOR2 aUV[3];

	// ���_���琶��
	ZGVECTOR3 aNor[3];
};

//-----------------------------
struct MQOObject
{
	MQOObject() : radFacet(1.03847f){}//59.5��
	zgstl::String strName;
	zgstl::Vector<ZGVECTOR3>::T aVertex;
	zgstl::Vector<MQOFace>::T aFace;

	zgF32 radFacet;//�@���X���[�W���O�p�x�irad)
};

//----------------------------------
struct MQOModel
{
	zgstl::Vector<MQOMaterial>::T aMaterial;
	zgstl::Vector<MQOObject>::T aObject;
};

//----------------------------------
// mqo�t�@�C������MQOModel�쐬
bool CreateMQO(const char* data, size_t size, MQOModel& mqo);

//--------------------------------------------
bool CreateMQOFromFile(const WCHAR* file, MQOModel& mqo);

// �@�����v�Z�ŋ��߂�
bool ComputeNormal(MQOModel& mqo);



