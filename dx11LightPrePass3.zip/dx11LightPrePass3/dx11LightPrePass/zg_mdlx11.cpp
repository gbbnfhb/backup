#include "stdafx.h"

#include "zg_mdlx11.h"
#include "zg_renctx11.h"
#include "zg_shdfx.h"

#include <d3d11.h>
#include <d3dcompiler.h>
#include <directxmath.h>
#include "DirectXTex/DirectXTex.h"

#include <stdlib.h>
#include <locale>
#include <fstream>

#include "sample_data.h"


using namespace DirectX;

zix11::RenContextX11& GetRenContext();
namespace zix11{

namespace{
XMVECTOR ToXMVec(const ZGVECTOR4& v)
{
	return XMLoadFloat4(reinterpret_cast<const XMFLOAT4*>(&v));
}

//���_�f�[�^�\����
struct VertexData
{
	XMFLOAT3 pos;
	XMFLOAT3 nor;
	XMFLOAT2 tex;
};
struct BoneWeight
{
	zgU16 idx[4];
	zgU8 weight[4];//0~100%
};

//-----------------------
// string->wstring�ϊ�
bool to_wstring(const zgstl::String& str, std::wstring& wstr)
{
	 size_t size;
	 if( 0!= mbstowcs_s(&size, NULL, 0, str.c_str(), 0) ){
		 return false;
	 }
	 std::vector<wchar_t> wch(size);
	 if( 0!= mbstowcs_s(&size, wch.data(), wch.size(), str.c_str(), str.length()) ){
		return false;
	 }
	 wstr = wch.data();
	 return true;
}

//-----------------------
// ���̓��C�A�E�g�`�F�b�N
// ���_�V�F�[�_���v�����Ă�����̓p�����[�^����`����Ă��邩
// shader_code,code_size �V�F�[�_���R���p�C�������o�C�g�R�[�h
bool CheckInputLayout(const void* shader_code, size_t code_size,
					  const D3D11_INPUT_ELEMENT_DESC* layout, size_t layout_num)
{
	DXPtr<ID3D11ShaderReflection>::Type vs_ref; 
	HRESULT hr = D3DReflect( shader_code,code_size,
				IID_ID3D11ShaderReflection, (void**)GSET_DXPTR(vs_ref));
	// dxguid.lib�̃����N���K�v
	if( FAILED( hr ) )return false;

	// �V�F�[�_���擾
	D3D11_SHADER_DESC shd_desc;
	hr = vs_ref->GetDesc(&shd_desc);
	if( FAILED( hr ) ){
		return false;
	}

	ID3D11ShaderReflectionConstantBuffer* cbuff = vs_ref->GetConstantBufferByName("CB7");
	if(cbuff){
		D3D11_SHADER_BUFFER_DESC cb_desc;
		hr = cbuff->GetDesc(&cb_desc);
		if( SUCCEEDED( hr ) ){
			for(UINT v=0;v<cb_desc.Variables;++v){
				D3D11_SHADER_VARIABLE_DESC vdesc;
				ID3D11ShaderReflectionVariable* var = cbuff->GetVariableByIndex(v);
				if( SUCCEEDED( var->GetDesc(&vdesc) )){
					var = var;
				}
			}
		}

	}

	for(UINT ip=0;ip<shd_desc.InputParameters;++ip){
		D3D11_SIGNATURE_PARAMETER_DESC desc;
		hr = vs_ref->GetInputParameterDesc(ip, &desc);
		if( FAILED( hr ) ){
			return false;
		}
		
		//���̓��C�A�E�g�ɕK�v�ȃZ�}���e�B�N�����Ȃ���Η��p�s��
		UINT il=0;
		for(il=0;il<layout_num;++il){
			if( strcmp(layout[il].SemanticName, desc.SemanticName) == 0){
				break;
			}
		}
		if( il==layout_num){
			return false;//������Ȃ�
		}
	}
	return true;

}

bool CheckInputResource(const void* shader_code, size_t code_size)
{
	DXPtr<ID3D11ShaderReflection>::Type vs_ref; 
	HRESULT hr = D3DReflect( shader_code,code_size,
				IID_ID3D11ShaderReflection, (void**)GSET_DXPTR(vs_ref));
	if( FAILED( hr ) )return false;

	// �V�F�[�_���擾
	D3D11_SHADER_DESC shd_desc;
	hr = vs_ref->GetDesc(&shd_desc);
	if( FAILED( hr ) ){
		return false;
	}
	
	for(UINT ir=0;ir<shd_desc.BoundResources;++ir){
		D3D11_SHADER_INPUT_BIND_DESC desc;
		vs_ref->GetResourceBindingDesc(ir, &desc);
		int a=0;
	}

	return true;
}
//-----------------------
ISRViewPtr LoadTexture(const zgstl::String& texname)
{
	// ���\�[�X���C�u����
	RenContextX11& renctx = GetRenContext();
	ResLibrary<ISRViewPtr>& texlib = renctx.libTexImage;//�e�N�X�`���摜
	ISRViewPtr ret;
	if( texlib.getRes(texname, ret) )return ret;

	//�V�K�쐬
	std::wstring wstr;
	to_wstring(texname, wstr);
	wstr = std::wstring(TEXTURE_FOLDER_PATH) + wstr;

	HRESULT hr;
	TexMetadata metadata;
	DirectX::ScratchImage image;
	if( std::wstring::npos != wstr.rfind(L".tga") ){
		hr = LoadFromTGAFile(wstr.c_str(), &metadata, image);
	}else{
		hr = LoadFromWICFile(wstr.c_str(), 0, &metadata, image);
	}
	if( FAILED(hr) ){
		return ret;
	}
	if( SUCCEEDED( hr ) ){
		CreateShaderResourceView(renctx.pDev.get(),
					image.GetImages(), image.GetImageCount(),
					metadata, GSET_DXPTR(ret));
	}
					
	// �ǉ�
	texlib.AddRes(texname, ret);
	return ret;
}

//-----------------------
DXGI_FORMAT get_format( const zgmdl::Vertex& vertex)
{
	switch(vertex.getFormat()){
	case zgmdl::Vertex::FMT_F32:
		switch(vertex.getElemNum()){
		case 1:return DXGI_FORMAT_R32_FLOAT;
		case 2:return DXGI_FORMAT_R32G32_FLOAT;
		case 3:return DXGI_FORMAT_R32G32B32_FLOAT;
		case 4:return DXGI_FORMAT_R32G32B32A32_FLOAT;
		default:return DXGI_FORMAT_UNKNOWN;
		}
		break;
	case zgmdl::Vertex::FMT_U32:
		switch(vertex.getElemNum()){
		case 1:return DXGI_FORMAT_R32_UINT;
		case 2:return DXGI_FORMAT_R32G32_UINT;
		case 3:return DXGI_FORMAT_R32G32B32_UINT;
		case 4:return DXGI_FORMAT_R32G32B32A32_UINT;
		default:return DXGI_FORMAT_UNKNOWN;
		}
		break;
	case zgmdl::Vertex::FMT_U16:
		switch(vertex.getElemNum()){
		case 1:return DXGI_FORMAT_R16_UINT;
		case 2:return DXGI_FORMAT_R16G16_UINT;
		case 3:return DXGI_FORMAT_UNKNOWN;
		case 4:return DXGI_FORMAT_R16G16B16A16_UINT;
		default:return DXGI_FORMAT_UNKNOWN;
		}
		break;
	case zgmdl::Vertex::FMT_U8:
		switch(vertex.getElemNum()){
		case 1:return DXGI_FORMAT_R8_UINT;
		case 2:return DXGI_FORMAT_R8G8_UINT;
		case 3:return DXGI_FORMAT_UNKNOWN;
		case 4:return DXGI_FORMAT_R8G8B8A8_UINT;
		default:return DXGI_FORMAT_UNKNOWN;
		}
		break;
	default:
		return DXGI_FORMAT_UNKNOWN;
	}
}


}//ns


//-----------------------
// DX11�����_�����O���f���̍쐬
ModelX11Ptr CreateModelX11(zgmdl::Model& model)
{
	HRESULT hr;
	RenContextX11& renctx = GetRenContext();
	
	// ���\�[�X���C�u����
	ResLibrary<ISRViewPtr>& texlib = renctx.libTexImage;//�e�N�X�`���摜
	ResLibrary<SEffectPtr>& efflib = renctx.libEffect;//�V�F�[�_�G�t�F�N�g

	// SamplerState�쐬
    D3D11_SAMPLER_DESC sampDesc;
    ZeroMemory( &sampDesc, sizeof(sampDesc) );
    sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
    sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
    sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
    sampDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
    sampDesc.MinLOD = 0;
    sampDesc.MaxLOD = D3D11_FLOAT32_MAX;
	ISpStatePtr spstate;
    hr = renctx.pDev->CreateSamplerState( &sampDesc, GSET_DXPTR(spstate) );
	if( FAILED( hr ) ){
		return ModelX11Ptr();
	}

	ModelX11Ptr mdx11(new ModelX11);
	if(!mdx11)return mdx11;

	// �萔�o�b�t�@�쐬�p��`
	D3D11_SUBRESOURCE_DATA cb_inidat;
	D3D11_BUFFER_DESC cb_bd;
	ZeroMemory( &cb_inidat, sizeof(cb_inidat) );
	ZeroMemory( &cb_bd, sizeof(cb_bd) );
	// �萔�o�b�t�@�쐬
	cb_bd.Usage = D3D11_USAGE_DEFAULT;
	cb_bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	cb_bd.CPUAccessFlags = 0;

	SCBModel scb_model;
	scb_model.colModel = XMVectorSet(1,1,1,1);
	scb_model.mtxModel = XMMatrixIdentity();
	cb_bd.ByteWidth = sizeof(SCBModel);
	cb_inidat.pSysMem = &scb_model;
	hr = renctx.pDev->CreateBuffer( &cb_bd, &cb_inidat, GSET_DXPTR(mdx11->pCBModel) );
	if( FAILED( hr ) ){ return ModelX11Ptr(); }

	// �{�[���s��
	if( model.BoneNum() > 0 ){
		cb_bd.ByteWidth = SCBBoneMatrix::getSize(model.BoneNum());
		hr = renctx.pDev->CreateBuffer( &cb_bd, NULL, GSET_DXPTR(mdx11->pCBBoneMtx) );
		if( FAILED( hr ) ){ return ModelX11Ptr(); }
		mdx11->numBoneMtx = model.BoneNum();
		mdx11->sizeBoneMtx = cb_bd.ByteWidth;
	}

	// �}�e���A��
	zgU32 mat_num = model.MatNum();
	mdx11->apMat.resize(mat_num);
	for(zgU32 im=0;im<mat_num;++im){
		zgmdl::Material* mat = model.getMat(im);
		if(!mat)continue;
		MatX11Ptr mat11(new MaterialX11);
		if(!mat11)continue;

		mat11->vDiffuse = mat->v4Diff;
		mat11->vSpecular = mat->v4Spec;

		// �}�e���A���萔�o�b�t�@
		SCBMaterial scb_mat;
		scb_mat.vDiffuse = ToXMVec(mat11->vDiffuse);
		scb_mat.vSpecular = ToXMVec(mat11->vSpecular);

		cb_inidat.pSysMem = &scb_mat;
		cb_bd.ByteWidth = sizeof(scb_mat);
		hr = renctx.pDev->CreateBuffer( &cb_bd, &cb_inidat, GSET_DXPTR(mat11->pCBMateiral) );
		if( FAILED( hr ) ){ return ModelX11Ptr(); }

		// �V�F�[�_�G�t�F�N�g
		{
			//��
			const char* shader_name = "basic";
			if( mat && mat->strShader != "" ){
				shader_name = mat->strShader.c_str();
			}else{
				if(model.BoneNum() > 0){
					//�{�[������
					shader_name = "basic_b";
				}
				if( mat && mat->strShader == "outline_b"){
					shader_name = "outline_b";
				}
				if( mat && mat->strShader == "shadow_b"){
					shader_name = "shadow_b";
				}
			}
			if( !efflib.getRes(shader_name, mat11->pEffect) ){
				return ModelX11Ptr();
			}
		}

		// �e�N�X�`���摜
		if(!mat || mat->numTex == 0){
			TextureX11 tex;
			tex.pSRView = LoadTexture("notex.png");
			tex.pSpState = spstate;
			mat11->aTex.push_back( std::move(tex) );
		}else{
			for(zgU32 it=0;it<mat->numTex;++it){
				TextureX11 tex;
				tex.pSpState = spstate;
				tex.pSRView = LoadTexture(mat->aTex[it].strTex);
				if(!tex.pSRView)tex.pSRView = LoadTexture("notex.png");
				mat11->aTex.push_back( std::move(tex) );
			}
		}

		mdx11->apMat[im] = mat11;
	}

	for(zgU32 o=0;o< model.ObjNum();++o){
		zgmdl::Object* obj = model.getObj(o);
		if(!obj)return ModelX11Ptr();

		ModelObjX11Ptr mox11(new ModelObjectX11);
		if(!mox11)return ModelX11Ptr();
		mdx11->apObj.push_back(mox11);
		
		//�I�u�W�F�N�g�p�����[�^�萔�o�b�t�@
		SCBObject scb_object;
		scb_object.mtxWorld = XMMatrixIdentity();//�{���̓��f���f�[�^����擾�A�f�[�^���Ȃ��̂ŒP�ʍs��
		cb_bd.ByteWidth = sizeof(scb_object);
		cb_inidat.pSysMem = &scb_object;
		hr = renctx.pDev->CreateBuffer( &cb_bd, &cb_inidat, GSET_DXPTR(mox11->pCBObject) );
		if( FAILED( hr ) ){ return ModelX11Ptr(); }

		for(zgU32 im=0;im<obj->MeshNum();++im){
			zgmdl::Mesh* mesh = obj->getMesh(im);
			if(!mesh)continue;

			//���b�V���쐬
			MeshX11Ptr mesh11(new MeshX11);
			if(!mesh11)return ModelX11Ptr();

			zgU32 midx = mesh->getMatIdx();
			zgmdl::Material* mat = model.getMat(midx);

			MatX11Ptr mat11;
			if( midx < mdx11->apMat.size() ){
				mat11 = mdx11->apMat[midx];
			}else{
				return ModelX11Ptr();
			}

			mesh11->idxMat = midx;

			mesh11->pGeom = GeomX11Ptr(new GeometryX11);
			if( !mesh11->pGeom )return ModelX11Ptr();

			{//�W�I���g���쐬
				using zgmdl::VertexDecl;
				using zgmdl::Vertex;
				IBuffPtr vertbuff;
				IBuffPtr bwgtbuff;
				IBuffPtr idxbuff;
				zgU32 stride = 0;
				zgU32 bwgt_stride = 0;
				size_t count = 0;

				struct STREAM
				{
					zgU32 uStream;
					zgU32 uStride;
					zgU32 uOffset;
					zgU32 nVertex;
					std::vector<const VertexDecl*> aDecl;
				};

				zgU32 stm_no = 0;
				zgU32 decl_num = mesh->DeclNum();
				if( decl_num == 0){
					return ModelX11Ptr();
				}

				// �X�g���[���ԍ��ŕ���
				std::vector<STREAM> stream;
				for(zgU32 i=0;i<decl_num;++i){
					const VertexDecl* d = mesh->getDecl(i);
					const Vertex* v = mesh->getVertex(d->uSlot);
					if(!d || !v)continue;
					bool found = false;

					for(auto& s : stream){
						// �����X�g���[���ԍ�
						if(s.uStream == d->uStream){
							s.aDecl.push_back(d);
							s.uStride += v->getStride();
							found = true;
							break;
						}
					}
					// ������Ȃ��@�V�K�ǉ�
					if(!found){
						STREAM stm;
						stm.nVertex = v->getNum();
						stm.uStream = stm_no++;
						stm.uOffset = 0;
						stm.uStride = v->getStride();
						stm.aDecl.push_back(d);
						stream.push_back(std::move(stm));
					}
				}

				// �X�g���[���ԍ����Ƃɒ��_�o�b�t�@�쐬
				for(auto& stm : stream){
					std::vector<zgU8> buff(stm.nVertex*stm.uStride);
					zgU32 ptr = 0;

					// ���_�錾
					zgU32 stride = 0;
					for(auto& d : stm.aDecl){
						const Vertex* v = mesh->getVertex(d->uSlot);
						if(!v)return ModelX11Ptr();
						InputDescX11 desc;
						desc.SemanticName = d->strSema;
						desc.SemanticIndex = 0;
						desc.Format = get_format(*v);
						desc.InputSlot = stm.uStream;
						desc.AlignedByteOffset = stride;
						stride += v->getStride();

						mesh11->pGeom->aInputDesc.push_back(desc);
					}

					for(zgU32 i=0;i<stm.nVertex;++i){
						zgU32 stride = 0;
						for(auto& d : stm.aDecl){
							const Vertex* v = mesh->getVertex(d->uSlot);
							if(!v)return ModelX11Ptr();
							void* data = &buff[ptr + stride];
							v->getRaw(i, data, v->getStride());
							stride += v->getStride();
						}
						ptr += stm.uStride;
					}

					//���_�o�b�t�@�쐬
					IBuffPtr vbuff;
					D3D11_BUFFER_DESC bd;
					ZeroMemory( &bd, sizeof(bd) );
					bd.Usage = D3D11_USAGE_DEFAULT;
					bd.ByteWidth = stm.nVertex*stm.uStride;
					bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
					bd.CPUAccessFlags = 0;

					D3D11_SUBRESOURCE_DATA inidat;
					ZeroMemory( &inidat, sizeof(inidat) );
					inidat.pSysMem = buff.data();
					hr = renctx.pDev->CreateBuffer( &bd, &inidat, GSET_DXPTR(vbuff) );
					if( FAILED( hr ) ){ return ModelX11Ptr(); }

					mesh11->pGeom->aVBuff.push_back( VertexBuffX11(vbuff, stm.uStride, stm.uOffset) );

				}

				// �C���f�b�N�X�o�b�t�@
				zgmdl::Vertex& idx = mesh->getIndex();
				std::vector<zgU16> index;
				index.reserve(idx.getNum());
				for(zgU32 ii=0;ii<idx.getNum();++ii){
					zgU32 i=0;
					idx.getData(ii,i);
					index.push_back(static_cast<zgU16>(i));
				}

				count = index.size();

				D3D11_BUFFER_DESC bd;
				ZeroMemory( &bd, sizeof(bd) );
				bd.Usage = D3D11_USAGE_DEFAULT;
				bd.BindFlags = D3D11_BIND_INDEX_BUFFER;
				bd.CPUAccessFlags = 0;
				bd.Usage = D3D11_USAGE_DEFAULT;
				bd.ByteWidth = sizeof( zgU16 ) * count;

				D3D11_SUBRESOURCE_DATA inidat;
				ZeroMemory( &inidat, sizeof(inidat) );
				inidat.pSysMem = index.data();
				hr = renctx.pDev->CreateBuffer( &bd, &inidat, GSET_DXPTR(idxbuff) );
				if( FAILED( hr ) ){
					return ModelX11Ptr();
				}

				mesh11->pGeom->pIdxBuff = idxbuff;
				mesh11->pGeom->eIdxFormat = DXGI_FORMAT_R16_UINT;
				mesh11->pGeom->nCount = count;

				switch(mesh->getPrim()){
				case zgmdl::Mesh::PRIM_LINELIST:
					mesh11->pGeom->eTopo = D3D11_PRIMITIVE_TOPOLOGY_LINELIST;
					break;
				case zgmdl::Mesh::PRIM_LINELIST_ADJ:
					mesh11->pGeom->eTopo = D3D11_PRIMITIVE_TOPOLOGY_LINELIST_ADJ;
					break;
				case zgmdl::Mesh::PRIM_TRILIST_ADJ:
					mesh11->pGeom->eTopo = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST_ADJ;
					break;
				case zgmdl::Mesh::PRIM_TRILIST:
				default:
					mesh11->pGeom->eTopo = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
					break;
				}

			}//�W�I���g���쐬

			mox11->apMesh.push_back(mesh11);
		}
	}

	mdx11->aInst = model.aInst;

	return mdx11;
}

//---------------------------------
zgU32 ModelX11::CreateRenList(zgU32 ren_idx, zgU32 tech_idx, RenListX11& renlist)
{
	if(ren_idx >= aInst.size())return 0;
	RenContextX11& renctx = GetRenContext();

	RenListX11 tmp;

	auto& ilist = aInst[ren_idx];
	for(auto& inst : ilist.aElem){
		if(inst.idxObj >= apObj.size())continue;
		auto& obj = apObj[inst.idxObj];
		if(!obj || inst.idxMesh >= obj->apMesh.size())continue;
		auto& mesh = obj->apMesh[inst.idxMesh];
		if(!mesh || mesh->idxMat >= this->apMat.size())continue;
		auto& mat = this->apMat[mesh->idxMat];
		if( !mat )continue;
		auto& geom = mesh->pGeom;
		if( !geom )continue;

		SEffectPtr seffect = mat->pEffect;
		if(!seffect || tech_idx >= seffect->aTech.size())continue;
		
		auto& se_tech = seffect->aTech[tech_idx];

		for(zgU32 ip=0;ip<se_tech.aPass.size();++ip){

			CinfoShaderPass cinfo;
			cinfo.pGeom = geom.get();
			cinfo.pEffect = seffect.get();
			cinfo.idxTech = tech_idx;
			cinfo.idxPass = ip;

			for(zgU32 it=0;it<mat->aTex.size();++it){
				cinfo.aTex[it] = mat->aTex[it];
			}

			cinfo.numCBuff = cinfo.apCBuff.size();
			cinfo.apCBuff[SCBScene::CBSLOT] = renctx.pCBScene;
			cinfo.apCBuff[SCBLight::CBSLOT] = renctx.pCBLight;
			cinfo.apCBuff[SCBModel::CBSLOT] = this->pCBModel;
			cinfo.apCBuff[SCBBoneMatrix::CBSLOT] = this->pCBBoneMtx;
			cinfo.apCBuff[SCBObject::CBSLOT] = obj->pCBObject;
			cinfo.apCBuff[SCBMaterial::CBSLOT] = mat->pCBMateiral;

			SPassPtr pass(new ShaderPass);
			if(!pass)return 0;

			if( !CreateShaderPass( cinfo, *pass) )continue;
			
			RenElemX11 elem;
			elem.idxPass = ip;
			elem.pPass = pass;
			tmp.aDList.push_back(elem);
		}
	}
	renlist = std::move(tmp);
	return renlist.aDList.size();
}

//-----------------------
// ShaderPass�쐬
bool CreateShaderPass(const CinfoShaderPass& cinfo,  ShaderPass& out_pass)
{
	if( !cinfo.pEffect || !cinfo.pGeom )return false;

	RenContextX11& renctx = GetRenContext();

	ShaderPass pass;
	GeometryX11& geom = *cinfo.pGeom;
	ShaderEffect& seff = *cinfo.pEffect;
	if( cinfo.idxTech >= seff.aTech.size() )return false;
		
	auto& se_tech = seff.aTech[cinfo.idxTech];
	if( cinfo.idxPass >= se_tech.aPass.size() )return false;

	auto& se_pass = se_tech.aPass[cinfo.idxPass];
	if(!se_pass.pVShader || !se_pass.pPShader)return false;		
			
	// ���_�o�b�t�@
	zgU32 vbnum = 0;
	for(auto& vb : geom.aVBuff){
		pass.apVBuff[vbnum] = vb.pVBuff;
		pass.aStride[vbnum] = vb.uStride;
		pass.aOffset[vbnum] = vb.uOffset;
		++vbnum;
		if( vbnum >= ShaderPass::VBUFF_MAXNUM )break;
	}
	pass.numVBuff = vbnum;
	pass.pIdxBuff = geom.pIdxBuff;
	pass.eIdxFormat = geom.eIdxFormat;

	// ���̓��C�A�E�g�쐬
	std::vector<D3D11_INPUT_ELEMENT_DESC> input_desc;
	for(auto& d : geom.aInputDesc){
		D3D11_INPUT_ELEMENT_DESC id = {
					d.SemanticName.c_str(), d.SemanticIndex, d.Format, d.InputSlot, d.AlignedByteOffset,
					D3D11_INPUT_PER_VERTEX_DATA, 0 };
		input_desc.push_back(id);
	}
			
	UINT elem_num = input_desc.size();
	const D3D11_INPUT_ELEMENT_DESC* input_layout = input_desc.data();
			
	// ���̓p�����[�^�̃`�F�b�N
	// CreateInputLayout�Ń`�F�b�N�����
	// first chance exception�ƃG���[���O���o�͂����̂Ŏ����Ń`�F�b�N
	if( !CheckInputLayout(
				se_pass.pVSCode->GetBufferPointer(),
				se_pass.pVSCode->GetBufferSize(),
				input_layout, elem_num)
	){
		//���̃V�F�[�_�͎g���Ȃ�
		return false;
	}

	HRESULT hr = renctx.pDev->CreateInputLayout( input_layout, elem_num,
						se_pass.pVSCode->GetBufferPointer(),
						se_pass.pVSCode->GetBufferSize(), GSET_DXPTR(pass.pLayout) );
	if( FAILED( hr ) )return false;

	CheckInputResource(se_pass.pPSCode->GetBufferPointer(), se_pass.pPSCode->GetBufferSize());

	// �X�e�[�g
	pass.pRsState = se_pass.pRsState;
	pass.pBdState = se_pass.pBdState;
	pass.pDsState = se_pass.pDsState;

	// �V�F�[�_
	pass.pVShader = se_pass.pVShader;
	pass.pGShader = se_pass.pGShader;
	pass.pPShader = se_pass.pPShader;
	pass.uStencilRef = se_pass.uStencilRef;
					
	// �e�N�X�`��
	for(zgU32 it=0;it<ShaderPass::TEX_MAXNUM;++it){
		pass.apSRView[it] = cinfo.aTex[it].pSRView;
		pass.apSpState[it] = cinfo.aTex[it].pSpState;
	}

	// �萔�o�b�t�@
	pass.numCBuff = cinfo.numCBuff;
	for(zgU32 ic=0;ic<pass.numCBuff;++ic){
		pass.apCBuff[ic] = cinfo.apCBuff[ic];
	}

	pass.nCount = geom.nCount;
	pass.eTopo = geom.eTopo;
	
	out_pass = std::move(pass);
	return true;
}

//-------------------------------------------
bool RenderShaderPass(const IDevCtxPtr& dtvctx, ShaderPass& pass)
{
	RenContextX11& renctx =  GetRenContext();

	// ���̓��C�A�E�g
	dtvctx->IASetInputLayout( pass.pLayout.get() );

	// �C���f�b�N�X�o�b�t�@
	dtvctx->IASetIndexBuffer( pass.pIdxBuff.get(), pass.eIdxFormat, 0 );

	// ���_�o�b�t�@
	ID3D11Buffer* vbs[ShaderPass::VBUFF_MAXNUM];
	for(zgU32 vi=0;vi<pass.numVBuff;++vi){
		vbs[vi] = pass.apVBuff[vi].get();
	};
	dtvctx->IASetVertexBuffers( 0, pass.numVBuff, vbs,
									pass.aStride.data(), pass.aOffset.data() );

	// �X�e�[�g
	FLOAT bdfactor[4]={0,0,0,0};
	dtvctx->RSSetState( pass.pRsState.get() );
	dtvctx->OMSetBlendState( pass.pBdState.get(), bdfactor, 0xffffffff );
	dtvctx->OMSetDepthStencilState( pass.pDsState.get(), pass.uStencilRef );

	// �V�F�[�_
	{
		ID3D11Buffer* cb[ShaderPass::CBUFF_MAXNUM];
		for(zgU32 ci=0;ci<pass.numCBuff;++ci){
			cb[ci] = pass.apCBuff[ci].get();
		}
		dtvctx->VSSetConstantBuffers( 0, pass.numCBuff, cb );
		dtvctx->VSSetShader( pass.pVShader.get(), NULL, 0 );

		dtvctx->GSSetShader( pass.pGShader.get(), NULL, 0 );
		if(pass.pGShader.get()){
			dtvctx->GSSetConstantBuffers( 0, pass.numCBuff, cb );
		}

		// �e�N�X�`��
		ID3D11ShaderResourceView* srv[ShaderPass::TEX_MAXNUM];
		ID3D11SamplerState* ss[ShaderPass::TEX_MAXNUM];
		for(zgU32 ti=0;ti<ShaderPass::TEX_MAXNUM;++ti){
			srv[ti] = pass.apSRView[ti].get();
			ss[ti] = pass.apSpState[ti].get();
		}
		dtvctx->PSSetShaderResources( 0, ShaderPass::TEX_MAXNUM, srv );
		dtvctx->PSSetSamplers( 0, ShaderPass::TEX_MAXNUM, ss );

		dtvctx->PSSetShader( pass.pPShader.get(), NULL, 0 );
		dtvctx->PSSetConstantBuffers( 0, pass.numCBuff, cb );
	}

	// �v���~�e�B�u�`��
	dtvctx->IASetPrimitiveTopology( pass.eTopo ); 
	//�|���S���`��
	dtvctx->DrawIndexed( pass.nCount, 0, 0 );

	// ���@��Еt��
	{
		ID3D11ShaderResourceView* srv[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		ID3D11SamplerState* ss[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		dtvctx->PSSetShaderResources( 0, 16, srv );
		dtvctx->PSSetSamplers( 0, 16, ss );
	}
	return true;
}

}// zix11
