Texture2D txDiffuse : register( t0 );
SamplerState samLinear : register( s0 );
Texture2D txToon : register( t1 );
SamplerState samToon : register( s1 );
Texture2D txSphere : register( t2 );
SamplerState samSphere : register( s2 );

#include "cb_main.h"


//�{�[���C���f�b�N�X�ƃE�G�C�g�L
struct VS_INPUT_BONE
{
	float4 Pos : POSITION;
	float3 Nor : NORMAL;
	float2 Tex : TEXCOORD0;
	uint4 Bidx : BONEINDEX;
	uint4 Bwgt : BONEWEIGHT;
};

struct PS_INPUT
{
	float4 Pos : SV_POSITION;
	float3 Nor : NORMAL;
	float2 Tex : TEXCOORD0;
};


//-------------------------
//�{�[���ό`�����_�u�����h
PS_INPUT vsBasicBlend( VS_INPUT_BONE input)
{
	PS_INPUT output = (PS_INPUT)0;
	float4 pos = input.Pos;
	float3 nor = input.Nor;
	float4x3 bm0 = getBoneMatrix(input.Bidx.x);
	float4x3 bm1 = getBoneMatrix(input.Bidx.y);
	float3 bpos0 = input.Bwgt[0]*mul(pos, bm0);
	float3 bpos1 = input.Bwgt[1]*mul(pos, bm1);
	pos.xyz = (bpos0.xyz + bpos1.xyz)/100;
	
	float3 bnor0 = input.Bwgt[0]*mul(nor, (float3x3)bm0);
	float3 bnor1 = input.Bwgt[1]*mul(nor, (float3x3)bm1);
	nor= (bnor0.xyz + bnor1.xyz)/100;
	nor = mul( nor, (float3x3)Object.mtxWorld);

	
	pos = mul( pos, Object.mtxWorld );
	pos = mul( pos, Scene.mtxView );
	output.Pos = mul( pos, Scene.mtxProj );
	output.Tex = input.Tex;
	output.Nor = normalize(nor);
	return output;
}

//-------------------------
//�s�N�Z���V�F�[�_
float4 psBasic( PS_INPUT input ) : SV_Target
{
	float3 nor = normalize(input.Nor);

	float l = dot(nor, Light.vDirLight[0].xyz);

	nor = normalize( mul(nor, (float3x3)Scene.mtxView) );

	float4 toon = txToon.Sample( samToon, float2(0,0.5*(1-l)));
	
	float spmap = txSphere.Sample( samSphere, float2(0.5,0.5) + 0.5*nor.xy);
	return spmap + float4(toon.xyz,1)*txDiffuse.Sample( samLinear, input.Tex)*vDiffuse;
}

//-------------------------
//�V�F�[�_�G�t�F�N�g��`
#ifdef ZGFX

	technique Basic
	{
		pass P0
		{
			CullMode = NONE;
			VertexShader = compile vs_4_0 vsBasicBlend();
			PixelShader = compile ps_4_0 psBasic();
		}
	}

#endif//ZGFX

