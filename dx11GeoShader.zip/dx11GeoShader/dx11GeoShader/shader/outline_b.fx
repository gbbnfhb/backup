Texture2D txDiffuse : register( t0 );
SamplerState samLinear : register( s0 );

#include "cb_main.h"


//�{�[���C���f�b�N�X�ƃE�G�C�g�L
struct VS_INPUT_BONE
{
	float4 Pos : POSITION;
	uint4 Bidx : BONEINDEX;
	uint4 Bwgt : BONEWEIGHT;
};
struct GS_INPUT
{
	float4 Pos : SV_POSITION;
	float Edge : COLOR;
};

struct PS_INPUT
{
	float4 Pos : SV_POSITION;
	float Edge : COLOR;
};


//-------------------------
//�{�[���ό`�����_�u�����h
PS_INPUT vsBasicBlend( VS_INPUT_BONE input)
{
	PS_INPUT output = (PS_INPUT)0;
	float4 pos = input.Pos;
	float3 bpos0 = input.Bwgt[0]*mul(pos, getBoneMatrix(input.Bidx.x));
	float3 bpos1 = input.Bwgt[1]*mul(pos, getBoneMatrix(input.Bidx.y));
	pos.xyz = (bpos0.xyz + bpos1.xyz)/100;
	
	pos = mul( pos, Object.mtxWorld );
	pos = mul( pos, Scene.mtxView );
	output.Pos = mul( pos, Scene.mtxProj );
	output.Edge = input.Bwgt.w;//�����p
	return output;
}

// �W�I���g���V�F�[�_
[maxvertexcount(10)]
void gsBasic( lineadj GS_INPUT input[4],
			uint primID : SV_PrimitiveID,
			inout LineStream<PS_INPUT> Stream )
{
	float3 v0 = input[1].Pos.xyz/input[1].Pos.w;
	float3 v1 = input[2].Pos.xyz/input[2].Pos.w;
	float3 va = input[0].Pos.xyz/input[0].Pos.w;
	float3 vb = input[3].Pos.xyz/input[3].Pos.w;
	
	float3 v0a = v0-va;
	float3 v1a = v1-va;
	float3 v0b = v0-vb;
	float3 v1b = v1-vb;
	if( 0 > cross(v0a,v1a).z * cross(v1b,v0b).z )
	{
		PS_INPUT vo0,vo1;
		float4 p0 = input[1].Pos;
		float4 p1 = input[2].Pos;
		vo0.Pos = p0;
		vo1.Pos = p1;
		vo0.Edge = input[1].Edge;
		vo1.Edge = input[2].Edge;
		Stream.Append(vo0);
		Stream.Append(vo1);
		Stream.RestartStrip();

		//��{���ƍׂ��̂ŏ㉺���E�ɂ��炵�ĕ`��
		const float px = 0.8*p0.w/640.0;
		const float py = 0.8*p1.w/480.0;

		vo0.Pos = p0 + float4(px,0,0,0);
		vo1.Pos = p1 + float4(px,0,0,0);
		Stream.Append(vo0);
		Stream.Append(vo1);
		Stream.RestartStrip();

		vo0.Pos = p0 + float4(-px,0,0,0);
		vo1.Pos = p1 + float4(-px,0,0,0);
		Stream.Append(vo0);
		Stream.Append(vo1);
		Stream.RestartStrip();
		
		vo0.Pos = p0 + float4(0,py,0,0);
		vo1.Pos = p1 + float4(0,py,0,0);
		Stream.Append(vo0);
		Stream.Append(vo1);
		Stream.RestartStrip();

		vo0.Pos = p0 + float4(0,-py,0,0);
		vo1.Pos = p1 + float4(0,-py,0,0);
		Stream.Append(vo0);
		Stream.Append(vo1);
		Stream.RestartStrip();
		
	}

	Stream.RestartStrip();
}

//-------------------------
//�s�N�Z���V�F�[�_
float4 psBasic( PS_INPUT input ) : SV_Target
{
	return float4(0,0,0,0.25*input.Edge);
}

//-------------------------
//�V�F�[�_�G�t�F�N�g��`
#ifdef ZGFX

	technique Basic
	{
		pass P0
		{
			//�A���t�@�u�����h
			BlendEnable[0] = TRUE;
			SrcBlend[0] = ZERO;//SRC_ALPHA;
			DestBlend[0] = INV_SRC_ALPHA;
			BlendOp[0] = ADD;
			SrcBlendAlpha[0] = ONE;
			DestBlendAlpha[0] = ZERO;
			BlendOpAlpha[0] = ADD;

			CullMode = NONE;
			DepthFunc = LESS_EQUAL;
			VertexShader = compile vs_4_0 vsBasicBlend();
			GeometryShader = compile gs_4_0 gsBasic();
			PixelShader = compile ps_4_0 psBasic();
		}
	}

#endif//ZGFX

